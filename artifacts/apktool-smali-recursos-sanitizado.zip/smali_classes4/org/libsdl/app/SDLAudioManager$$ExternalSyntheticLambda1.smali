.class public final synthetic Lorg/libsdl/app/SDLAudioManager$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Predicate;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lorg/libsdl/app/SDLAudioManager;"
    method = "lambda$getOutputAudioDeviceInfo$0"
    proto = "(ILandroid/media/AudioDeviceInfo;)Z"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "cbd4c57888e08b903a50082e8040806b0c79bdc3f3008bd67f5febb2a47b439e"
.end annotation


# instance fields
.field public final synthetic f$0:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lorg/libsdl/app/SDLAudioManager$$ExternalSyntheticLambda1;->f$0:I

    return-void
.end method


# virtual methods
.method public final test(Ljava/lang/Object;)Z
    .locals 1

    .line 0
    iget v0, p0, Lorg/libsdl/app/SDLAudioManager$$ExternalSyntheticLambda1;->f$0:I

    check-cast p1, Landroid/media/AudioDeviceInfo;

    invoke-static {v0, p1}, Lorg/libsdl/app/SDLAudioManager;->lambda$getOutputAudioDeviceInfo$0(ILandroid/media/AudioDeviceInfo;)Z

    move-result p1

    return p1
.end method
