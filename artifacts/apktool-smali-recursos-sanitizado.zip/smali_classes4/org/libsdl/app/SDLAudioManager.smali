.class public Lorg/libsdl/app/SDLAudioManager;
.super Ljava/lang/Object;
.source "SDLAudioManager.java"


# static fields
.field private static final NO_DEVICES:[I

.field protected static final TAG:Ljava/lang/String; = "SDLAudio"

.field private static mAudioDeviceCallback:Landroid/media/AudioDeviceCallback;

.field protected static mAudioRecord:Landroid/media/AudioRecord;

.field protected static mAudioTrack:Landroid/media/AudioTrack;

.field protected static mContext:Landroid/content/Context;


# direct methods
.method public static synthetic $r8$lambda$iPF4QPypmKNdEynIqZOm9XoZWY4(Landroid/media/AudioDeviceInfo;)I
    .locals 0

    invoke-virtual {p0}, Landroid/media/AudioDeviceInfo;->getId()I

    move-result p0

    return p0
.end method

.method static constructor <clinit>()V
    .locals 1

    .line 23
    const/4 v0, 0x0

    new-array v0, v0, [I

    sput-object v0, Lorg/libsdl/app/SDLAudioManager;->NO_DEVICES:[I

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static native addAudioDevice(ZI)V
.end method

.method public static audioClose()V
    .locals 1

    .line 473
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    if-eqz v0, :cond_0

    .line 474
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    invoke-virtual {v0}, Landroid/media/AudioTrack;->stop()V

    .line 475
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    invoke-virtual {v0}, Landroid/media/AudioTrack;->release()V

    .line 476
    const/4 v0, 0x0

    sput-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    .line 478
    :cond_0
    return-void
.end method

.method public static audioOpen(IIIII)[I
    .locals 6
    .param p0, "sampleRate"    # I
    .param p1, "audioFormat"    # I
    .param p2, "desiredChannels"    # I
    .param p3, "desiredFrames"    # I
    .param p4, "deviceId"    # I

    .line 351
    const/4 v0, 0x0

    move v1, p0

    move v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    .end local p0    # "sampleRate":I
    .end local p1    # "audioFormat":I
    .end local p2    # "desiredChannels":I
    .end local p3    # "desiredFrames":I
    .end local p4    # "deviceId":I
    .local v1, "sampleRate":I
    .local v2, "audioFormat":I
    .local v3, "desiredChannels":I
    .local v4, "desiredFrames":I
    .local v5, "deviceId":I
    invoke-static/range {v0 .. v5}, Lorg/libsdl/app/SDLAudioManager;->open(ZIIIII)[I

    move-result-object p0

    return-object p0
.end method

.method public static audioSetThreadPriority(ZI)V
    .locals 3
    .param p0, "iscapture"    # Z
    .param p1, "device_id"    # I

    .line 494
    if-eqz p0, :cond_0

    .line 495
    :try_start_0
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "SDLAudioC"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    goto :goto_0

    .line 497
    :cond_0
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "SDLAudioP"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    .line 501
    :goto_0
    const/16 v0, -0x10

    invoke-static {v0}, Landroid/os/Process;->setThreadPriority(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 505
    goto :goto_1

    .line 503
    :catch_0
    move-exception v0

    .line 504
    .local v0, "e":Ljava/lang/Exception;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "modify thread properties failed "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "SDLAudio"

    invoke-static {v2, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 506
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_1
    return-void
.end method

.method public static audioWriteByteBuffer([B)V
    .locals 5
    .param p0, "buffer"    # [B

    .line 415
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    const-string v1, "SDLAudio"

    if-nez v0, :cond_0

    .line 416
    const-string v0, "Attempted to make audio call with uninitialized audio!"

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 417
    return-void

    .line 420
    :cond_0
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    array-length v2, p0

    if-ge v0, v2, :cond_3

    .line 421
    sget-object v2, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    array-length v3, p0

    sub-int/2addr v3, v0

    invoke-virtual {v2, p0, v0, v3}, Landroid/media/AudioTrack;->write([BII)I

    move-result v2

    .line 422
    .local v2, "result":I
    if-lez v2, :cond_1

    .line 423
    add-int/2addr v0, v2

    goto :goto_2

    .line 424
    :cond_1
    if-nez v2, :cond_2

    .line 426
    const-wide/16 v3, 0x1

    :try_start_0
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 429
    :goto_1
    goto :goto_2

    .line 427
    :catch_0
    move-exception v3

    goto :goto_1

    .line 434
    .end local v2    # "result":I
    :goto_2
    goto :goto_0

    .line 431
    .restart local v2    # "result":I
    :cond_2
    const-string v3, "SDL audio: error return from write(byte)"

    invoke-static {v1, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 432
    return-void

    .line 435
    .end local v0    # "i":I
    .end local v2    # "result":I
    :cond_3
    return-void
.end method

.method public static audioWriteFloatBuffer([F)V
    .locals 5
    .param p0, "buffer"    # [F

    .line 358
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    const-string v1, "SDLAudio"

    if-nez v0, :cond_0

    .line 359
    const-string v0, "Attempted to make audio call with uninitialized audio!"

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 360
    return-void

    .line 363
    :cond_0
    nop

    .line 368
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    array-length v2, p0

    if-ge v0, v2, :cond_3

    .line 369
    sget-object v2, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    array-length v3, p0

    sub-int/2addr v3, v0

    const/4 v4, 0x0

    invoke-virtual {v2, p0, v0, v3, v4}, Landroid/media/AudioTrack;->write([FIII)I

    move-result v2

    .line 370
    .local v2, "result":I
    if-lez v2, :cond_1

    .line 371
    add-int/2addr v0, v2

    goto :goto_2

    .line 372
    :cond_1
    if-nez v2, :cond_2

    .line 374
    const-wide/16 v3, 0x1

    :try_start_0
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 377
    :goto_1
    goto :goto_2

    .line 375
    :catch_0
    move-exception v3

    goto :goto_1

    .line 382
    .end local v2    # "result":I
    :goto_2
    goto :goto_0

    .line 379
    .restart local v2    # "result":I
    :cond_2
    const-string v3, "SDL audio: error return from write(float)"

    invoke-static {v1, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 380
    return-void

    .line 383
    .end local v0    # "i":I
    .end local v2    # "result":I
    :cond_3
    return-void
.end method

.method public static audioWriteShortBuffer([S)V
    .locals 5
    .param p0, "buffer"    # [S

    .line 389
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    const-string v1, "SDLAudio"

    if-nez v0, :cond_0

    .line 390
    const-string v0, "Attempted to make audio call with uninitialized audio!"

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 391
    return-void

    .line 394
    :cond_0
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    array-length v2, p0

    if-ge v0, v2, :cond_3

    .line 395
    sget-object v2, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    array-length v3, p0

    sub-int/2addr v3, v0

    invoke-virtual {v2, p0, v0, v3}, Landroid/media/AudioTrack;->write([SII)I

    move-result v2

    .line 396
    .local v2, "result":I
    if-lez v2, :cond_1

    .line 397
    add-int/2addr v0, v2

    goto :goto_2

    .line 398
    :cond_1
    if-nez v2, :cond_2

    .line 400
    const-wide/16 v3, 0x1

    :try_start_0
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 403
    :goto_1
    goto :goto_2

    .line 401
    :catch_0
    move-exception v3

    goto :goto_1

    .line 408
    .end local v2    # "result":I
    :goto_2
    goto :goto_0

    .line 405
    .restart local v2    # "result":I
    :cond_2
    const-string v3, "SDL audio: error return from write(short)"

    invoke-static {v1, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 406
    return-void

    .line 409
    .end local v0    # "i":I
    .end local v2    # "result":I
    :cond_3
    return-void
.end method

.method public static captureClose()V
    .locals 1

    .line 482
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioRecord:Landroid/media/AudioRecord;

    if-eqz v0, :cond_0

    .line 483
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioRecord:Landroid/media/AudioRecord;

    invoke-virtual {v0}, Landroid/media/AudioRecord;->stop()V

    .line 484
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioRecord:Landroid/media/AudioRecord;

    invoke-virtual {v0}, Landroid/media/AudioRecord;->release()V

    .line 485
    const/4 v0, 0x0

    sput-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioRecord:Landroid/media/AudioRecord;

    .line 487
    :cond_0
    return-void
.end method

.method public static captureOpen(IIIII)[I
    .locals 6
    .param p0, "sampleRate"    # I
    .param p1, "audioFormat"    # I
    .param p2, "desiredChannels"    # I
    .param p3, "desiredFrames"    # I
    .param p4, "deviceId"    # I

    .line 441
    const/4 v0, 0x1

    move v1, p0

    move v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    .end local p0    # "sampleRate":I
    .end local p1    # "audioFormat":I
    .end local p2    # "desiredChannels":I
    .end local p3    # "desiredFrames":I
    .end local p4    # "deviceId":I
    .local v1, "sampleRate":I
    .local v2, "audioFormat":I
    .local v3, "desiredChannels":I
    .local v4, "desiredFrames":I
    .local v5, "deviceId":I
    invoke-static/range {v0 .. v5}, Lorg/libsdl/app/SDLAudioManager;->open(ZIIIII)[I

    move-result-object p0

    return-object p0
.end method

.method public static captureReadByteBuffer([BZ)I
    .locals 4
    .param p0, "buffer"    # [B
    .param p1, "blocking"    # Z

    .line 464
    nop

    .line 467
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioRecord:Landroid/media/AudioRecord;

    array-length v1, p0

    xor-int/lit8 v2, p1, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, p0, v3, v1, v2}, Landroid/media/AudioRecord;->read([BIII)I

    move-result v0

    return v0
.end method

.method public static captureReadFloatBuffer([FZ)I
    .locals 4
    .param p0, "buffer"    # [F
    .param p1, "blocking"    # Z

    .line 446
    nop

    .line 449
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioRecord:Landroid/media/AudioRecord;

    array-length v1, p0

    xor-int/lit8 v2, p1, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, p0, v3, v1, v2}, Landroid/media/AudioRecord;->read([FIII)I

    move-result v0

    return v0
.end method

.method public static captureReadShortBuffer([SZ)I
    .locals 4
    .param p0, "buffer"    # [S
    .param p1, "blocking"    # Z

    .line 455
    nop

    .line 458
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioRecord:Landroid/media/AudioRecord;

    array-length v1, p0

    xor-int/lit8 v2, p1, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, p0, v3, v1, v2}, Landroid/media/AudioRecord;->read([SIII)I

    move-result v0

    return v0
.end method

.method protected static getAudioFormatString(I)Ljava/lang/String;
    .locals 1
    .param p0, "audioFormat"    # I

    .line 62
    packed-switch p0, :pswitch_data_0

    .line 70
    invoke-static {p0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 68
    :pswitch_0
    const-string v0, "float"

    return-object v0

    .line 64
    :pswitch_1
    const-string v0, "8-bit"

    return-object v0

    .line 66
    :pswitch_2
    const-string v0, "16-bit"

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static getAudioInputDevices()[I
    .locals 3

    .line 339
    nop

    .line 340
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mContext:Landroid/content/Context;

    const-string v1, "audio"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/AudioManager;

    .line 341
    .local v0, "audioManager":Landroid/media/AudioManager;
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getDevices(I)[Landroid/media/AudioDeviceInfo;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->stream([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v1

    new-instance v2, Lorg/libsdl/app/SDLAudioManager$$ExternalSyntheticLambda0;

    invoke-direct {v2}, Lorg/libsdl/app/SDLAudioManager$$ExternalSyntheticLambda0;-><init>()V

    invoke-interface {v1, v2}, Ljava/util/stream/Stream;->mapToInt(Ljava/util/function/ToIntFunction;)Ljava/util/stream/IntStream;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/stream/IntStream;->toArray()[I

    move-result-object v1

    return-object v1
.end method

.method public static getAudioOutputDevices()[I
    .locals 3

    .line 327
    nop

    .line 328
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mContext:Landroid/content/Context;

    const-string v1, "audio"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/AudioManager;

    .line 329
    .local v0, "audioManager":Landroid/media/AudioManager;
    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getDevices(I)[Landroid/media/AudioDeviceInfo;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->stream([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v1

    new-instance v2, Lorg/libsdl/app/SDLAudioManager$$ExternalSyntheticLambda0;

    invoke-direct {v2}, Lorg/libsdl/app/SDLAudioManager$$ExternalSyntheticLambda0;-><init>()V

    invoke-interface {v1, v2}, Ljava/util/stream/Stream;->mapToInt(Ljava/util/function/ToIntFunction;)Ljava/util/stream/IntStream;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/stream/IntStream;->toArray()[I

    move-result-object v1

    return-object v1
.end method

.method private static getInputAudioDeviceInfo(I)Landroid/media/AudioDeviceInfo;
    .locals 3
    .param p0, "deviceId"    # I

    .line 286
    nop

    .line 287
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mContext:Landroid/content/Context;

    const-string v1, "audio"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/AudioManager;

    .line 288
    .local v0, "audioManager":Landroid/media/AudioManager;
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getDevices(I)[Landroid/media/AudioDeviceInfo;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->stream([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v1

    new-instance v2, Lorg/libsdl/app/SDLAudioManager$$ExternalSyntheticLambda2;

    invoke-direct {v2, p0}, Lorg/libsdl/app/SDLAudioManager$$ExternalSyntheticLambda2;-><init>(I)V

    .line 289
    invoke-interface {v1, v2}, Ljava/util/stream/Stream;->filter(Ljava/util/function/Predicate;)Ljava/util/stream/Stream;

    move-result-object v1

    .line 290
    invoke-interface {v1}, Ljava/util/stream/Stream;->findFirst()Ljava/util/Optional;

    move-result-object v1

    .line 291
    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Ljava/util/Optional;->orElse(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/media/AudioDeviceInfo;

    .line 288
    return-object v1
.end method

.method private static getOutputAudioDeviceInfo(I)Landroid/media/AudioDeviceInfo;
    .locals 3
    .param p0, "deviceId"    # I

    .line 298
    nop

    .line 299
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mContext:Landroid/content/Context;

    const-string v1, "audio"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/AudioManager;

    .line 300
    .local v0, "audioManager":Landroid/media/AudioManager;
    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getDevices(I)[Landroid/media/AudioDeviceInfo;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->stream([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v1

    new-instance v2, Lorg/libsdl/app/SDLAudioManager$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0}, Lorg/libsdl/app/SDLAudioManager$$ExternalSyntheticLambda1;-><init>(I)V

    .line 301
    invoke-interface {v1, v2}, Ljava/util/stream/Stream;->filter(Ljava/util/function/Predicate;)Ljava/util/stream/Stream;

    move-result-object v1

    .line 302
    invoke-interface {v1}, Ljava/util/stream/Stream;->findFirst()Ljava/util/Optional;

    move-result-object v1

    .line 303
    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Ljava/util/Optional;->orElse(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/media/AudioDeviceInfo;

    .line 300
    return-object v1
.end method

.method public static initialize()V
    .locals 1

    .line 28
    const/4 v0, 0x0

    sput-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    .line 29
    sput-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioRecord:Landroid/media/AudioRecord;

    .line 30
    sput-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioDeviceCallback:Landroid/media/AudioDeviceCallback;

    .line 32
    nop

    .line 34
    new-instance v0, Lorg/libsdl/app/SDLAudioManager$1;

    invoke-direct {v0}, Lorg/libsdl/app/SDLAudioManager$1;-><init>()V

    sput-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioDeviceCallback:Landroid/media/AudioDeviceCallback;

    .line 46
    return-void
.end method

.method static synthetic lambda$getInputAudioDeviceInfo$0(ILandroid/media/AudioDeviceInfo;)Z
    .locals 1
    .param p0, "deviceId"    # I
    .param p1, "deviceInfo"    # Landroid/media/AudioDeviceInfo;

    .line 289
    invoke-virtual {p1}, Landroid/media/AudioDeviceInfo;->getId()I

    move-result v0

    if-ne v0, p0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method static synthetic lambda$getOutputAudioDeviceInfo$0(ILandroid/media/AudioDeviceInfo;)Z
    .locals 1
    .param p0, "deviceId"    # I
    .param p1, "deviceInfo"    # Landroid/media/AudioDeviceInfo;

    .line 301
    invoke-virtual {p1}, Landroid/media/AudioDeviceInfo;->getId()I

    move-result v0

    if-ne v0, p0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public static native nativeSetupJNI()I
.end method

.method protected static open(ZIIIII)[I
    .locals 25
    .param p0, "isCapture"    # Z
    .param p1, "sampleRate"    # I
    .param p2, "audioFormat"    # I
    .param p3, "desiredChannels"    # I
    .param p4, "desiredFrames"    # I
    .param p5, "deviceId"    # I

    .line 79
    move/from16 v2, p1

    move/from16 v0, p3

    move/from16 v1, p4

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Opening "

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v8, "capture"

    const-string v9, "playback"

    if-eqz p0, :cond_0

    move-object v4, v8

    goto :goto_0

    :cond_0
    move-object v4, v9

    :goto_0
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", requested "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v10, " frames of "

    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v11, " channel "

    invoke-virtual {v3, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-static/range {p2 .. p2}, Lorg/libsdl/app/SDLAudioManager;->getAudioFormatString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v12, " audio at "

    invoke-virtual {v3, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v13, " Hz"

    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v14, "SDLAudio"

    invoke-static {v14, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 82
    nop

    .line 89
    nop

    .line 97
    const/4 v3, 0x4

    move/from16 v4, p2

    if-ne v4, v3, :cond_2

    .line 98
    if-eqz p0, :cond_1

    const/16 v5, 0x17

    goto :goto_1

    :cond_1
    const/16 v5, 0x15

    .line 99
    .local v5, "minSDKVersion":I
    :goto_1
    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    if-ge v6, v5, :cond_2

    .line 100
    const/4 v4, 0x2

    .line 103
    .end local v5    # "minSDKVersion":I
    .end local p2    # "audioFormat":I
    .local v4, "audioFormat":I
    :cond_2
    packed-switch v4, :pswitch_data_0

    .line 115
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Requested format "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ", getting ENCODING_PCM_16BIT"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v14, v5}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 116
    const/4 v4, 0x2

    .line 117
    const/4 v5, 0x2

    move v15, v5

    .local v5, "sampleSize":I
    goto :goto_2

    .line 112
    .end local v5    # "sampleSize":I
    :pswitch_0
    const/4 v5, 0x4

    .line 113
    .restart local v5    # "sampleSize":I
    move v15, v5

    goto :goto_2

    .line 106
    .end local v5    # "sampleSize":I
    :pswitch_1
    const/4 v5, 0x1

    .line 107
    .restart local v5    # "sampleSize":I
    move v15, v5

    goto :goto_2

    .line 109
    .end local v5    # "sampleSize":I
    :pswitch_2
    const/4 v5, 0x2

    .line 110
    .restart local v5    # "sampleSize":I
    move v15, v5

    .line 121
    .end local v5    # "sampleSize":I
    .local v15, "sampleSize":I
    :goto_2
    const-string v5, " channels, getting stereo"

    const-string v6, "Requested "

    if-eqz p0, :cond_3

    .line 122
    packed-switch v0, :pswitch_data_1

    .line 130
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v14, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 131
    const/4 v0, 0x2

    .line 132
    .end local p3    # "desiredChannels":I
    .local v0, "desiredChannels":I
    const/16 v5, 0xc

    .line 133
    .local v5, "channelConfig":I
    move/from16 v17, v0

    move v3, v5

    goto/16 :goto_3

    .line 127
    .end local v0    # "desiredChannels":I
    .end local v5    # "channelConfig":I
    .restart local p3    # "desiredChannels":I
    :pswitch_3
    const/16 v5, 0xc

    .line 128
    .restart local v5    # "channelConfig":I
    move/from16 v17, v0

    move v3, v5

    goto/16 :goto_3

    .line 124
    .end local v5    # "channelConfig":I
    :pswitch_4
    const/16 v5, 0x10

    .line 125
    .restart local v5    # "channelConfig":I
    move/from16 v17, v0

    move v3, v5

    goto :goto_3

    .line 136
    .end local v5    # "channelConfig":I
    :cond_3
    packed-switch v0, :pswitch_data_2

    .line 168
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v14, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 169
    const/4 v0, 0x2

    .line 170
    .end local p3    # "desiredChannels":I
    .restart local v0    # "desiredChannels":I
    const/16 v5, 0xc

    move/from16 v17, v0

    move v3, v5

    .restart local v5    # "channelConfig":I
    goto :goto_3

    .line 159
    .end local v0    # "desiredChannels":I
    .end local v5    # "channelConfig":I
    .restart local p3    # "desiredChannels":I
    :pswitch_5
    nop

    .line 160
    const/16 v5, 0x18fc

    move/from16 v17, v0

    move v3, v5

    .restart local v5    # "channelConfig":I
    goto :goto_3

    .line 156
    .end local v5    # "channelConfig":I
    :pswitch_6
    const/16 v5, 0x4fc

    .line 157
    .restart local v5    # "channelConfig":I
    move/from16 v17, v0

    move v3, v5

    goto :goto_3

    .line 153
    .end local v5    # "channelConfig":I
    :pswitch_7
    const/16 v5, 0xfc

    .line 154
    .restart local v5    # "channelConfig":I
    move/from16 v17, v0

    move v3, v5

    goto :goto_3

    .line 150
    .end local v5    # "channelConfig":I
    :pswitch_8
    const/16 v5, 0xdc

    .line 151
    .restart local v5    # "channelConfig":I
    move/from16 v17, v0

    move v3, v5

    goto :goto_3

    .line 147
    .end local v5    # "channelConfig":I
    :pswitch_9
    const/16 v5, 0xcc

    .line 148
    .restart local v5    # "channelConfig":I
    move/from16 v17, v0

    move v3, v5

    goto :goto_3

    .line 144
    .end local v5    # "channelConfig":I
    :pswitch_a
    const/16 v5, 0x1c

    .line 145
    .restart local v5    # "channelConfig":I
    move/from16 v17, v0

    move v3, v5

    goto :goto_3

    .line 141
    .end local v5    # "channelConfig":I
    :pswitch_b
    const/16 v5, 0xc

    .line 142
    .restart local v5    # "channelConfig":I
    move/from16 v17, v0

    move v3, v5

    goto :goto_3

    .line 138
    .end local v5    # "channelConfig":I
    :pswitch_c
    const/4 v5, 0x4

    .line 139
    .restart local v5    # "channelConfig":I
    move/from16 v17, v0

    move v3, v5

    .line 212
    .end local v5    # "channelConfig":I
    .end local p3    # "desiredChannels":I
    .local v3, "channelConfig":I
    .local v17, "desiredChannels":I
    :goto_3
    mul-int v18, v15, v17

    .line 218
    .local v18, "frameSize":I
    if-eqz p0, :cond_4

    .line 219
    invoke-static {v2, v3, v4}, Landroid/media/AudioRecord;->getMinBufferSize(III)I

    move-result v0

    move/from16 v19, v0

    .local v0, "minBufferSize":I
    goto :goto_4

    .line 221
    .end local v0    # "minBufferSize":I
    :cond_4
    invoke-static {v2, v3, v4}, Landroid/media/AudioTrack;->getMinBufferSize(III)I

    move-result v0

    move/from16 v19, v0

    .line 223
    .local v19, "minBufferSize":I
    :goto_4
    add-int v0, v19, v18

    const/4 v6, 0x1

    sub-int/2addr v0, v6

    div-int v0, v0, v18

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v20

    .line 225
    .end local p4    # "desiredFrames":I
    .local v20, "desiredFrames":I
    const/4 v0, 0x4

    new-array v0, v0, [I

    .line 227
    .local v0, "results":[I
    const/16 v16, 0x2

    const/16 v21, 0x0

    const/16 v22, 0x0

    if-eqz p0, :cond_8

    .line 228
    sget-object v1, Lorg/libsdl/app/SDLAudioManager;->mAudioRecord:Landroid/media/AudioRecord;

    if-nez v1, :cond_7

    .line 229
    move-object v1, v0

    .end local v0    # "results":[I
    .local v1, "results":[I
    new-instance v0, Landroid/media/AudioRecord;

    move-object v5, v1

    .end local v1    # "results":[I
    .local v5, "results":[I
    const/4 v1, 0x0

    move-object/from16 v23, v5

    .end local v5    # "results":[I
    .local v23, "results":[I
    mul-int v5, v20, v18

    invoke-direct/range {v0 .. v5}, Landroid/media/AudioRecord;-><init>(IIIII)V

    sput-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioRecord:Landroid/media/AudioRecord;

    .line 233
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioRecord:Landroid/media/AudioRecord;

    invoke-virtual {v0}, Landroid/media/AudioRecord;->getState()I

    move-result v0

    if-eq v0, v6, :cond_5

    .line 234
    const-string v0, "Failed during initialization of AudioRecord"

    invoke-static {v14, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 235
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioRecord:Landroid/media/AudioRecord;

    invoke-virtual {v0}, Landroid/media/AudioRecord;->release()V

    .line 236
    sput-object v22, Lorg/libsdl/app/SDLAudioManager;->mAudioRecord:Landroid/media/AudioRecord;

    .line 237
    return-object v22

    .line 240
    :cond_5
    if-eqz p5, :cond_6

    .line 241
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioRecord:Landroid/media/AudioRecord;

    invoke-static/range {p5 .. p5}, Lorg/libsdl/app/SDLAudioManager;->getOutputAudioDeviceInfo(I)Landroid/media/AudioDeviceInfo;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/media/AudioRecord;->setPreferredDevice(Landroid/media/AudioDeviceInfo;)Z

    .line 244
    :cond_6
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioRecord:Landroid/media/AudioRecord;

    invoke-virtual {v0}, Landroid/media/AudioRecord;->startRecording()V

    goto :goto_5

    .line 228
    .end local v23    # "results":[I
    .restart local v0    # "results":[I
    :cond_7
    move-object/from16 v23, v0

    .line 247
    .end local v0    # "results":[I
    .restart local v23    # "results":[I
    :goto_5
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioRecord:Landroid/media/AudioRecord;

    invoke-virtual {v0}, Landroid/media/AudioRecord;->getSampleRate()I

    move-result v0

    aput v0, v23, v21

    .line 248
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioRecord:Landroid/media/AudioRecord;

    invoke-virtual {v0}, Landroid/media/AudioRecord;->getAudioFormat()I

    move-result v0

    aput v0, v23, v6

    .line 249
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioRecord:Landroid/media/AudioRecord;

    invoke-virtual {v0}, Landroid/media/AudioRecord;->getChannelCount()I

    move-result v0

    aput v0, v23, v16

    move-object/from16 v24, v8

    move v8, v6

    goto :goto_7

    .line 252
    .end local v23    # "results":[I
    .restart local v0    # "results":[I
    :cond_8
    move-object/from16 v23, v0

    .end local v0    # "results":[I
    .restart local v23    # "results":[I
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    if-nez v0, :cond_b

    .line 253
    new-instance v0, Landroid/media/AudioTrack;

    mul-int v5, v20, v18

    move v1, v6

    const/4 v6, 0x1

    move v2, v1

    const/4 v1, 0x3

    move-object/from16 v24, v8

    move v8, v2

    move/from16 v2, p1

    invoke-direct/range {v0 .. v6}, Landroid/media/AudioTrack;-><init>(IIIIII)V

    sput-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    .line 258
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    invoke-virtual {v0}, Landroid/media/AudioTrack;->getState()I

    move-result v0

    if-eq v0, v8, :cond_9

    .line 261
    const-string v0, "Failed during initialization of Audio Track"

    invoke-static {v14, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 262
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    invoke-virtual {v0}, Landroid/media/AudioTrack;->release()V

    .line 263
    sput-object v22, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    .line 264
    return-object v22

    .line 267
    :cond_9
    if-eqz p5, :cond_a

    .line 268
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    invoke-static/range {p5 .. p5}, Lorg/libsdl/app/SDLAudioManager;->getInputAudioDeviceInfo(I)Landroid/media/AudioDeviceInfo;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/media/AudioTrack;->setPreferredDevice(Landroid/media/AudioDeviceInfo;)Z

    .line 271
    :cond_a
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    invoke-virtual {v0}, Landroid/media/AudioTrack;->play()V

    goto :goto_6

    .line 252
    :cond_b
    move-object/from16 v24, v8

    move v8, v6

    .line 274
    :goto_6
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    invoke-virtual {v0}, Landroid/media/AudioTrack;->getSampleRate()I

    move-result v0

    aput v0, v23, v21

    .line 275
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    invoke-virtual {v0}, Landroid/media/AudioTrack;->getAudioFormat()I

    move-result v0

    aput v0, v23, v8

    .line 276
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mAudioTrack:Landroid/media/AudioTrack;

    invoke-virtual {v0}, Landroid/media/AudioTrack;->getChannelCount()I

    move-result v0

    aput v0, v23, v16

    .line 278
    :goto_7
    const/4 v0, 0x3

    aput v20, v23, v0

    .line 280
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    if-eqz p0, :cond_c

    move-object/from16 v9, v24

    :cond_c
    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", got "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    aget v0, v23, v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    aget v1, v23, v16

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    aget v1, v23, v8

    invoke-static {v1}, Lorg/libsdl/app/SDLAudioManager;->getAudioFormatString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    aget v1, v23, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v14, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 282
    return-object v23

    nop

    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x1
        :pswitch_4
        :pswitch_3
    .end packed-switch

    :pswitch_data_2
    .packed-switch 0x1
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
    .end packed-switch
.end method

.method private static registerAudioDeviceCallback()V
    .locals 3

    .line 310
    nop

    .line 311
    sget-object v0, Lorg/libsdl/app/SDLAudioManager;->mContext:Landroid/content/Context;

    const-string v1, "audio"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/AudioManager;

    .line 312
    .local v0, "audioManager":Landroid/media/AudioManager;
    sget-object v1, Lorg/libsdl/app/SDLAudioManager;->mAudioDeviceCallback:Landroid/media/AudioDeviceCallback;

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/media/AudioManager;->registerAudioDeviceCallback(Landroid/media/AudioDeviceCallback;Landroid/os/Handler;)V

    .line 314
    .end local v0    # "audioManager":Landroid/media/AudioManager;
    return-void
.end method

.method public static release(Landroid/content/Context;)V
    .locals 0
    .param p0, "context"    # Landroid/content/Context;

    .line 56
    invoke-static {p0}, Lorg/libsdl/app/SDLAudioManager;->unregisterAudioDeviceCallback(Landroid/content/Context;)V

    .line 57
    return-void
.end method

.method public static native removeAudioDevice(ZI)V
.end method

.method public static setContext(Landroid/content/Context;)V
    .locals 0
    .param p0, "context"    # Landroid/content/Context;

    .line 49
    sput-object p0, Lorg/libsdl/app/SDLAudioManager;->mContext:Landroid/content/Context;

    .line 50
    if-eqz p0, :cond_0

    .line 51
    invoke-static {}, Lorg/libsdl/app/SDLAudioManager;->registerAudioDeviceCallback()V

    .line 53
    :cond_0
    return-void
.end method

.method private static unregisterAudioDeviceCallback(Landroid/content/Context;)V
    .locals 2
    .param p0, "context"    # Landroid/content/Context;

    .line 317
    nop

    .line 318
    const-string v0, "audio"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/AudioManager;

    .line 319
    .local v0, "audioManager":Landroid/media/AudioManager;
    sget-object v1, Lorg/libsdl/app/SDLAudioManager;->mAudioDeviceCallback:Landroid/media/AudioDeviceCallback;

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->unregisterAudioDeviceCallback(Landroid/media/AudioDeviceCallback;)V

    .line 321
    .end local v0    # "audioManager":Landroid/media/AudioManager;
    return-void
.end method
