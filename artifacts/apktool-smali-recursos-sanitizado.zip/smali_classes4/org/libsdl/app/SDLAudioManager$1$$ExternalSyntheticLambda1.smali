.class public final synthetic Lorg/libsdl/app/SDLAudioManager$1$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Consumer;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lorg/libsdl/app/SDLAudioManager$1;"
    method = "lambda$onAudioDevicesAdded$0"
    proto = "(Landroid/media/AudioDeviceInfo;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "cbd4c57888e08b903a50082e8040806b0c79bdc3f3008bd67f5febb2a47b439e"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 0

    .line 0
    check-cast p1, Landroid/media/AudioDeviceInfo;

    invoke-static {p1}, Lorg/libsdl/app/SDLAudioManager$1;->lambda$onAudioDevicesAdded$0(Landroid/media/AudioDeviceInfo;)V

    return-void
.end method
