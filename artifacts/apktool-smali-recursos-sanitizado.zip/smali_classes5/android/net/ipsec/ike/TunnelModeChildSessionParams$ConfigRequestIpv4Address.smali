.class public interface abstract synthetic Landroid/net/ipsec/ike/TunnelModeChildSessionParams$ConfigRequestIpv4Address;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/net/ipsec/ike/TunnelModeChildSessionParams$TunnelModeChildConfigRequest;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/NoClassDefFoundError;

    invoke-direct {v0}, Ljava/lang/NoClassDefFoundError;-><init>()V

    throw v0
.end method
