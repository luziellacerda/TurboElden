.class final Lorg/emulationstation/frontend/HttpBridge$CancelledException;
.super Ljava/lang/Exception;
.source "HttpBridge.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/emulationstation/frontend/HttpBridge;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "CancelledException"
.end annotation


# direct methods
.method constructor <init>()V
    .locals 1

    .line 548
    const-string v0, "cancelled"

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    return-void
.end method
