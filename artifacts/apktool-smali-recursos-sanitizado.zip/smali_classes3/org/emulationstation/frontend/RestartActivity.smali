.class public final Lorg/emulationstation/frontend/RestartActivity;
.super Landroid/app/Activity;
.source "RestartActivity.java"


# static fields
.field public static final EXTRA_PID:Ljava/lang/String; = "pid"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 21
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 4
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 28
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 30
    invoke-virtual {p0}, Lorg/emulationstation/frontend/RestartActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "pid"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    .line 31
    .local v0, "pid":I
    if-lez v0, :cond_0

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v1

    if-eq v0, v1, :cond_0

    .line 32
    invoke-static {v0}, Landroid/os/Process;->killProcess(I)V

    .line 34
    :cond_0
    new-instance v1, Landroid/content/Intent;

    const-class v3, Lorg/emulationstation/frontend/ESActivity;

    invoke-direct {v1, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 35
    .local v1, "launch":Landroid/content/Intent;
    const v3, 0x10008000

    invoke-virtual {v1, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 36
    invoke-virtual {p0, v1}, Lorg/emulationstation/frontend/RestartActivity;->startActivity(Landroid/content/Intent;)V

    .line 38
    invoke-virtual {p0}, Lorg/emulationstation/frontend/RestartActivity;->finish()V

    .line 41
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/Runtime;->exit(I)V

    .line 42
    return-void
.end method
