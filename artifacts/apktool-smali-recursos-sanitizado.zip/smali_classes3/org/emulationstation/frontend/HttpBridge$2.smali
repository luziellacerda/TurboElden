.class Lorg/emulationstation/frontend/HttpBridge$2;
.super Ljava/lang/Object;
.source "HttpBridge.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/emulationstation/frontend/HttpBridge;->startInternal(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)I
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$destPath:Ljava/lang/String;

.field final synthetic val$extractAll:Z

.field final synthetic val$extractDir:Ljava/lang/String;

.field final synthetic val$request:Lorg/emulationstation/frontend/HttpBridge$Request;

.field final synthetic val$url:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;Ljava/lang/String;Z)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 286
    iput-object p1, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$url:Ljava/lang/String;

    iput-object p2, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$destPath:Ljava/lang/String;

    iput-object p3, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$request:Lorg/emulationstation/frontend/HttpBridge$Request;

    iput-object p4, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$extractDir:Ljava/lang/String;

    iput-boolean p5, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$extractAll:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 290
    iget-object v0, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$url:Ljava/lang/String;

    iget-object v1, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$destPath:Ljava/lang/String;

    iget-object v2, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$request:Lorg/emulationstation/frontend/HttpBridge$Request;

    invoke-static {v0, v1, v2}, Lorg/emulationstation/frontend/HttpBridge;->-$$Nest$smexecute(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;)V

    .line 292
    iget-object v0, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$extractDir:Ljava/lang/String;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$request:Lorg/emulationstation/frontend/HttpBridge$Request;

    iget-boolean v0, v0, Lorg/emulationstation/frontend/HttpBridge$Request;->downloadOk:Z

    if-eqz v0, :cond_1

    .line 294
    iget-boolean v0, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$extractAll:Z

    .line 297
    iget-object v1, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$destPath:Ljava/lang/String;

    .line 294
    if-eqz v0, :cond_0

    .line 295
    iget-object v0, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$extractDir:Ljava/lang/String;

    iget-object v2, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$request:Lorg/emulationstation/frontend/HttpBridge$Request;

    invoke-static {v1, v0, v2}, Lorg/emulationstation/frontend/HttpBridge;->-$$Nest$smextractAll(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;)V

    goto :goto_0

    .line 297
    :cond_0
    iget-object v0, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$extractDir:Ljava/lang/String;

    iget-object v2, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$request:Lorg/emulationstation/frontend/HttpBridge$Request;

    invoke-static {v1, v0, v2}, Lorg/emulationstation/frontend/HttpBridge;->-$$Nest$smextractCores(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;)V

    .line 301
    :cond_1
    :goto_0
    iget-object v0, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$destPath:Ljava/lang/String;

    if-eqz v0, :cond_3

    iget-object v0, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$extractDir:Ljava/lang/String;

    if-nez v0, :cond_3

    iget-object v0, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$request:Lorg/emulationstation/frontend/HttpBridge$Request;

    iget-boolean v0, v0, Lorg/emulationstation/frontend/HttpBridge$Request;->userCancelled:Z

    if-nez v0, :cond_3

    .line 302
    iget-object v0, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$request:Lorg/emulationstation/frontend/HttpBridge$Request;

    iget-object v0, v0, Lorg/emulationstation/frontend/HttpBridge$Request;->title:Ljava/lang/String;

    iget-object v1, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$request:Lorg/emulationstation/frontend/HttpBridge$Request;

    iget v1, v1, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I

    const/4 v2, 0x1

    if-ne v1, v2, :cond_2

    goto :goto_1

    :cond_2
    const/4 v2, 0x0

    :goto_1
    iget-object v1, p0, Lorg/emulationstation/frontend/HttpBridge$2;->val$request:Lorg/emulationstation/frontend/HttpBridge$Request;

    iget-object v1, v1, Lorg/emulationstation/frontend/HttpBridge$Request;->error:Ljava/lang/String;

    invoke-static {v0, v2, v1}, Lorg/emulationstation/frontend/DownloadService;->notifyFinished(Ljava/lang/String;ZLjava/lang/String;)V

    .line 303
    :cond_3
    return-void
.end method
