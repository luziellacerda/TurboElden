.class public final synthetic Lorg/emulationstation/frontend/HttpBridge-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
