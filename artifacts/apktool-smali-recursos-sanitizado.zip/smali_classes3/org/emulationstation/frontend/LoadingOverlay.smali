.class final Lorg/emulationstation/frontend/LoadingOverlay;
.super Landroid/view/View;
.source "LoadingOverlay.java"


# static fields
.field private static sView:Lorg/emulationstation/frontend/LoadingOverlay;


# instance fields
.field private final mArc:Landroid/graphics/Paint;

.field private final mCaption:Landroid/graphics/Paint;

.field private mGradientHeight:I

.field private mName:Ljava/lang/String;

.field private final mOval:Landroid/graphics/RectF;

.field private final mScrim:Landroid/graphics/Paint;

.field private final mStart:J

.field private final mTitle:Landroid/graphics/Paint;

.field private final mTrack:Landroid/graphics/Paint;


# direct methods
.method static bridge synthetic -$$Nest$fputmName(Lorg/emulationstation/frontend/LoadingOverlay;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mName:Ljava/lang/String;

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetsView()Lorg/emulationstation/frontend/LoadingOverlay;
    .locals 1

    sget-object v0, Lorg/emulationstation/frontend/LoadingOverlay;->sView:Lorg/emulationstation/frontend/LoadingOverlay;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfputsView(Lorg/emulationstation/frontend/LoadingOverlay;)V
    .locals 0

    sput-object p0, Lorg/emulationstation/frontend/LoadingOverlay;->sView:Lorg/emulationstation/frontend/LoadingOverlay;

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "name"    # Ljava/lang/String;

    .line 42
    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 29
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mScrim:Landroid/graphics/Paint;

    .line 30
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mTrack:Landroid/graphics/Paint;

    .line 31
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mArc:Landroid/graphics/Paint;

    .line 32
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mTitle:Landroid/graphics/Paint;

    .line 33
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mCaption:Landroid/graphics/Paint;

    .line 34
    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mOval:Landroid/graphics/RectF;

    .line 35
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    iput-wide v2, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mStart:J

    .line 43
    iput-object p2, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mName:Ljava/lang/String;

    .line 45
    iget-object v0, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mTrack:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 46
    iget-object v0, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mTrack:Landroid/graphics/Paint;

    const v2, 0x30ffffff

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 48
    iget-object v0, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mArc:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 49
    iget-object v0, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mArc:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 50
    iget-object v0, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mArc:Landroid/graphics/Paint;

    const v2, -0x19000001

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 52
    sget-object v0, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    .line 55
    .local v0, "typeface":Landroid/graphics/Typeface;
    :try_start_0
    invoke-virtual {p1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v2

    const-string v3, "resources/sst_medium_condensed.ttf"

    invoke-static {v2, v3}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-object v0, v2

    goto :goto_0

    .line 57
    :catch_0
    move-exception v2

    :goto_0
    nop

    .line 59
    iget-object v2, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mTitle:Landroid/graphics/Paint;

    invoke-virtual {v2, v0}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 60
    iget-object v2, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mTitle:Landroid/graphics/Paint;

    const/4 v3, -0x1

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 61
    iget-object v2, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mTitle:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 63
    iget-object v2, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mCaption:Landroid/graphics/Paint;

    invoke-virtual {v2, v0}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 64
    iget-object v2, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mCaption:Landroid/graphics/Paint;

    const v3, -0x473d30

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 65
    iget-object v2, p0, Lorg/emulationstation/frontend/LoadingOverlay;->mCaption:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 68
    invoke-virtual {p0, v1}, Lorg/emulationstation/frontend/LoadingOverlay;->setClickable(Z)V

    .line 69
    return-void
.end method

.method synthetic constructor <init>(Landroid/content/Context;Ljava/lang/String;Lorg/emulationstation/frontend/LoadingOverlay-IA;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lorg/emulationstation/frontend/LoadingOverlay;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method

.method static hide(Landroid/app/Activity;)V
    .locals 1
    .param p0, "activity"    # Landroid/app/Activity;

    .line 145
    if-nez p0, :cond_0

    .line 146
    return-void

    .line 148
    :cond_0
    new-instance v0, Lorg/emulationstation/frontend/LoadingOverlay$2;

    invoke-direct {v0}, Lorg/emulationstation/frontend/LoadingOverlay$2;-><init>()V

    invoke-virtual {p0, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 168
    return-void
.end method

.method static show(Landroid/app/Activity;Ljava/lang/String;)V
    .locals 1
    .param p0, "activity"    # Landroid/app/Activity;
    .param p1, "name"    # Ljava/lang/String;

    .line 119
    if-nez p0, :cond_0

    .line 120
    return-void

    .line 122
    :cond_0
    new-instance v0, Lorg/emulationstation/frontend/LoadingOverlay$1;

    invoke-direct {v0, p1, p0}, Lorg/emulationstation/frontend/LoadingOverlay$1;-><init>(Ljava/lang/String;Landroid/app/Activity;)V

    invoke-virtual {p0, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 140
    return-void
.end method


# virtual methods
.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 17
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .line 74
    move-object/from16 v0, p0

    invoke-virtual {v0}, Lorg/emulationstation/frontend/LoadingOverlay;->getWidth()I

    move-result v7

    .line 75
    .local v7, "width":I
    invoke-virtual {v0}, Lorg/emulationstation/frontend/LoadingOverlay;->getHeight()I

    move-result v8

    .line 78
    .local v8, "height":I
    iget v1, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mGradientHeight:I

    if-eq v1, v8, :cond_0

    .line 80
    iput v8, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mGradientHeight:I

    .line 81
    iget-object v1, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mScrim:Landroid/graphics/Paint;

    new-instance v9, Landroid/graphics/LinearGradient;

    int-to-float v13, v8

    const v15, -0x9d5ca70

    sget-object v16, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const v14, -0xfe9f0bb

    invoke-direct/range {v9 .. v16}, Landroid/graphics/LinearGradient;-><init>(FFFFIILandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v1, v9}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 83
    :cond_0
    int-to-float v4, v7

    int-to-float v5, v8

    iget-object v6, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mScrim:Landroid/graphics/Paint;

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object/from16 v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 87
    invoke-static {v7, v8}, Ljava/lang/Math;->min(II)I

    move-result v2

    int-to-float v9, v2

    .line 88
    .local v9, "unit":F
    const v2, 0x3d23d70a    # 0.04f

    mul-float v10, v9, v2

    .line 89
    .local v10, "radius":F
    int-to-float v2, v7

    const/high16 v3, 0x3f000000    # 0.5f

    mul-float v11, v2, v3

    .line 90
    .local v11, "cx":F
    int-to-float v2, v8

    mul-float v12, v2, v3

    .line 91
    .local v12, "cy":F
    const v2, 0x3db851ec    # 0.09f

    mul-float v13, v10, v2

    .line 93
    .local v13, "stroke":F
    iget-object v2, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mTrack:Landroid/graphics/Paint;

    invoke-virtual {v2, v13}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 94
    iget-object v2, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mArc:Landroid/graphics/Paint;

    invoke-virtual {v2, v13}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 95
    iget-object v2, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mOval:Landroid/graphics/RectF;

    sub-float v3, v11, v10

    sub-float v4, v12, v10

    add-float v5, v11, v10

    add-float v6, v12, v10

    invoke-virtual {v2, v3, v4, v5, v6}, Landroid/graphics/RectF;->set(FFFF)V

    .line 97
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    iget-wide v4, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mStart:J

    sub-long v14, v2, v4

    .line 98
    .local v14, "elapsed":J
    long-to-float v2, v14

    const v3, 0x3e92b021    # 0.2865f

    mul-float/2addr v2, v3

    const/high16 v3, 0x43b40000    # 360.0f

    rem-float v3, v2, v3

    .line 100
    .local v3, "angle":F
    iget-object v2, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mTrack:Landroid/graphics/Paint;

    invoke-virtual {v1, v11, v12, v10, v2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 101
    iget-object v2, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mOval:Landroid/graphics/RectF;

    const/4 v5, 0x0

    iget-object v6, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mArc:Landroid/graphics/Paint;

    const/high16 v4, 0x42a00000    # 80.0f

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    .line 104
    iget-object v2, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mTitle:Landroid/graphics/Paint;

    const v4, 0x3d3851ec    # 0.045f

    mul-float/2addr v4, v9

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 105
    iget-object v2, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mCaption:Landroid/graphics/Paint;

    const v4, 0x3d03126f    # 0.032f

    mul-float/2addr v4, v9

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 107
    const v2, 0x400ccccd    # 2.2f

    mul-float/2addr v2, v10

    add-float/2addr v2, v12

    iget-object v4, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mTitle:Landroid/graphics/Paint;

    invoke-virtual {v4}, Landroid/graphics/Paint;->getTextSize()F

    move-result v4

    add-float/2addr v2, v4

    .line 108
    .local v2, "titleY":F
    iget-object v4, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mName:Ljava/lang/String;

    if-eqz v4, :cond_1

    iget-object v4, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mName:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_1

    .line 109
    iget-object v4, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mName:Ljava/lang/String;

    iget-object v5, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mTitle:Landroid/graphics/Paint;

    invoke-virtual {v1, v4, v11, v2, v5}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 111
    :cond_1
    iget-object v4, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mCaption:Landroid/graphics/Paint;

    invoke-virtual {v4}, Landroid/graphics/Paint;->getTextSize()F

    move-result v4

    const v5, 0x3fcccccd    # 1.6f

    mul-float/2addr v4, v5

    add-float/2addr v4, v2

    iget-object v5, v0, Lorg/emulationstation/frontend/LoadingOverlay;->mCaption:Landroid/graphics/Paint;

    const-string v6, "CARREGANDO"

    invoke-virtual {v1, v6, v11, v4, v5}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 113
    invoke-virtual {v0}, Lorg/emulationstation/frontend/LoadingOverlay;->postInvalidateOnAnimation()V

    .line 114
    return-void
.end method
