.class Lorg/emulationstation/frontend/HttpBridge$3;
.super Ljava/lang/Object;
.source "HttpBridge.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/emulationstation/frontend/HttpBridge;->downloadInParts(Ljava/lang/String;Ljava/io/File;Lorg/emulationstation/frontend/HttpBridge$Request;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$channel:Ljava/nio/channels/FileChannel;

.field final synthetic val$end:J

.field final synthetic val$failure:[Ljava/lang/Exception;

.field final synthetic val$request:Lorg/emulationstation/frontend/HttpBridge$Request;

.field final synthetic val$start:J

.field final synthetic val$url:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/nio/channels/FileChannel;JJLorg/emulationstation/frontend/HttpBridge$Request;[Ljava/lang/Exception;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 581
    iput-object p1, p0, Lorg/emulationstation/frontend/HttpBridge$3;->val$url:Ljava/lang/String;

    iput-object p2, p0, Lorg/emulationstation/frontend/HttpBridge$3;->val$channel:Ljava/nio/channels/FileChannel;

    iput-wide p3, p0, Lorg/emulationstation/frontend/HttpBridge$3;->val$start:J

    iput-wide p5, p0, Lorg/emulationstation/frontend/HttpBridge$3;->val$end:J

    iput-object p7, p0, Lorg/emulationstation/frontend/HttpBridge$3;->val$request:Lorg/emulationstation/frontend/HttpBridge$Request;

    iput-object p8, p0, Lorg/emulationstation/frontend/HttpBridge$3;->val$failure:[Ljava/lang/Exception;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    .line 587
    :try_start_0
    iget-object v0, p0, Lorg/emulationstation/frontend/HttpBridge$3;->val$url:Ljava/lang/String;

    iget-object v1, p0, Lorg/emulationstation/frontend/HttpBridge$3;->val$channel:Ljava/nio/channels/FileChannel;

    iget-wide v2, p0, Lorg/emulationstation/frontend/HttpBridge$3;->val$start:J

    iget-wide v4, p0, Lorg/emulationstation/frontend/HttpBridge$3;->val$end:J

    iget-object v6, p0, Lorg/emulationstation/frontend/HttpBridge$3;->val$request:Lorg/emulationstation/frontend/HttpBridge$Request;

    invoke-static/range {v0 .. v6}, Lorg/emulationstation/frontend/HttpBridge;->-$$Nest$smdownloadRange(Ljava/lang/String;Ljava/nio/channels/FileChannel;JJLorg/emulationstation/frontend/HttpBridge$Request;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 598
    goto :goto_0

    .line 589
    :catch_0
    move-exception v0

    move-object v1, v0

    .line 591
    .local v1, "e":Ljava/lang/Exception;
    iget-object v2, p0, Lorg/emulationstation/frontend/HttpBridge$3;->val$failure:[Ljava/lang/Exception;

    monitor-enter v2

    .line 593
    :try_start_1
    iget-object v0, p0, Lorg/emulationstation/frontend/HttpBridge$3;->val$failure:[Ljava/lang/Exception;

    const/4 v3, 0x0

    aget-object v0, v0, v3

    if-nez v0, :cond_0

    .line 594
    iget-object v0, p0, Lorg/emulationstation/frontend/HttpBridge$3;->val$failure:[Ljava/lang/Exception;

    aput-object v1, v0, v3

    .line 595
    :cond_0
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 597
    iget-object v0, p0, Lorg/emulationstation/frontend/HttpBridge$3;->val$request:Lorg/emulationstation/frontend/HttpBridge$Request;

    const/4 v2, 0x1

    iput-boolean v2, v0, Lorg/emulationstation/frontend/HttpBridge$Request;->cancelled:Z

    .line 599
    .end local v1    # "e":Ljava/lang/Exception;
    :goto_0
    return-void

    .line 595
    .restart local v1    # "e":Ljava/lang/Exception;
    :catchall_0
    move-exception v0

    :try_start_2
    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0
.end method
