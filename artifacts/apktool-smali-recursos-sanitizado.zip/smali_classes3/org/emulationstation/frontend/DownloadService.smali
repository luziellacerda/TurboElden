.class public final Lorg/emulationstation/frontend/DownloadService;
.super Landroid/app/Service;
.source "DownloadService.java"


# static fields
.field private static final CHANNEL_DONE:Ljava/lang/String; = "downloads_done"

.field private static final CHANNEL_PROGRESS:Ljava/lang/String; = "downloads"

.field private static final NOTIFICATION_ID:I = 0x1b59

.field private static final REFRESH_MS:J = 0x3e8L

.field private static volatile sRunning:Z


# instance fields
.field private final mHandler:Landroid/os/Handler;

.field private mLastBytes:J

.field private mLastTime:J

.field private final mRefresh:Ljava/lang/Runnable;

.field private mSpeed:D

.field private mWakeLock:Landroid/os/PowerManager$WakeLock;

.field private mWifiLock:Landroid/net/wifi/WifiManager$WifiLock;


# direct methods
.method static bridge synthetic -$$Nest$fgetmHandler(Lorg/emulationstation/frontend/DownloadService;)Landroid/os/Handler;
    .locals 0

    iget-object p0, p0, Lorg/emulationstation/frontend/DownloadService;->mHandler:Landroid/os/Handler;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mbuildProgress(Lorg/emulationstation/frontend/DownloadService;)Landroid/app/Notification;
    .locals 0

    invoke-direct {p0}, Lorg/emulationstation/frontend/DownloadService;->buildProgress()Landroid/app/Notification;

    move-result-object p0

    return-object p0
.end method

.method public constructor <init>()V
    .locals 2

    .line 35
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    .line 44
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lorg/emulationstation/frontend/DownloadService;->mHandler:Landroid/os/Handler;

    .line 48
    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lorg/emulationstation/frontend/DownloadService;->mLastBytes:J

    .line 135
    new-instance v0, Lorg/emulationstation/frontend/DownloadService$1;

    invoke-direct {v0, p0}, Lorg/emulationstation/frontend/DownloadService$1;-><init>(Lorg/emulationstation/frontend/DownloadService;)V

    iput-object v0, p0, Lorg/emulationstation/frontend/DownloadService;->mRefresh:Ljava/lang/Runnable;

    return-void
.end method

.method private buildProgress()Landroid/app/Notification;
    .locals 15

    .line 156
    invoke-static {}, Lorg/emulationstation/frontend/HttpBridge;->activeFileDownloads()Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;

    move-result-object v0

    .line 159
    .local v0, "snapshot":Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    .line 160
    .local v1, "now":J
    iget-wide v3, p0, Lorg/emulationstation/frontend/DownloadService;->mLastBytes:J

    const-wide/16 v5, 0x0

    cmp-long v3, v3, v5

    const-wide/16 v7, 0x0

    if-ltz v3, :cond_1

    iget-wide v3, p0, Lorg/emulationstation/frontend/DownloadService;->mLastTime:J

    cmp-long v3, v1, v3

    if-lez v3, :cond_1

    iget-wide v3, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->downloaded:J

    iget-wide v9, p0, Lorg/emulationstation/frontend/DownloadService;->mLastBytes:J

    cmp-long v3, v3, v9

    if-ltz v3, :cond_1

    .line 162
    iget-wide v3, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->downloaded:J

    iget-wide v9, p0, Lorg/emulationstation/frontend/DownloadService;->mLastBytes:J

    sub-long/2addr v3, v9

    long-to-double v3, v3

    const-wide v9, 0x408f400000000000L    # 1000.0

    mul-double/2addr v3, v9

    iget-wide v9, p0, Lorg/emulationstation/frontend/DownloadService;->mLastTime:J

    sub-long v9, v1, v9

    long-to-double v9, v9

    div-double/2addr v3, v9

    .line 163
    .local v3, "instant":D
    iget-wide v9, p0, Lorg/emulationstation/frontend/DownloadService;->mSpeed:D

    cmpg-double v9, v9, v7

    if-gtz v9, :cond_0

    move-wide v9, v3

    goto :goto_0

    :cond_0
    iget-wide v9, p0, Lorg/emulationstation/frontend/DownloadService;->mSpeed:D

    const-wide v11, 0x3fe3333333333333L    # 0.6

    mul-double/2addr v9, v11

    const-wide v11, 0x3fd999999999999aL    # 0.4

    mul-double/2addr v11, v3

    add-double/2addr v9, v11

    :goto_0
    iput-wide v9, p0, Lorg/emulationstation/frontend/DownloadService;->mSpeed:D

    .line 165
    .end local v3    # "instant":D
    :cond_1
    iget-wide v3, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->downloaded:J

    iput-wide v3, p0, Lorg/emulationstation/frontend/DownloadService;->mLastBytes:J

    .line 166
    iput-wide v1, p0, Lorg/emulationstation/frontend/DownloadService;->mLastTime:J

    .line 168
    iget v3, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->count:I

    const-string v4, "Baixando "

    const/4 v9, 0x1

    if-gt v3, v9, :cond_3

    .line 169
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->firstTitle:Ljava/lang/String;

    if-eqz v4, :cond_2

    iget-object v4, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->firstTitle:Ljava/lang/String;

    goto :goto_1

    :cond_2
    const-string v4, ""

    :goto_1
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    goto :goto_2

    .line 170
    :cond_3
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget v4, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->count:I

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " jogos"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    :goto_2
    nop

    .line 172
    .local v3, "title":Ljava/lang/String;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 173
    .local v4, "text":Ljava/lang/StringBuilder;
    const/4 v10, -0x1

    .line 175
    .local v10, "percent":I
    iget-wide v11, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->total:J

    cmp-long v5, v11, v5

    if-lez v5, :cond_4

    .line 177
    iget-wide v5, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->downloaded:J

    const-wide/16 v11, 0x64

    mul-long/2addr v5, v11

    iget-wide v13, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->total:J

    div-long/2addr v5, v13

    invoke-static {v11, v12, v5, v6}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v5

    long-to-int v10, v5

    .line 178
    invoke-virtual {v4, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "%  \u00b7  "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-wide v11, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->downloaded:J

    invoke-static {v11, v12}, Lorg/emulationstation/frontend/DownloadService;->size(J)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " de "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-wide v11, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->total:J

    invoke-static {v11, v12}, Lorg/emulationstation/frontend/DownloadService;->size(J)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_3

    .line 182
    :cond_4
    iget-wide v5, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->downloaded:J

    invoke-static {v5, v6}, Lorg/emulationstation/frontend/DownloadService;->size(J)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 185
    :goto_3
    iget-wide v5, p0, Lorg/emulationstation/frontend/DownloadService;->mSpeed:D

    cmpl-double v5, v5, v7

    if-lez v5, :cond_5

    .line 186
    const-string v5, "  \u00b7  "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-wide v6, p0, Lorg/emulationstation/frontend/DownloadService;->mSpeed:D

    double-to-long v6, v6

    invoke-static {v6, v7}, Lorg/emulationstation/frontend/DownloadService;->size(J)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "/s"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 188
    :cond_5
    new-instance v5, Landroidx/core/app/NotificationCompat$Builder;

    const-string v6, "downloads"

    invoke-direct {v5, p0, v6}, Landroidx/core/app/NotificationCompat$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 189
    const v6, 0x1080081

    invoke-virtual {v5, v6}, Landroidx/core/app/NotificationCompat$Builder;->setSmallIcon(I)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v5

    .line 190
    invoke-virtual {v5, v3}, Landroidx/core/app/NotificationCompat$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v5

    .line 191
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroidx/core/app/NotificationCompat$Builder;->setContentText(Ljava/lang/CharSequence;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v5

    .line 192
    const/4 v6, 0x0

    invoke-static {v10, v6}, Ljava/lang/Math;->max(II)I

    move-result v7

    if-gez v10, :cond_6

    move v6, v9

    :cond_6
    const/16 v8, 0x64

    invoke-virtual {v5, v8, v7, v6}, Landroidx/core/app/NotificationCompat$Builder;->setProgress(IIZ)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v5

    .line 193
    invoke-virtual {v5, v9}, Landroidx/core/app/NotificationCompat$Builder;->setOngoing(Z)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v5

    .line 194
    invoke-virtual {v5, v9}, Landroidx/core/app/NotificationCompat$Builder;->setOnlyAlertOnce(Z)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v5

    .line 195
    invoke-virtual {v5, v9}, Landroidx/core/app/NotificationCompat$Builder;->setSilent(Z)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v5

    .line 196
    invoke-static {p0}, Lorg/emulationstation/frontend/DownloadService;->openAppIntent(Landroid/content/Context;)Landroid/app/PendingIntent;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroidx/core/app/NotificationCompat$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v5

    .line 197
    invoke-virtual {v5, v9}, Landroidx/core/app/NotificationCompat$Builder;->setForegroundServiceBehavior(I)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v5

    .line 198
    invoke-virtual {v5}, Landroidx/core/app/NotificationCompat$Builder;->build()Landroid/app/Notification;

    move-result-object v5

    .line 188
    return-object v5
.end method

.method private static createChannels(Landroid/content/Context;)V
    .locals 6
    .param p0, "context"    # Landroid/content/Context;

    .line 233
    nop

    .line 236
    const-string v0, "notification"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    .line 237
    .local v0, "manager":Landroid/app/NotificationManager;
    if-nez v0, :cond_0

    .line 238
    return-void

    .line 241
    :cond_0
    new-instance v1, Landroid/app/NotificationChannel;

    const-string v2, "Downloads em andamento"

    const/4 v3, 0x2

    const-string v4, "downloads"

    invoke-direct {v1, v4, v2, v3}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    .line 242
    .local v1, "progress":Landroid/app/NotificationChannel;
    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/app/NotificationChannel;->setShowBadge(Z)V

    .line 243
    invoke-virtual {v0, v1}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 245
    new-instance v2, Landroid/app/NotificationChannel;

    const-string v3, "Downloads conclu\u00eddos"

    const/4 v4, 0x3

    const-string v5, "downloads_done"

    invoke-direct {v2, v5, v3, v4}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    invoke-virtual {v0, v2}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 246
    return-void
.end method

.method static ensureRunning()V
    .locals 4

    .line 55
    invoke-static {}, Lorg/emulationstation/frontend/ESActivity;->getAppContext()Landroid/content/Context;

    move-result-object v0

    .line 56
    .local v0, "context":Landroid/content/Context;
    if-eqz v0, :cond_1

    sget-boolean v1, Lorg/emulationstation/frontend/DownloadService;->sRunning:Z

    if-eqz v1, :cond_0

    goto :goto_1

    .line 59
    :cond_0
    invoke-static {}, Lorg/emulationstation/frontend/ESActivity;->requestNotificationPermission()V

    .line 63
    :try_start_0
    new-instance v1, Landroid/content/Intent;

    const-class v2, Lorg/emulationstation/frontend/DownloadService;

    invoke-direct {v1, v0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-static {v0, v1}, Landroidx/core/content/ContextCompat;->startForegroundService(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 70
    goto :goto_0

    .line 65
    :catch_0
    move-exception v1

    .line 69
    .local v1, "e":Ljava/lang/Exception;
    const-string v2, "EmulationStation"

    const-string v3, "Could not start the download service"

    invoke-static {v2, v3, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 71
    .end local v1    # "e":Ljava/lang/Exception;
    :goto_0
    return-void

    .line 57
    :cond_1
    :goto_1
    return-void
.end method

.method static notifyFinished(Ljava/lang/String;ZLjava/lang/String;)V
    .locals 5
    .param p0, "title"    # Ljava/lang/String;
    .param p1, "succeeded"    # Z
    .param p2, "error"    # Ljava/lang/String;

    .line 76
    invoke-static {}, Lorg/emulationstation/frontend/ESActivity;->getAppContext()Landroid/content/Context;

    move-result-object v0

    .line 77
    .local v0, "context":Landroid/content/Context;
    if-nez v0, :cond_0

    .line 78
    return-void

    .line 80
    :cond_0
    invoke-static {v0}, Lorg/emulationstation/frontend/DownloadService;->createChannels(Landroid/content/Context;)V

    .line 82
    new-instance v1, Landroidx/core/app/NotificationCompat$Builder;

    const-string v2, "downloads_done"

    invoke-direct {v1, v0, v2}, Landroidx/core/app/NotificationCompat$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 83
    if-eqz p1, :cond_1

    const v2, 0x1080082

    goto :goto_0

    :cond_1
    const v2, 0x1080078

    :goto_0
    invoke-virtual {v1, v2}, Landroidx/core/app/NotificationCompat$Builder;->setSmallIcon(I)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v1

    .line 84
    if-eqz p1, :cond_2

    const-string v2, "Download conclu\u00eddo"

    goto :goto_1

    :cond_2
    const-string v2, "Falha no download"

    :goto_1
    invoke-virtual {v1, v2}, Landroidx/core/app/NotificationCompat$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v1

    .line 85
    if-eqz p1, :cond_3

    move-object v2, p0

    goto :goto_2

    :cond_3
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " - "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :goto_2
    invoke-virtual {v1, v2}, Landroidx/core/app/NotificationCompat$Builder;->setContentText(Ljava/lang/CharSequence;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v1

    .line 86
    invoke-static {v0}, Lorg/emulationstation/frontend/DownloadService;->openAppIntent(Landroid/content/Context;)Landroid/app/PendingIntent;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroidx/core/app/NotificationCompat$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v1

    .line 87
    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroidx/core/app/NotificationCompat$Builder;->setAutoCancel(Z)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v1

    .line 89
    .local v1, "builder":Landroidx/core/app/NotificationCompat$Builder;
    const-string v2, "notification"

    invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/app/NotificationManager;

    .line 90
    .local v2, "manager":Landroid/app/NotificationManager;
    if-eqz v2, :cond_4

    .line 91
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v3

    const v4, 0x186a0

    rem-int/2addr v3, v4

    invoke-static {v3}, Ljava/lang/Math;->abs(I)I

    move-result v3

    add-int/lit16 v3, v3, 0x1b5a

    invoke-virtual {v1}, Landroidx/core/app/NotificationCompat$Builder;->build()Landroid/app/Notification;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    .line 92
    :cond_4
    return-void
.end method

.method private static openAppIntent(Landroid/content/Context;)Landroid/app/PendingIntent;
    .locals 3
    .param p0, "context"    # Landroid/content/Context;

    .line 223
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lorg/emulationstation/frontend/ESActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 224
    const-string v1, "android.intent.action.MAIN"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 225
    const-string v1, "android.intent.category.LAUNCHER"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 226
    const/high16 v1, 0x10200000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v0

    .line 228
    .local v0, "open":Landroid/content/Intent;
    const/4 v1, 0x0

    const/high16 v2, 0xc000000

    invoke-static {p0, v1, v0, v2}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v1

    return-object v1
.end method

.method private static size(J)Ljava/lang/String;
    .locals 5
    .param p0, "bytes"    # J

    .line 250
    const-wide/32 v0, 0x40000000

    cmp-long v0, p0, v0

    if-ltz v0, :cond_0

    .line 251
    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    long-to-double v1, p0

    const-wide/high16 v3, 0x41d0000000000000L    # 1.073741824E9

    div-double/2addr v1, v3

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const-string v2, "%.2f GB"

    invoke-static {v0, v2, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 252
    :cond_0
    const-wide/32 v0, 0x100000

    cmp-long v0, p0, v0

    if-ltz v0, :cond_1

    .line 253
    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    long-to-double v1, p0

    const-wide/high16 v3, 0x4130000000000000L    # 1048576.0

    div-double/2addr v1, v3

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const-string v2, "%.1f MB"

    invoke-static {v0, v2, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 254
    :cond_1
    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-wide/16 v1, 0x400

    div-long v1, p0, v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const-string v2, "%d KB"

    invoke-static {v0, v2, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 1
    .param p1, "intent"    # Landroid/content/Intent;

    .line 218
    const/4 v0, 0x0

    return-object v0
.end method

.method public onCreate()V
    .locals 6

    .line 97
    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    .line 98
    const/4 v0, 0x1

    sput-boolean v0, Lorg/emulationstation/frontend/DownloadService;->sRunning:Z

    .line 99
    invoke-static {p0}, Lorg/emulationstation/frontend/DownloadService;->createChannels(Landroid/content/Context;)V

    .line 103
    const-string v1, "power"

    invoke-virtual {p0, v1}, Lorg/emulationstation/frontend/DownloadService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/PowerManager;

    .line 104
    .local v1, "power":Landroid/os/PowerManager;
    const/4 v2, 0x0

    const-string v3, "EmulationStation:download"

    if-eqz v1, :cond_0

    .line 106
    invoke-virtual {v1, v0, v3}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    move-result-object v0

    iput-object v0, p0, Lorg/emulationstation/frontend/DownloadService;->mWakeLock:Landroid/os/PowerManager$WakeLock;

    .line 107
    iget-object v0, p0, Lorg/emulationstation/frontend/DownloadService;->mWakeLock:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {v0, v2}, Landroid/os/PowerManager$WakeLock;->setReferenceCounted(Z)V

    .line 108
    iget-object v0, p0, Lorg/emulationstation/frontend/DownloadService;->mWakeLock:Landroid/os/PowerManager$WakeLock;

    const-wide/32 v4, 0x1499700

    invoke-virtual {v0, v4, v5}, Landroid/os/PowerManager$WakeLock;->acquire(J)V

    .line 111
    :cond_0
    invoke-virtual {p0}, Lorg/emulationstation/frontend/DownloadService;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v4, "wifi"

    invoke-virtual {v0, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/net/wifi/WifiManager;

    .line 112
    .local v0, "wifi":Landroid/net/wifi/WifiManager;
    if-eqz v0, :cond_2

    .line 114
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x1d

    if-lt v4, v5, :cond_1

    .line 115
    const/4 v4, 0x4

    goto :goto_0

    .line 116
    :cond_1
    const/4 v4, 0x3

    :goto_0
    nop

    .line 117
    .local v4, "mode":I
    invoke-virtual {v0, v4, v3}, Landroid/net/wifi/WifiManager;->createWifiLock(ILjava/lang/String;)Landroid/net/wifi/WifiManager$WifiLock;

    move-result-object v3

    iput-object v3, p0, Lorg/emulationstation/frontend/DownloadService;->mWifiLock:Landroid/net/wifi/WifiManager$WifiLock;

    .line 118
    iget-object v3, p0, Lorg/emulationstation/frontend/DownloadService;->mWifiLock:Landroid/net/wifi/WifiManager$WifiLock;

    invoke-virtual {v3, v2}, Landroid/net/wifi/WifiManager$WifiLock;->setReferenceCounted(Z)V

    .line 119
    iget-object v2, p0, Lorg/emulationstation/frontend/DownloadService;->mWifiLock:Landroid/net/wifi/WifiManager$WifiLock;

    invoke-virtual {v2}, Landroid/net/wifi/WifiManager$WifiLock;->acquire()V

    .line 121
    .end local v4    # "mode":I
    :cond_2
    return-void
.end method

.method public onDestroy()V
    .locals 2

    .line 204
    iget-object v0, p0, Lorg/emulationstation/frontend/DownloadService;->mHandler:Landroid/os/Handler;

    iget-object v1, p0, Lorg/emulationstation/frontend/DownloadService;->mRefresh:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 206
    iget-object v0, p0, Lorg/emulationstation/frontend/DownloadService;->mWakeLock:Landroid/os/PowerManager$WakeLock;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lorg/emulationstation/frontend/DownloadService;->mWakeLock:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 207
    iget-object v0, p0, Lorg/emulationstation/frontend/DownloadService;->mWakeLock:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V

    .line 208
    :cond_0
    iget-object v0, p0, Lorg/emulationstation/frontend/DownloadService;->mWifiLock:Landroid/net/wifi/WifiManager$WifiLock;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lorg/emulationstation/frontend/DownloadService;->mWifiLock:Landroid/net/wifi/WifiManager$WifiLock;

    invoke-virtual {v0}, Landroid/net/wifi/WifiManager$WifiLock;->isHeld()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 209
    iget-object v0, p0, Lorg/emulationstation/frontend/DownloadService;->mWifiLock:Landroid/net/wifi/WifiManager$WifiLock;

    invoke-virtual {v0}, Landroid/net/wifi/WifiManager$WifiLock;->release()V

    .line 211
    :cond_1
    const/4 v0, 0x0

    sput-boolean v0, Lorg/emulationstation/frontend/DownloadService;->sRunning:Z

    .line 212
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    .line 213
    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 3
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "flags"    # I
    .param p3, "startId"    # I

    .line 127
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1d

    if-lt v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    .line 128
    .local v0, "type":I
    :goto_0
    const/16 v1, 0x1b59

    invoke-direct {p0}, Lorg/emulationstation/frontend/DownloadService;->buildProgress()Landroid/app/Notification;

    move-result-object v2

    invoke-static {p0, v1, v2, v0}, Landroidx/core/app/ServiceCompat;->startForeground(Landroid/app/Service;ILandroid/app/Notification;I)V

    .line 130
    iget-object v1, p0, Lorg/emulationstation/frontend/DownloadService;->mHandler:Landroid/os/Handler;

    iget-object v2, p0, Lorg/emulationstation/frontend/DownloadService;->mRefresh:Ljava/lang/Runnable;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 131
    iget-object v1, p0, Lorg/emulationstation/frontend/DownloadService;->mHandler:Landroid/os/Handler;

    iget-object v2, p0, Lorg/emulationstation/frontend/DownloadService;->mRefresh:Ljava/lang/Runnable;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 132
    const/4 v1, 0x2

    return v1
.end method
