.class Lorg/emulationstation/frontend/LoadingOverlay$2$1;
.super Ljava/lang/Object;
.source "LoadingOverlay.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/emulationstation/frontend/LoadingOverlay$2;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lorg/emulationstation/frontend/LoadingOverlay$2;

.field final synthetic val$view:Lorg/emulationstation/frontend/LoadingOverlay;


# direct methods
.method constructor <init>(Lorg/emulationstation/frontend/LoadingOverlay$2;Lorg/emulationstation/frontend/LoadingOverlay;)V
    .locals 0
    .param p1, "this$0"    # Lorg/emulationstation/frontend/LoadingOverlay$2;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 157
    iput-object p2, p0, Lorg/emulationstation/frontend/LoadingOverlay$2$1;->val$view:Lorg/emulationstation/frontend/LoadingOverlay;

    iput-object p1, p0, Lorg/emulationstation/frontend/LoadingOverlay$2$1;->this$0:Lorg/emulationstation/frontend/LoadingOverlay$2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 161
    iget-object v0, p0, Lorg/emulationstation/frontend/LoadingOverlay$2$1;->val$view:Lorg/emulationstation/frontend/LoadingOverlay;

    invoke-virtual {v0}, Lorg/emulationstation/frontend/LoadingOverlay;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    .line 162
    .local v0, "parent":Landroid/view/ViewGroup;
    if-eqz v0, :cond_0

    .line 163
    iget-object v1, p0, Lorg/emulationstation/frontend/LoadingOverlay$2$1;->val$view:Lorg/emulationstation/frontend/LoadingOverlay;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 164
    :cond_0
    return-void
.end method
