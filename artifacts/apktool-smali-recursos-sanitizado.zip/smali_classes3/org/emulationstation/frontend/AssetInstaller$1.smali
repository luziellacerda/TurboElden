.class Lorg/emulationstation/frontend/AssetInstaller$1;
.super Ljava/lang/Object;
.source "AssetInstaller.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/emulationstation/frontend/AssetInstaller;->installPacks(Landroid/content/Context;Ljava/io/File;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$assets:Landroid/content/res/AssetManager;

.field final synthetic val$pending:Ljava/util/List;

.field final synthetic val$systemDir:Ljava/io/File;


# direct methods
.method constructor <init>(Ljava/util/List;Ljava/io/File;Landroid/content/res/AssetManager;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 109
    iput-object p1, p0, Lorg/emulationstation/frontend/AssetInstaller$1;->val$pending:Ljava/util/List;

    iput-object p2, p0, Lorg/emulationstation/frontend/AssetInstaller$1;->val$systemDir:Ljava/io/File;

    iput-object p3, p0, Lorg/emulationstation/frontend/AssetInstaller$1;->val$assets:Landroid/content/res/AssetManager;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 13

    .line 113
    const-string v0, "EmulationStation"

    iget-object v1, p0, Lorg/emulationstation/frontend/AssetInstaller$1;->val$pending:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Ljava/lang/String;

    .line 118
    .local v2, "pack":[Ljava/lang/String;
    new-instance v3, Ljava/io/File;

    iget-object v4, p0, Lorg/emulationstation/frontend/AssetInstaller$1;->val$systemDir:Ljava/io/File;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    aget-object v7, v2, v6

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, ".installing"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v4, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 122
    .local v3, "installing":Ljava/io/File;
    const/4 v4, 0x0

    :try_start_0
    new-instance v5, Ljava/io/FileOutputStream;

    invoke-direct {v5, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 123
    .local v5, "flag":Ljava/io/OutputStream;
    :try_start_1
    const-string v7, "1\n"

    invoke-virtual {v7}, Ljava/lang/String;->getBytes()[B

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/io/OutputStream;->write([B)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 124
    :try_start_2
    invoke-virtual {v5}, Ljava/io/OutputStream;->close()V

    .line 126
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    .line 127
    .local v7, "started":J
    iget-object v9, p0, Lorg/emulationstation/frontend/AssetInstaller$1;->val$assets:Landroid/content/res/AssetManager;

    aget-object v10, v2, v4

    iget-object v11, p0, Lorg/emulationstation/frontend/AssetInstaller$1;->val$systemDir:Ljava/io/File;

    invoke-static {v9, v10, v11}, Lorg/emulationstation/frontend/AssetInstaller;->-$$Nest$smextractPack(Landroid/content/res/AssetManager;Ljava/lang/String;Ljava/io/File;)I

    move-result v9

    .line 129
    .local v9, "files":I
    new-instance v10, Ljava/io/FileOutputStream;

    new-instance v11, Ljava/io/File;

    iget-object v12, p0, Lorg/emulationstation/frontend/AssetInstaller$1;->val$systemDir:Ljava/io/File;

    aget-object v6, v2, v6

    invoke-direct {v11, v12, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-direct {v10, v11}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 130
    .local v10, "marker":Ljava/io/OutputStream;
    :try_start_3
    const-string v6, "ok\n"

    invoke-virtual {v6}, Ljava/lang/String;->getBytes()[B

    move-result-object v6

    invoke-virtual {v10, v6}, Ljava/io/OutputStream;->write([B)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 131
    :try_start_4
    invoke-virtual {v10}, Ljava/io/OutputStream;->close()V

    .line 133
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "Installed "

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    aget-object v11, v2, v4

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v11, ": "

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v11, " files in "

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    sub-long/2addr v11, v7

    invoke-virtual {v6, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v11, " ms"

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v0, v6}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 142
    nop

    .end local v5    # "flag":Ljava/io/OutputStream;
    .end local v7    # "started":J
    .end local v9    # "files":I
    .end local v10    # "marker":Ljava/io/OutputStream;
    goto :goto_1

    .line 131
    .restart local v5    # "flag":Ljava/io/OutputStream;
    .restart local v7    # "started":J
    .restart local v9    # "files":I
    .restart local v10    # "marker":Ljava/io/OutputStream;
    :catchall_0
    move-exception v6

    invoke-virtual {v10}, Ljava/io/OutputStream;->close()V

    .end local v2    # "pack":[Ljava/lang/String;
    .end local v3    # "installing":Ljava/io/File;
    throw v6

    .line 124
    .end local v7    # "started":J
    .end local v9    # "files":I
    .end local v10    # "marker":Ljava/io/OutputStream;
    .restart local v2    # "pack":[Ljava/lang/String;
    .restart local v3    # "installing":Ljava/io/File;
    :catchall_1
    move-exception v6

    invoke-virtual {v5}, Ljava/io/OutputStream;->close()V

    .end local v2    # "pack":[Ljava/lang/String;
    .end local v3    # "installing":Ljava/io/File;
    throw v6
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 142
    .end local v5    # "flag":Ljava/io/OutputStream;
    .restart local v2    # "pack":[Ljava/lang/String;
    .restart local v3    # "installing":Ljava/io/File;
    :catchall_2
    move-exception v0

    goto :goto_2

    .line 135
    :catch_0
    move-exception v5

    .line 138
    .local v5, "e":Ljava/lang/Exception;
    :try_start_5
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Could not install "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    aget-object v4, v2, v4

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v0, v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 142
    nop

    .end local v5    # "e":Ljava/lang/Exception;
    :goto_1
    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    .line 143
    nop

    .line 144
    .end local v2    # "pack":[Ljava/lang/String;
    .end local v3    # "installing":Ljava/io/File;
    goto/16 :goto_0

    .line 142
    .restart local v2    # "pack":[Ljava/lang/String;
    .restart local v3    # "installing":Ljava/io/File;
    :goto_2
    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    .line 143
    throw v0

    .line 145
    .end local v2    # "pack":[Ljava/lang/String;
    .end local v3    # "installing":Ljava/io/File;
    :cond_0
    return-void
.end method
