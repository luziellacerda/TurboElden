.class public final Lorg/emulationstation/frontend/HttpBridge;
.super Ljava/lang/Object;
.source "HttpBridge.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;,
        Lorg/emulationstation/frontend/HttpBridge$Request;,
        Lorg/emulationstation/frontend/HttpBridge$CancelledException;
    }
.end annotation


# static fields
.field private static final BUSY_RETRIES:I = 0x1e

.field private static final CONNECT_TIMEOUT:I = 0x3a98

.field private static final FILE_POOL:Ljava/util/concurrent/ExecutorService;

.field private static final IO_BUFFER:I = 0x40000

.field private static final MAX_REDIRECTS:I = 0x5

.field private static final NEXT_ID:Ljava/util/concurrent/atomic/AtomicInteger;

.field private static final PARALLEL_CONNECTIONS:I = 0x18

.field private static final PARALLEL_MIN_SIZE:J = 0x800000L

.field private static final POOL:Ljava/util/concurrent/ExecutorService;

.field private static final READ_TIMEOUT:I = 0x7530

.field private static final REQUESTS:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Ljava/lang/Integer;",
            "Lorg/emulationstation/frontend/HttpBridge$Request;",
            ">;"
        }
    .end annotation
.end field

.field private static final SEGMENT_READ_TIMEOUT:I = 0x2ee0

.field private static final SEGMENT_RETRIES:I = 0xc

.field private static final SEGMENT_RETRY_MAX_MS:J = 0x3a98L

.field public static final STATUS_BAD_STATUS:I = 0x3

.field public static final STATUS_INVALID:I = 0x4

.field public static final STATUS_IN_PROGRESS:I = 0x0

.field public static final STATUS_IO_ERROR:I = 0x2

.field public static final STATUS_SUCCESS:I = 0x1


# direct methods
.method static bridge synthetic -$$Nest$smdownloadRange(Ljava/lang/String;Ljava/nio/channels/FileChannel;JJLorg/emulationstation/frontend/HttpBridge$Request;)V
    .locals 0

    invoke-static/range {p0 .. p6}, Lorg/emulationstation/frontend/HttpBridge;->downloadRange(Ljava/lang/String;Ljava/nio/channels/FileChannel;JJLorg/emulationstation/frontend/HttpBridge$Request;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$smexecute(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/emulationstation/frontend/HttpBridge;->execute(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$smexecutePost(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/emulationstation/frontend/HttpBridge;->executePost(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$smextractAll(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/emulationstation/frontend/HttpBridge;->extractAll(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$smextractCores(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/emulationstation/frontend/HttpBridge;->extractCores(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 2

    .line 66
    const/4 v0, 0x4

    invoke-static {v0}, Ljava/util/concurrent/Executors;->newFixedThreadPool(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    sput-object v0, Lorg/emulationstation/frontend/HttpBridge;->POOL:Ljava/util/concurrent/ExecutorService;

    .line 71
    invoke-static {}, Ljava/util/concurrent/Executors;->newCachedThreadPool()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    sput-object v0, Lorg/emulationstation/frontend/HttpBridge;->FILE_POOL:Ljava/util/concurrent/ExecutorService;

    .line 73
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    sput-object v0, Lorg/emulationstation/frontend/HttpBridge;->REQUESTS:Ljava/util/concurrent/ConcurrentHashMap;

    .line 74
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    sput-object v0, Lorg/emulationstation/frontend/HttpBridge;->NEXT_ID:Ljava/util/concurrent/atomic/AtomicInteger;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 76
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static activeFileDownloads()Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;
    .locals 7

    .line 115
    new-instance v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;

    invoke-direct {v0}, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;-><init>()V

    .line 117
    .local v0, "snapshot":Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;
    sget-object v1, Lorg/emulationstation/frontend/HttpBridge;->REQUESTS:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lorg/emulationstation/frontend/HttpBridge$Request;

    .line 119
    .local v2, "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    iget-boolean v3, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->isFile:Z

    if-eqz v3, :cond_0

    iget-boolean v3, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->userCancelled:Z

    if-nez v3, :cond_0

    iget v3, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I

    if-eqz v3, :cond_1

    .line 120
    goto :goto_0

    .line 122
    :cond_1
    iget v3, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->count:I

    if-nez v3, :cond_2

    .line 123
    iget-object v3, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->title:Ljava/lang/String;

    iput-object v3, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->firstTitle:Ljava/lang/String;

    .line 125
    :cond_2
    iget v3, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->count:I

    add-int/lit8 v3, v3, 0x1

    iput v3, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->count:I

    .line 126
    iget-wide v3, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->downloaded:J

    iget-object v5, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->downloadedBytes:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v5

    add-long/2addr v3, v5

    iput-wide v3, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->downloaded:J

    .line 128
    iget-wide v3, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->total:J

    const-wide/16 v5, 0x0

    cmp-long v3, v3, v5

    if-ltz v3, :cond_4

    .line 129
    iget-wide v3, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->total:J

    cmp-long v3, v3, v5

    if-lez v3, :cond_3

    iget-wide v3, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->total:J

    iget-wide v5, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->total:J

    add-long/2addr v3, v5

    goto :goto_1

    :cond_3
    const-wide/16 v3, -0x1

    :goto_1
    iput-wide v3, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->total:J

    .line 130
    .end local v2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :cond_4
    goto :goto_0

    .line 132
    :cond_5
    return-object v0
.end method

.method public static cancel(I)V
    .locals 2
    .param p0, "id"    # I

    .line 918
    sget-object v0, Lorg/emulationstation/frontend/HttpBridge;->REQUESTS:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/emulationstation/frontend/HttpBridge$Request;

    .line 919
    .local v0, "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    if-eqz v0, :cond_0

    .line 921
    const/4 v1, 0x1

    iput-boolean v1, v0, Lorg/emulationstation/frontend/HttpBridge$Request;->userCancelled:Z

    .line 922
    iput-boolean v1, v0, Lorg/emulationstation/frontend/HttpBridge$Request;->cancelled:Z

    .line 924
    :cond_0
    return-void
.end method

.method public static content(I)[B
    .locals 2
    .param p0, "id"    # I

    .line 896
    sget-object v0, Lorg/emulationstation/frontend/HttpBridge;->REQUESTS:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/emulationstation/frontend/HttpBridge$Request;

    .line 897
    .local v0, "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    if-eqz v0, :cond_1

    iget-object v1, v0, Lorg/emulationstation/frontend/HttpBridge$Request;->content:[B

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    iget-object v1, v0, Lorg/emulationstation/frontend/HttpBridge$Request;->content:[B

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x0

    new-array v1, v1, [B

    :goto_1
    return-object v1
.end method

.method private static describeFailure(Ljava/lang/Throwable;)Ljava/lang/String;
    .locals 3
    .param p0, "e"    # Ljava/lang/Throwable;

    .line 632
    move-object v0, p0

    .local v0, "cause":Ljava/lang/Throwable;
    :goto_0
    if-eqz v0, :cond_6

    .line 634
    instance-of v1, v0, Ljava/net/UnknownHostException;

    if-eqz v1, :cond_0

    .line 635
    const-string v1, "sem internet: n\u00e3o foi poss\u00edvel encontrar o servidor"

    return-object v1

    .line 637
    :cond_0
    instance-of v1, v0, Ljava/net/SocketTimeoutException;

    if-eqz v1, :cond_1

    .line 638
    const-string v1, "o servidor demorou demais para responder"

    return-object v1

    .line 640
    :cond_1
    instance-of v1, v0, Ljava/net/ConnectException;

    if-nez v1, :cond_5

    instance-of v1, v0, Ljava/net/NoRouteToHostException;

    if-eqz v1, :cond_2

    goto :goto_1

    .line 643
    :cond_2
    instance-of v1, v0, Ljavax/net/ssl/SSLException;

    if-eqz v1, :cond_3

    .line 644
    const-string v1, "falha na conex\u00e3o segura com o servidor"

    return-object v1

    .line 646
    :cond_3
    instance-of v1, v0, Ljava/io/IOException;

    if-eqz v1, :cond_4

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_4

    .line 647
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    const-string v2, "ENOSPC"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_4

    .line 648
    const-string v1, "sem espa\u00e7o no armazenamento"

    return-object v1

    .line 632
    :cond_4
    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    goto :goto_0

    .line 641
    :cond_5
    :goto_1
    const-string v1, "n\u00e3o foi poss\u00edvel conectar ao servidor"

    return-object v1

    .line 651
    .end local v0    # "cause":Ljava/lang/Throwable;
    :cond_6
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_7

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    :cond_7
    move-object v0, p0

    :goto_2
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static downloadInParts(Ljava/lang/String;Ljava/io/File;Lorg/emulationstation/frontend/HttpBridge$Request;)V
    .locals 23
    .param p0, "url"    # Ljava/lang/String;
    .param p1, "part"    # Ljava/io/File;
    .param p2, "request"    # Lorg/emulationstation/frontend/HttpBridge$Request;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 559
    move-object/from16 v7, p2

    iget-wide v9, v7, Lorg/emulationstation/frontend/HttpBridge$Request;->total:J

    .line 560
    .local v9, "total":J
    const-wide/16 v0, 0x18

    add-long v2, v9, v0

    const-wide/16 v11, 0x1

    sub-long/2addr v2, v11

    div-long v13, v2, v0

    .line 562
    .local v13, "segment":J
    new-instance v0, Ljava/io/RandomAccessFile;

    const-string v1, "rw"

    move-object/from16 v15, p1

    invoke-direct {v0, v15, v1}, Ljava/io/RandomAccessFile;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v1, v0

    .line 563
    .local v1, "file":Ljava/io/RandomAccessFile;
    const/4 v0, 0x1

    new-array v8, v0, [Ljava/lang/Exception;

    .line 568
    .local v8, "failure":[Ljava/lang/Exception;
    :try_start_0
    invoke-virtual {v1, v9, v10}, Ljava/io/RandomAccessFile;->setLength(J)V

    .line 569
    invoke-virtual {v1}, Ljava/io/RandomAccessFile;->getChannel()Ljava/nio/channels/FileChannel;

    move-result-object v2

    .line 571
    .local v2, "channel":Ljava/nio/channels/FileChannel;
    const/16 v0, 0x18

    new-array v3, v0, [Ljava/lang/Thread;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 573
    .local v3, "workers":[Ljava/lang/Thread;
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_0
    if-ge v4, v0, :cond_1

    .line 575
    int-to-long v5, v4

    mul-long/2addr v5, v13

    .line 576
    .local v5, "start":J
    move-object/from16 v16, v1

    .end local v1    # "file":Ljava/io/RandomAccessFile;
    .local v16, "file":Ljava/io/RandomAccessFile;
    add-long v0, v5, v13

    :try_start_1
    invoke-static {v9, v10, v0, v1}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v0

    sub-long/2addr v0, v11

    .line 578
    .local v0, "end":J
    cmp-long v18, v5, v0

    if-lez v18, :cond_0

    .line 579
    move-object v12, v3

    move-wide/from16 v19, v9

    goto :goto_1

    .line 581
    :cond_0
    new-instance v11, Ljava/lang/Thread;

    move v12, v4

    move-wide/from16 v21, v0

    move-object v1, v3

    move-wide v3, v5

    move-wide/from16 v5, v21

    .end local v0    # "end":J
    .end local v4    # "i":I
    .local v1, "workers":[Ljava/lang/Thread;
    .local v3, "start":J
    .local v5, "end":J
    .local v12, "i":I
    new-instance v0, Lorg/emulationstation/frontend/HttpBridge$3;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/16 v17, 0x18

    move-wide/from16 v19, v9

    move v9, v12

    move-object v12, v1

    move-object/from16 v1, p0

    .end local v1    # "workers":[Ljava/lang/Thread;
    .local v9, "i":I
    .local v12, "workers":[Ljava/lang/Thread;
    .local v19, "total":J
    :try_start_2
    invoke-direct/range {v0 .. v8}, Lorg/emulationstation/frontend/HttpBridge$3;-><init>(Ljava/lang/String;Ljava/nio/channels/FileChannel;JJLorg/emulationstation/frontend/HttpBridge$Request;[Ljava/lang/Exception;)V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "Download-"

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v11, v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    aput-object v11, v12, v9

    .line 602
    aget-object v0, v12, v9

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 573
    .end local v3    # "start":J
    .end local v5    # "end":J
    add-int/lit8 v4, v9, 0x1

    move-object v3, v12

    move-object/from16 v1, v16

    move/from16 v0, v17

    move-wide/from16 v9, v19

    const-wide/16 v11, 0x1

    .end local v9    # "i":I
    .restart local v4    # "i":I
    goto :goto_0

    .line 613
    .end local v2    # "channel":Ljava/nio/channels/FileChannel;
    .end local v4    # "i":I
    .end local v12    # "workers":[Ljava/lang/Thread;
    .end local v19    # "total":J
    .local v9, "total":J
    :catchall_0
    move-exception v0

    move-wide/from16 v19, v9

    .end local v9    # "total":J
    .restart local v19    # "total":J
    goto :goto_3

    .line 573
    .end local v16    # "file":Ljava/io/RandomAccessFile;
    .end local v19    # "total":J
    .local v1, "file":Ljava/io/RandomAccessFile;
    .restart local v2    # "channel":Ljava/nio/channels/FileChannel;
    .local v3, "workers":[Ljava/lang/Thread;
    .restart local v4    # "i":I
    .restart local v9    # "total":J
    :cond_1
    move-object/from16 v16, v1

    move-object v12, v3

    move-wide/from16 v19, v9

    move v9, v4

    .line 605
    .end local v1    # "file":Ljava/io/RandomAccessFile;
    .end local v3    # "workers":[Ljava/lang/Thread;
    .end local v4    # "i":I
    .end local v9    # "total":J
    .restart local v12    # "workers":[Ljava/lang/Thread;
    .restart local v16    # "file":Ljava/io/RandomAccessFile;
    .restart local v19    # "total":J
    :goto_1
    array-length v0, v12

    const/4 v1, 0x0

    move v3, v1

    :goto_2
    if-ge v3, v0, :cond_3

    aget-object v4, v12, v3

    .line 607
    .local v4, "worker":Ljava/lang/Thread;
    if-eqz v4, :cond_2

    .line 608
    invoke-virtual {v4}, Ljava/lang/Thread;->join()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 605
    .end local v4    # "worker":Ljava/lang/Thread;
    :cond_2
    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    .line 613
    .end local v2    # "channel":Ljava/nio/channels/FileChannel;
    .end local v12    # "workers":[Ljava/lang/Thread;
    :cond_3
    invoke-virtual/range {v16 .. v16}, Ljava/io/RandomAccessFile;->close()V

    .line 614
    nop

    .line 616
    aget-object v0, v8, v1

    if-eqz v0, :cond_5

    .line 618
    aget-object v0, v8, v1

    instance-of v0, v0, Lorg/emulationstation/frontend/HttpBridge$CancelledException;

    if-eqz v0, :cond_4

    .line 619
    aget-object v0, v8, v1

    throw v0

    .line 621
    :cond_4
    new-instance v0, Ljava/lang/Exception;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "download em partes falhou: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    aget-object v3, v8, v1

    invoke-virtual {v3}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    aget-object v1, v8, v1

    invoke-direct {v0, v2, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    .line 624
    :cond_5
    iget-boolean v0, v7, Lorg/emulationstation/frontend/HttpBridge$Request;->cancelled:Z

    if-nez v0, :cond_6

    .line 626
    return-void

    .line 625
    :cond_6
    new-instance v0, Lorg/emulationstation/frontend/HttpBridge$CancelledException;

    invoke-direct {v0}, Lorg/emulationstation/frontend/HttpBridge$CancelledException;-><init>()V

    throw v0

    .line 613
    :catchall_1
    move-exception v0

    goto :goto_3

    .end local v16    # "file":Ljava/io/RandomAccessFile;
    .end local v19    # "total":J
    .restart local v1    # "file":Ljava/io/RandomAccessFile;
    .restart local v9    # "total":J
    :catchall_2
    move-exception v0

    move-object/from16 v16, v1

    move-wide/from16 v19, v9

    .end local v1    # "file":Ljava/io/RandomAccessFile;
    .end local v9    # "total":J
    .restart local v16    # "file":Ljava/io/RandomAccessFile;
    .restart local v19    # "total":J
    :goto_3
    invoke-virtual/range {v16 .. v16}, Ljava/io/RandomAccessFile;->close()V

    .line 614
    throw v0
.end method

.method private static downloadRange(Ljava/lang/String;Ljava/nio/channels/FileChannel;JJLorg/emulationstation/frontend/HttpBridge$Request;)V
    .locals 22
    .param p0, "url"    # Ljava/lang/String;
    .param p1, "channel"    # Ljava/nio/channels/FileChannel;
    .param p2, "start"    # J
    .param p4, "end"    # J
    .param p6, "request"    # Lorg/emulationstation/frontend/HttpBridge$Request;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 656
    move-wide/from16 v1, p4

    move-object/from16 v3, p6

    const-string v4, "-"

    const-string v5, "EmulationStation"

    move-wide/from16 v6, p2

    .line 657
    .local v6, "position":J
    const/4 v0, 0x0

    .line 658
    .local v0, "attempt":I
    const/4 v8, 0x0

    .line 659
    .local v8, "busy":I
    const/high16 v9, 0x40000

    new-array v9, v9, [B

    move v10, v8

    move-wide v7, v6

    move v6, v0

    .line 661
    .end local v0    # "attempt":I
    .end local v8    # "busy":I
    .local v6, "attempt":I
    .local v7, "position":J
    .local v9, "buffer":[B
    .local v10, "busy":I
    :goto_0
    cmp-long v0, v7, v1

    if-gtz v0, :cond_f

    .line 663
    iget-boolean v0, v3, Lorg/emulationstation/frontend/HttpBridge$Request;->cancelled:Z

    if-nez v0, :cond_e

    .line 666
    const/4 v11, 0x0

    .line 670
    .local v11, "connection":Ljava/net/HttpURLConnection;
    :try_start_0
    new-instance v0, Ljava/net/URL;
    :try_end_0
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_0 .. :try_end_0} :catch_14
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_13
    .catchall {:try_start_0 .. :try_end_0} :catchall_9

    move-object/from16 v12, p0

    :try_start_1
    invoke-direct {v0, v12}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v0

    check-cast v0, Ljava/net/HttpURLConnection;
    :try_end_1
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_1 .. :try_end_1} :catch_12
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_13
    .catchall {:try_start_1 .. :try_end_1} :catchall_9

    move-object v11, v0

    .line 671
    const/16 v0, 0x3a98

    :try_start_2
    invoke-virtual {v11, v0}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    .line 672
    const/16 v0, 0x2ee0

    invoke-virtual {v11, v0}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    .line 673
    const-string v0, "User-Agent"

    invoke-virtual {v11, v0, v5}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 674
    const-string v0, "Accept-Encoding"

    const-string v13, "identity"

    invoke-virtual {v11, v0, v13}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 675
    const-string v0, "Range"

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const-string v14, "bytes="

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v11, v0, v13}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 677
    invoke-virtual {v11}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0
    :try_end_2
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_2 .. :try_end_2} :catch_11
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_10
    .catchall {:try_start_2 .. :try_end_2} :catchall_8

    .line 681
    .local v0, "code":I
    const/16 v13, 0x1ad

    if-eq v0, v13, :cond_8

    const/16 v13, 0x1f7

    if-ne v0, v13, :cond_0

    move-object/from16 v15, p1

    move-object/from16 v17, v9

    move/from16 v20, v10

    move-object/from16 v21, v11

    goto/16 :goto_4

    .line 693
    :cond_0
    const/16 v13, 0xce

    if-ne v0, v13, :cond_7

    .line 696
    :try_start_3
    invoke-virtual {v11}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v13
    :try_end_3
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_3 .. :try_end_3} :catch_9
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_8
    .catchall {:try_start_3 .. :try_end_3} :catchall_4

    .line 699
    .local v13, "in":Ljava/io/InputStream;
    :goto_1
    cmp-long v14, v7, v1

    if-gtz v14, :cond_4

    :try_start_4
    array-length v14, v9
    :try_end_4
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_4 .. :try_end_4} :catch_5
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    int-to-long v14, v14

    sub-long v16, v1, v7

    const-wide/16 v18, 0x1

    move/from16 v20, v10

    move-object/from16 v21, v11

    .end local v10    # "busy":I
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .local v20, "busy":I
    .local v21, "connection":Ljava/net/HttpURLConnection;
    add-long v10, v16, v18

    :try_start_5
    invoke-static {v14, v15, v10, v11}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v10

    long-to-int v10, v10

    const/4 v11, 0x0

    invoke-virtual {v13, v9, v11, v10}, Ljava/io/InputStream;->read([BII)I

    move-result v10

    move v14, v10

    .local v14, "read":I
    if-lez v10, :cond_3

    .line 701
    iget-boolean v10, v3, Lorg/emulationstation/frontend/HttpBridge$Request;->cancelled:Z

    if-nez v10, :cond_2

    .line 704
    invoke-static {v9, v11, v14}, Ljava/nio/ByteBuffer;->wrap([BII)Ljava/nio/ByteBuffer;

    move-result-object v10

    .line 705
    .local v10, "chunk":Ljava/nio/ByteBuffer;
    move-wide v15, v7

    move-wide v11, v15

    .line 706
    .local v11, "at":J
    :goto_2
    invoke-virtual {v10}, Ljava/nio/ByteBuffer;->hasRemaining()Z

    move-result v15
    :try_end_5
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_5 .. :try_end_5} :catch_3
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_2
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    if-eqz v15, :cond_1

    .line 707
    move-object/from16 v15, p1

    move/from16 v16, v6

    .end local v6    # "attempt":I
    .local v16, "attempt":I
    :try_start_6
    invoke-virtual {v15, v10, v11, v12}, Ljava/nio/channels/FileChannel;->write(Ljava/nio/ByteBuffer;J)I

    move-result v6
    :try_end_6
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_6 .. :try_end_6} :catch_1
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    move-object/from16 v17, v9

    move-object/from16 v18, v10

    .end local v9    # "buffer":[B
    .end local v10    # "chunk":Ljava/nio/ByteBuffer;
    .local v17, "buffer":[B
    .local v18, "chunk":Ljava/nio/ByteBuffer;
    int-to-long v9, v6

    add-long/2addr v11, v9

    move/from16 v6, v16

    move-object/from16 v9, v17

    move-object/from16 v10, v18

    goto :goto_2

    .line 742
    .end local v0    # "code":I
    .end local v11    # "at":J
    .end local v13    # "in":Ljava/io/InputStream;
    .end local v14    # "read":I
    .end local v17    # "buffer":[B
    .end local v18    # "chunk":Ljava/nio/ByteBuffer;
    .restart local v9    # "buffer":[B
    :catchall_0
    move-exception v0

    move-object/from16 v17, v9

    move-wide/from16 v13, p2

    move/from16 v6, v16

    move/from16 v10, v20

    move-object/from16 v11, v21

    .end local v9    # "buffer":[B
    .restart local v17    # "buffer":[B
    goto/16 :goto_8

    .line 726
    .end local v17    # "buffer":[B
    .restart local v9    # "buffer":[B
    :catch_0
    move-exception v0

    move-object/from16 v17, v9

    move/from16 v6, v16

    move/from16 v10, v20

    move-object/from16 v11, v21

    .end local v9    # "buffer":[B
    .restart local v17    # "buffer":[B
    goto/16 :goto_5

    .line 722
    .end local v17    # "buffer":[B
    .restart local v9    # "buffer":[B
    :catch_1
    move-exception v0

    move-object/from16 v17, v9

    move-wide/from16 v13, p2

    move/from16 v6, v16

    move/from16 v10, v20

    move-object/from16 v11, v21

    .end local v9    # "buffer":[B
    .restart local v17    # "buffer":[B
    goto/16 :goto_7

    .line 709
    .end local v16    # "attempt":I
    .end local v17    # "buffer":[B
    .restart local v0    # "code":I
    .restart local v6    # "attempt":I
    .restart local v9    # "buffer":[B
    .restart local v10    # "chunk":Ljava/nio/ByteBuffer;
    .restart local v11    # "at":J
    .restart local v13    # "in":Ljava/io/InputStream;
    .restart local v14    # "read":I
    :cond_1
    move-object/from16 v15, p1

    move/from16 v16, v6

    move-object/from16 v17, v9

    move-object/from16 v18, v10

    .end local v6    # "attempt":I
    .end local v9    # "buffer":[B
    .end local v10    # "chunk":Ljava/nio/ByteBuffer;
    .restart local v16    # "attempt":I
    .restart local v17    # "buffer":[B
    .restart local v18    # "chunk":Ljava/nio/ByteBuffer;
    int-to-long v9, v14

    add-long/2addr v7, v9

    .line 710
    :try_start_7
    iget-object v6, v3, Lorg/emulationstation/frontend/HttpBridge$Request;->downloadedBytes:Ljava/util/concurrent/atomic/AtomicLong;

    int-to-long v9, v14

    invoke-virtual {v6, v9, v10}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    .line 714
    const/4 v6, 0x0

    .line 715
    .end local v11    # "at":J
    .end local v16    # "attempt":I
    .end local v18    # "chunk":Ljava/nio/ByteBuffer;
    .restart local v6    # "attempt":I
    move-object/from16 v12, p0

    move-object/from16 v9, v17

    move/from16 v10, v20

    move-object/from16 v11, v21

    goto/16 :goto_1

    .line 702
    .end local v17    # "buffer":[B
    .restart local v9    # "buffer":[B
    :cond_2
    move-object/from16 v15, p1

    move/from16 v16, v6

    move-object/from16 v17, v9

    .end local v6    # "attempt":I
    .end local v9    # "buffer":[B
    .restart local v16    # "attempt":I
    .restart local v17    # "buffer":[B
    new-instance v6, Lorg/emulationstation/frontend/HttpBridge$CancelledException;

    invoke-direct {v6}, Lorg/emulationstation/frontend/HttpBridge$CancelledException;-><init>()V

    .end local v7    # "position":J
    .end local v16    # "attempt":I
    .end local v17    # "buffer":[B
    .end local v20    # "busy":I
    .end local v21    # "connection":Ljava/net/HttpURLConnection;
    .end local p0    # "url":Ljava/lang/String;
    .end local p1    # "channel":Ljava/nio/channels/FileChannel;
    .end local p2    # "start":J
    .end local p4    # "end":J
    .end local p6    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    throw v6

    .line 699
    .restart local v6    # "attempt":I
    .restart local v7    # "position":J
    .restart local v9    # "buffer":[B
    .restart local v20    # "busy":I
    .restart local v21    # "connection":Ljava/net/HttpURLConnection;
    .restart local p0    # "url":Ljava/lang/String;
    .restart local p1    # "channel":Ljava/nio/channels/FileChannel;
    .restart local p2    # "start":J
    .restart local p4    # "end":J
    .restart local p6    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :cond_3
    move-object/from16 v15, p1

    move/from16 v16, v6

    move-object/from16 v17, v9

    .end local v6    # "attempt":I
    .end local v9    # "buffer":[B
    .restart local v16    # "attempt":I
    .restart local v17    # "buffer":[B
    goto/16 :goto_3

    .line 742
    .end local v0    # "code":I
    .end local v13    # "in":Ljava/io/InputStream;
    .end local v14    # "read":I
    .end local v16    # "attempt":I
    .end local v17    # "buffer":[B
    .restart local v6    # "attempt":I
    .restart local v9    # "buffer":[B
    :catchall_1
    move-exception v0

    move-object/from16 v15, p1

    move/from16 v16, v6

    move-object/from16 v17, v9

    move-wide/from16 v13, p2

    move/from16 v10, v20

    move-object/from16 v11, v21

    .end local v6    # "attempt":I
    .end local v9    # "buffer":[B
    .restart local v16    # "attempt":I
    .restart local v17    # "buffer":[B
    goto/16 :goto_8

    .line 726
    .end local v16    # "attempt":I
    .end local v17    # "buffer":[B
    .restart local v6    # "attempt":I
    .restart local v9    # "buffer":[B
    :catch_2
    move-exception v0

    move-object/from16 v15, p1

    move/from16 v16, v6

    move-object/from16 v17, v9

    move/from16 v10, v20

    move-object/from16 v11, v21

    .end local v6    # "attempt":I
    .end local v9    # "buffer":[B
    .restart local v16    # "attempt":I
    .restart local v17    # "buffer":[B
    goto/16 :goto_5

    .line 722
    .end local v16    # "attempt":I
    .end local v17    # "buffer":[B
    .restart local v6    # "attempt":I
    .restart local v9    # "buffer":[B
    :catch_3
    move-exception v0

    move-object/from16 v15, p1

    move/from16 v16, v6

    move-object/from16 v17, v9

    move-wide/from16 v13, p2

    move/from16 v10, v20

    move-object/from16 v11, v21

    .end local v6    # "attempt":I
    .end local v9    # "buffer":[B
    .restart local v16    # "attempt":I
    .restart local v17    # "buffer":[B
    goto/16 :goto_7

    .line 742
    .end local v16    # "attempt":I
    .end local v17    # "buffer":[B
    .end local v20    # "busy":I
    .end local v21    # "connection":Ljava/net/HttpURLConnection;
    .restart local v6    # "attempt":I
    .restart local v9    # "buffer":[B
    .local v10, "busy":I
    .local v11, "connection":Ljava/net/HttpURLConnection;
    :catchall_2
    move-exception v0

    move-object/from16 v15, p1

    move/from16 v16, v6

    move-object/from16 v17, v9

    move/from16 v20, v10

    move-object/from16 v21, v11

    move-wide/from16 v13, p2

    .end local v6    # "attempt":I
    .end local v9    # "buffer":[B
    .end local v10    # "busy":I
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v16    # "attempt":I
    .restart local v17    # "buffer":[B
    .restart local v20    # "busy":I
    .restart local v21    # "connection":Ljava/net/HttpURLConnection;
    goto/16 :goto_8

    .line 726
    .end local v16    # "attempt":I
    .end local v17    # "buffer":[B
    .end local v20    # "busy":I
    .end local v21    # "connection":Ljava/net/HttpURLConnection;
    .restart local v6    # "attempt":I
    .restart local v9    # "buffer":[B
    .restart local v10    # "busy":I
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    :catch_4
    move-exception v0

    move-object/from16 v15, p1

    move/from16 v16, v6

    move-object/from16 v17, v9

    move/from16 v20, v10

    move-object/from16 v21, v11

    .end local v6    # "attempt":I
    .end local v9    # "buffer":[B
    .end local v10    # "busy":I
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v16    # "attempt":I
    .restart local v17    # "buffer":[B
    .restart local v20    # "busy":I
    .restart local v21    # "connection":Ljava/net/HttpURLConnection;
    goto/16 :goto_5

    .line 722
    .end local v16    # "attempt":I
    .end local v17    # "buffer":[B
    .end local v20    # "busy":I
    .end local v21    # "connection":Ljava/net/HttpURLConnection;
    .restart local v6    # "attempt":I
    .restart local v9    # "buffer":[B
    .restart local v10    # "busy":I
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    :catch_5
    move-exception v0

    move-object/from16 v15, p1

    move/from16 v16, v6

    move-object/from16 v17, v9

    move/from16 v20, v10

    move-object/from16 v21, v11

    move-wide/from16 v13, p2

    .end local v6    # "attempt":I
    .end local v9    # "buffer":[B
    .end local v10    # "busy":I
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v16    # "attempt":I
    .restart local v17    # "buffer":[B
    .restart local v20    # "busy":I
    .restart local v21    # "connection":Ljava/net/HttpURLConnection;
    goto/16 :goto_7

    .line 699
    .end local v16    # "attempt":I
    .end local v17    # "buffer":[B
    .end local v20    # "busy":I
    .end local v21    # "connection":Ljava/net/HttpURLConnection;
    .restart local v0    # "code":I
    .restart local v6    # "attempt":I
    .restart local v9    # "buffer":[B
    .restart local v10    # "busy":I
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v13    # "in":Ljava/io/InputStream;
    :cond_4
    move-object/from16 v15, p1

    move/from16 v16, v6

    move-object/from16 v17, v9

    move/from16 v20, v10

    move-object/from16 v21, v11

    .line 717
    .end local v6    # "attempt":I
    .end local v9    # "buffer":[B
    .end local v10    # "busy":I
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v16    # "attempt":I
    .restart local v17    # "buffer":[B
    .restart local v20    # "busy":I
    .restart local v21    # "connection":Ljava/net/HttpURLConnection;
    :goto_3
    invoke-virtual {v13}, Ljava/io/InputStream;->close()V
    :try_end_7
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_7 .. :try_end_7} :catch_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_6
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 719
    cmp-long v6, v7, v1

    if-lez v6, :cond_6

    .line 742
    .end local v0    # "code":I
    .end local v13    # "in":Ljava/io/InputStream;
    if-eqz v21, :cond_5

    .line 743
    invoke-virtual/range {v21 .. v21}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 745
    .end local v21    # "connection":Ljava/net/HttpURLConnection;
    :cond_5
    move-wide/from16 v13, p2

    move/from16 v6, v16

    move/from16 v10, v20

    goto/16 :goto_6

    .line 720
    .restart local v0    # "code":I
    .restart local v13    # "in":Ljava/io/InputStream;
    .restart local v21    # "connection":Ljava/net/HttpURLConnection;
    :cond_6
    :try_start_8
    new-instance v6, Ljava/io/IOException;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "connection closed at "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, " of "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-direct {v6, v9}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .end local v7    # "position":J
    .end local v16    # "attempt":I
    .end local v17    # "buffer":[B
    .end local v20    # "busy":I
    .end local v21    # "connection":Ljava/net/HttpURLConnection;
    .end local p0    # "url":Ljava/lang/String;
    .end local p1    # "channel":Ljava/nio/channels/FileChannel;
    .end local p2    # "start":J
    .end local p4    # "end":J
    .end local p6    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    throw v6
    :try_end_8
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_8 .. :try_end_8} :catch_7
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_6
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    .line 742
    .end local v0    # "code":I
    .end local v13    # "in":Ljava/io/InputStream;
    .restart local v7    # "position":J
    .restart local v16    # "attempt":I
    .restart local v17    # "buffer":[B
    .restart local v20    # "busy":I
    .restart local v21    # "connection":Ljava/net/HttpURLConnection;
    .restart local p0    # "url":Ljava/lang/String;
    .restart local p1    # "channel":Ljava/nio/channels/FileChannel;
    .restart local p2    # "start":J
    .restart local p4    # "end":J
    .restart local p6    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :catchall_3
    move-exception v0

    move-wide/from16 v13, p2

    move/from16 v6, v16

    move/from16 v10, v20

    move-object/from16 v11, v21

    goto/16 :goto_8

    .line 726
    :catch_6
    move-exception v0

    move/from16 v6, v16

    move/from16 v10, v20

    move-object/from16 v11, v21

    goto/16 :goto_5

    .line 722
    :catch_7
    move-exception v0

    move-wide/from16 v13, p2

    move/from16 v6, v16

    move/from16 v10, v20

    move-object/from16 v11, v21

    goto/16 :goto_7

    .line 742
    .end local v16    # "attempt":I
    .end local v17    # "buffer":[B
    .end local v20    # "busy":I
    .end local v21    # "connection":Ljava/net/HttpURLConnection;
    .restart local v6    # "attempt":I
    .restart local v9    # "buffer":[B
    .restart local v10    # "busy":I
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    :catchall_4
    move-exception v0

    move-object/from16 v15, p1

    move-object/from16 v17, v9

    move/from16 v20, v10

    move-object/from16 v21, v11

    move-wide/from16 v13, p2

    .end local v9    # "buffer":[B
    .end local v10    # "busy":I
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v17    # "buffer":[B
    .restart local v20    # "busy":I
    .restart local v21    # "connection":Ljava/net/HttpURLConnection;
    goto/16 :goto_8

    .line 726
    .end local v17    # "buffer":[B
    .end local v20    # "busy":I
    .end local v21    # "connection":Ljava/net/HttpURLConnection;
    .restart local v9    # "buffer":[B
    .restart local v10    # "busy":I
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    :catch_8
    move-exception v0

    move-object/from16 v15, p1

    move-object/from16 v17, v9

    move/from16 v20, v10

    move-object/from16 v21, v11

    .end local v9    # "buffer":[B
    .end local v10    # "busy":I
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v17    # "buffer":[B
    .restart local v20    # "busy":I
    .restart local v21    # "connection":Ljava/net/HttpURLConnection;
    goto/16 :goto_5

    .line 722
    .end local v17    # "buffer":[B
    .end local v20    # "busy":I
    .end local v21    # "connection":Ljava/net/HttpURLConnection;
    .restart local v9    # "buffer":[B
    .restart local v10    # "busy":I
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    :catch_9
    move-exception v0

    move-object/from16 v15, p1

    move-object/from16 v17, v9

    move/from16 v20, v10

    move-object/from16 v21, v11

    move-wide/from16 v13, p2

    .end local v9    # "buffer":[B
    .end local v10    # "busy":I
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v17    # "buffer":[B
    .restart local v20    # "busy":I
    .restart local v21    # "connection":Ljava/net/HttpURLConnection;
    goto/16 :goto_7

    .line 694
    .end local v17    # "buffer":[B
    .end local v20    # "busy":I
    .end local v21    # "connection":Ljava/net/HttpURLConnection;
    .restart local v0    # "code":I
    .restart local v9    # "buffer":[B
    .restart local v10    # "busy":I
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    :cond_7
    move-object/from16 v15, p1

    move-object/from16 v17, v9

    move/from16 v20, v10

    move-object/from16 v21, v11

    .end local v9    # "buffer":[B
    .end local v10    # "busy":I
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v17    # "buffer":[B
    .restart local v20    # "busy":I
    .restart local v21    # "connection":Ljava/net/HttpURLConnection;
    :try_start_9
    new-instance v9, Ljava/lang/Exception;

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "HTTP "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, " numa faixa (servidor ignorou Range)"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-direct {v9, v10}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .end local v6    # "attempt":I
    .end local v7    # "position":J
    .end local v17    # "buffer":[B
    .end local v20    # "busy":I
    .end local v21    # "connection":Ljava/net/HttpURLConnection;
    .end local p0    # "url":Ljava/lang/String;
    .end local p1    # "channel":Ljava/nio/channels/FileChannel;
    .end local p2    # "start":J
    .end local p4    # "end":J
    .end local p6    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    throw v9
    :try_end_9
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_9 .. :try_end_9} :catch_b
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_a
    .catchall {:try_start_9 .. :try_end_9} :catchall_5

    .line 742
    .end local v0    # "code":I
    .restart local v6    # "attempt":I
    .restart local v7    # "position":J
    .restart local v17    # "buffer":[B
    .restart local v20    # "busy":I
    .restart local v21    # "connection":Ljava/net/HttpURLConnection;
    .restart local p0    # "url":Ljava/lang/String;
    .restart local p1    # "channel":Ljava/nio/channels/FileChannel;
    .restart local p2    # "start":J
    .restart local p4    # "end":J
    .restart local p6    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :catchall_5
    move-exception v0

    move-wide/from16 v13, p2

    move/from16 v10, v20

    move-object/from16 v11, v21

    goto/16 :goto_8

    .line 726
    :catch_a
    move-exception v0

    move/from16 v10, v20

    move-object/from16 v11, v21

    goto/16 :goto_5

    .line 722
    :catch_b
    move-exception v0

    move-wide/from16 v13, p2

    move/from16 v10, v20

    move-object/from16 v11, v21

    goto/16 :goto_7

    .line 681
    .end local v17    # "buffer":[B
    .end local v20    # "busy":I
    .end local v21    # "connection":Ljava/net/HttpURLConnection;
    .restart local v0    # "code":I
    .restart local v9    # "buffer":[B
    .restart local v10    # "busy":I
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    :cond_8
    move-object/from16 v15, p1

    move-object/from16 v17, v9

    move/from16 v20, v10

    move-object/from16 v21, v11

    .line 683
    .end local v9    # "buffer":[B
    .end local v10    # "busy":I
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v17    # "buffer":[B
    .restart local v20    # "busy":I
    .restart local v21    # "connection":Ljava/net/HttpURLConnection;
    :goto_4
    :try_start_a
    invoke-virtual/range {v21 .. v21}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_a
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_a .. :try_end_a} :catch_f
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_e
    .catchall {:try_start_a .. :try_end_a} :catchall_7

    .line 684
    const/4 v11, 0x0

    .line 686
    .end local v21    # "connection":Ljava/net/HttpURLConnection;
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    add-int/lit8 v10, v20, 0x1

    .end local v20    # "busy":I
    .restart local v10    # "busy":I
    const/16 v9, 0x1e

    if-gt v10, v9, :cond_a

    .line 689
    const-wide/16 v18, 0x2bc

    int-to-long v12, v10

    mul-long v12, v12, v18

    move v9, v6

    move-wide/from16 v18, v7

    .end local v6    # "attempt":I
    .end local v7    # "position":J
    .local v9, "attempt":I
    .local v18, "position":J
    const-wide/16 v6, 0x1388

    :try_start_b
    invoke-static {v6, v7, v12, v13}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v6

    invoke-static {v6, v7}, Ljava/lang/Thread;->sleep(J)V
    :try_end_b
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_b .. :try_end_b} :catch_d
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_c
    .catchall {:try_start_b .. :try_end_b} :catchall_6

    .line 742
    if-eqz v11, :cond_9

    .line 743
    invoke-virtual {v11}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 661
    .end local v0    # "code":I
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    :cond_9
    move v6, v9

    move-object/from16 v9, v17

    move-wide/from16 v7, v18

    goto/16 :goto_0

    .line 742
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    :catchall_6
    move-exception v0

    move-wide/from16 v13, p2

    move v6, v9

    move-wide/from16 v7, v18

    goto/16 :goto_8

    .line 726
    :catch_c
    move-exception v0

    move v6, v9

    move-wide/from16 v7, v18

    goto/16 :goto_5

    .line 722
    :catch_d
    move-exception v0

    move-wide/from16 v13, p2

    move v6, v9

    move-wide/from16 v7, v18

    goto/16 :goto_7

    .line 687
    .end local v9    # "attempt":I
    .end local v18    # "position":J
    .restart local v0    # "code":I
    .restart local v6    # "attempt":I
    .restart local v7    # "position":J
    :cond_a
    move v9, v6

    move-wide/from16 v18, v7

    .end local v6    # "attempt":I
    .end local v7    # "position":J
    .restart local v9    # "attempt":I
    .restart local v18    # "position":J
    :try_start_c
    new-instance v6, Ljava/lang/Exception;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "servidor ocupado (HTTP "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, ")"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .end local v9    # "attempt":I
    .end local v10    # "busy":I
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v17    # "buffer":[B
    .end local v18    # "position":J
    .end local p0    # "url":Ljava/lang/String;
    .end local p1    # "channel":Ljava/nio/channels/FileChannel;
    .end local p2    # "start":J
    .end local p4    # "end":J
    .end local p6    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    throw v6
    :try_end_c
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_c .. :try_end_c} :catch_d
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_c
    .catchall {:try_start_c .. :try_end_c} :catchall_6

    .line 742
    .end local v0    # "code":I
    .restart local v6    # "attempt":I
    .restart local v7    # "position":J
    .restart local v17    # "buffer":[B
    .restart local v20    # "busy":I
    .restart local v21    # "connection":Ljava/net/HttpURLConnection;
    .restart local p0    # "url":Ljava/lang/String;
    .restart local p1    # "channel":Ljava/nio/channels/FileChannel;
    .restart local p2    # "start":J
    .restart local p4    # "end":J
    .restart local p6    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :catchall_7
    move-exception v0

    move v9, v6

    move-wide/from16 v18, v7

    move-wide/from16 v13, p2

    move/from16 v10, v20

    move-object/from16 v11, v21

    .end local v6    # "attempt":I
    .end local v7    # "position":J
    .restart local v9    # "attempt":I
    .restart local v18    # "position":J
    goto/16 :goto_8

    .line 726
    .end local v9    # "attempt":I
    .end local v18    # "position":J
    .restart local v6    # "attempt":I
    .restart local v7    # "position":J
    :catch_e
    move-exception v0

    move v9, v6

    move-wide/from16 v18, v7

    move/from16 v10, v20

    move-object/from16 v11, v21

    .end local v6    # "attempt":I
    .end local v7    # "position":J
    .restart local v9    # "attempt":I
    .restart local v18    # "position":J
    goto/16 :goto_5

    .line 722
    .end local v9    # "attempt":I
    .end local v18    # "position":J
    .restart local v6    # "attempt":I
    .restart local v7    # "position":J
    :catch_f
    move-exception v0

    move v9, v6

    move-wide/from16 v18, v7

    move-wide/from16 v13, p2

    move/from16 v10, v20

    move-object/from16 v11, v21

    .end local v6    # "attempt":I
    .end local v7    # "position":J
    .restart local v9    # "attempt":I
    .restart local v18    # "position":J
    goto/16 :goto_7

    .line 742
    .end local v17    # "buffer":[B
    .end local v18    # "position":J
    .end local v20    # "busy":I
    .end local v21    # "connection":Ljava/net/HttpURLConnection;
    .restart local v6    # "attempt":I
    .restart local v7    # "position":J
    .local v9, "buffer":[B
    .restart local v10    # "busy":I
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    :catchall_8
    move-exception v0

    move-object/from16 v15, p1

    move-wide/from16 v18, v7

    move-object/from16 v17, v9

    move/from16 v20, v10

    move-object/from16 v21, v11

    move v9, v6

    move-wide/from16 v13, p2

    .end local v6    # "attempt":I
    .end local v7    # "position":J
    .end local v10    # "busy":I
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .local v9, "attempt":I
    .restart local v17    # "buffer":[B
    .restart local v18    # "position":J
    .restart local v20    # "busy":I
    .restart local v21    # "connection":Ljava/net/HttpURLConnection;
    goto/16 :goto_8

    .line 726
    .end local v17    # "buffer":[B
    .end local v18    # "position":J
    .end local v20    # "busy":I
    .end local v21    # "connection":Ljava/net/HttpURLConnection;
    .restart local v6    # "attempt":I
    .restart local v7    # "position":J
    .local v9, "buffer":[B
    .restart local v10    # "busy":I
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    :catch_10
    move-exception v0

    move-object/from16 v15, p1

    move-wide/from16 v18, v7

    move-object/from16 v17, v9

    move/from16 v20, v10

    move-object/from16 v21, v11

    move v9, v6

    .end local v6    # "attempt":I
    .end local v7    # "position":J
    .end local v10    # "busy":I
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .local v9, "attempt":I
    .restart local v17    # "buffer":[B
    .restart local v18    # "position":J
    .restart local v20    # "busy":I
    .restart local v21    # "connection":Ljava/net/HttpURLConnection;
    goto :goto_5

    .line 722
    .end local v17    # "buffer":[B
    .end local v18    # "position":J
    .end local v20    # "busy":I
    .end local v21    # "connection":Ljava/net/HttpURLConnection;
    .restart local v6    # "attempt":I
    .restart local v7    # "position":J
    .local v9, "buffer":[B
    .restart local v10    # "busy":I
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    :catch_11
    move-exception v0

    move-object/from16 v15, p1

    move-wide/from16 v18, v7

    move-object/from16 v17, v9

    move/from16 v20, v10

    move-object/from16 v21, v11

    move v9, v6

    move-wide/from16 v13, p2

    .end local v6    # "attempt":I
    .end local v7    # "position":J
    .end local v10    # "busy":I
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .local v9, "attempt":I
    .restart local v17    # "buffer":[B
    .restart local v18    # "position":J
    .restart local v20    # "busy":I
    .restart local v21    # "connection":Ljava/net/HttpURLConnection;
    goto/16 :goto_7

    .end local v17    # "buffer":[B
    .end local v18    # "position":J
    .end local v20    # "busy":I
    .end local v21    # "connection":Ljava/net/HttpURLConnection;
    .restart local v6    # "attempt":I
    .restart local v7    # "position":J
    .local v9, "buffer":[B
    .restart local v10    # "busy":I
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    :catch_12
    move-exception v0

    move-object/from16 v15, p1

    move-wide/from16 v18, v7

    move-object/from16 v17, v9

    move/from16 v20, v10

    move v9, v6

    move-wide/from16 v13, p2

    goto/16 :goto_7

    .line 742
    :catchall_9
    move-exception v0

    move-object/from16 v15, p1

    move-wide/from16 v18, v7

    move-object/from16 v17, v9

    move/from16 v20, v10

    move v9, v6

    move-wide/from16 v13, p2

    .end local v6    # "attempt":I
    .end local v7    # "position":J
    .end local v10    # "busy":I
    .local v9, "attempt":I
    .restart local v17    # "buffer":[B
    .restart local v18    # "position":J
    .restart local v20    # "busy":I
    goto/16 :goto_8

    .line 726
    .end local v17    # "buffer":[B
    .end local v18    # "position":J
    .end local v20    # "busy":I
    .restart local v6    # "attempt":I
    .restart local v7    # "position":J
    .local v9, "buffer":[B
    .restart local v10    # "busy":I
    :catch_13
    move-exception v0

    move-object/from16 v15, p1

    move-wide/from16 v18, v7

    move-object/from16 v17, v9

    move/from16 v20, v10

    move v9, v6

    .line 731
    .end local v9    # "buffer":[B
    .local v0, "e":Ljava/lang/Exception;
    .restart local v17    # "buffer":[B
    :goto_5
    add-int/lit8 v6, v6, 0x1

    const/16 v9, 0xc

    if-gt v6, v9, :cond_c

    .line 734
    add-int/lit8 v9, v6, -0x1

    const/16 v12, 0x10

    :try_start_d
    invoke-static {v9, v12}, Ljava/lang/Math;->min(II)I

    move-result v9
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_b

    const-wide/16 v12, 0x1f4

    shl-long/2addr v12, v9

    move v14, v10

    .end local v10    # "busy":I
    .local v14, "busy":I
    const-wide/16 v9, 0x3a98

    :try_start_e
    invoke-static {v9, v10, v12, v13}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v9

    .line 736
    .local v9, "wait":J
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "Range "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_a

    move/from16 v16, v14

    move-wide/from16 v13, p2

    .end local v14    # "busy":I
    .local v16, "busy":I
    :try_start_f
    invoke-virtual {v12, v13, v14}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object/from16 v18, v0

    .end local v0    # "e":Ljava/lang/Exception;
    .local v18, "e":Ljava/lang/Exception;
    const-string v0, " retry "

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v12, " at "

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v12, " in "

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v12, "ms: "

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 737
    invoke-virtual/range {v18 .. v18}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 736
    invoke-static {v5, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 738
    invoke-static {v9, v10}, Ljava/lang/Thread;->sleep(J)V
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_c

    .line 742
    .end local v9    # "wait":J
    .end local v18    # "e":Ljava/lang/Exception;
    if-eqz v11, :cond_b

    .line 743
    invoke-virtual {v11}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 745
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    :cond_b
    move/from16 v10, v16

    .end local v16    # "busy":I
    .restart local v10    # "busy":I
    :goto_6
    move-object/from16 v9, v17

    goto/16 :goto_0

    .line 742
    .end local v10    # "busy":I
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v14    # "busy":I
    :catchall_a
    move-exception v0

    move/from16 v16, v14

    move-wide/from16 v13, p2

    move/from16 v10, v16

    .end local v14    # "busy":I
    .restart local v16    # "busy":I
    goto :goto_8

    .end local v16    # "busy":I
    .restart local v10    # "busy":I
    :catchall_b
    move-exception v0

    move-wide/from16 v13, p2

    move/from16 v16, v10

    .end local v10    # "busy":I
    .restart local v16    # "busy":I
    goto :goto_8

    .line 732
    .end local v16    # "busy":I
    .restart local v0    # "e":Ljava/lang/Exception;
    .restart local v10    # "busy":I
    :cond_c
    move-wide/from16 v13, p2

    move-object/from16 v18, v0

    move/from16 v16, v10

    .end local v0    # "e":Ljava/lang/Exception;
    .end local v6    # "attempt":I
    .end local v7    # "position":J
    .end local v10    # "busy":I
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v17    # "buffer":[B
    .end local p0    # "url":Ljava/lang/String;
    .end local p1    # "channel":Ljava/nio/channels/FileChannel;
    .end local p2    # "start":J
    .end local p4    # "end":J
    .end local p6    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    .restart local v18    # "e":Ljava/lang/Exception;
    :try_start_10
    throw v18
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_c

    .line 742
    .end local v18    # "e":Ljava/lang/Exception;
    .restart local v6    # "attempt":I
    .restart local v7    # "position":J
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v16    # "busy":I
    .restart local v17    # "buffer":[B
    .restart local p0    # "url":Ljava/lang/String;
    .restart local p1    # "channel":Ljava/nio/channels/FileChannel;
    .restart local p2    # "start":J
    .restart local p4    # "end":J
    .restart local p6    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :catchall_c
    move-exception v0

    move/from16 v10, v16

    goto :goto_8

    .line 722
    .end local v16    # "busy":I
    .end local v17    # "buffer":[B
    .local v9, "buffer":[B
    .restart local v10    # "busy":I
    :catch_14
    move-exception v0

    move-object/from16 v15, p1

    move-wide/from16 v13, p2

    move-wide/from16 v18, v7

    move-object/from16 v17, v9

    move/from16 v20, v10

    move v9, v6

    .line 724
    .end local v9    # "buffer":[B
    .local v0, "e":Lorg/emulationstation/frontend/HttpBridge$CancelledException;
    .restart local v17    # "buffer":[B
    :goto_7
    nop

    .end local v6    # "attempt":I
    .end local v7    # "position":J
    .end local v10    # "busy":I
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v17    # "buffer":[B
    .end local p0    # "url":Ljava/lang/String;
    .end local p1    # "channel":Ljava/nio/channels/FileChannel;
    .end local p2    # "start":J
    .end local p4    # "end":J
    .end local p6    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :try_start_11
    throw v0
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_d

    .line 742
    .end local v0    # "e":Lorg/emulationstation/frontend/HttpBridge$CancelledException;
    .restart local v6    # "attempt":I
    .restart local v7    # "position":J
    .restart local v10    # "busy":I
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v17    # "buffer":[B
    .restart local p0    # "url":Ljava/lang/String;
    .restart local p1    # "channel":Ljava/nio/channels/FileChannel;
    .restart local p2    # "start":J
    .restart local p4    # "end":J
    .restart local p6    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :catchall_d
    move-exception v0

    :goto_8
    if-eqz v11, :cond_d

    .line 743
    invoke-virtual {v11}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 744
    :cond_d
    throw v0

    .line 664
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v17    # "buffer":[B
    .restart local v9    # "buffer":[B
    :cond_e
    new-instance v0, Lorg/emulationstation/frontend/HttpBridge$CancelledException;

    invoke-direct {v0}, Lorg/emulationstation/frontend/HttpBridge$CancelledException;-><init>()V

    throw v0

    .line 746
    :cond_f
    return-void
.end method

.method public static error(I)Ljava/lang/String;
    .locals 2
    .param p0, "id"    # I

    .line 902
    sget-object v0, Lorg/emulationstation/frontend/HttpBridge;->REQUESTS:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/emulationstation/frontend/HttpBridge$Request;

    .line 903
    .local v0, "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    if-nez v0, :cond_0

    const-string v1, "unknown request"

    goto :goto_0

    :cond_0
    iget-object v1, v0, Lorg/emulationstation/frontend/HttpBridge$Request;->error:Ljava/lang/String;

    :goto_0
    return-object v1
.end method

.method private static execute(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;)V
    .locals 19
    .param p0, "url"    # Ljava/lang/String;
    .param p1, "destPath"    # Ljava/lang/String;
    .param p2, "request"    # Lorg/emulationstation/frontend/HttpBridge$Request;

    .line 373
    move-object/from16 v1, p1

    move-object/from16 v2, p2

    const-string v0, "HTTP "

    const-string v3, "Could not delete "

    const-string v4, ".part"

    const-string v5, "EmulationStation"

    const/4 v6, 0x0

    .line 374
    .local v6, "connection":Ljava/net/HttpURLConnection;
    const/4 v7, 0x0

    .line 378
    .local v7, "fileOut":Ljava/io/OutputStream;
    :try_start_0
    invoke-static/range {p0 .. p0}, Lorg/emulationstation/frontend/HttpBridge;->normalizeUrl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9
    :try_end_0
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_0 .. :try_end_0} :catch_c
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_a
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 383
    .end local p0    # "url":Ljava/lang/String;
    .local v9, "url":Ljava/lang/String;
    move-object v10, v9

    .line 385
    .local v10, "current":Ljava/lang/String;
    const/4 v11, 0x0

    .line 387
    .local v11, "redirect":I
    :goto_0
    :try_start_1
    new-instance v12, Ljava/net/URL;

    invoke-direct {v12, v10}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v12}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v12

    check-cast v12, Ljava/net/HttpURLConnection;

    move-object v6, v12

    .line 388
    const/16 v12, 0x3a98

    invoke-virtual {v6, v12}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    .line 389
    const/16 v12, 0x7530

    invoke-virtual {v6, v12}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    .line 390
    const/4 v12, 0x0

    invoke-virtual {v6, v12}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    .line 391
    const-string v13, "User-Agent"

    invoke-virtual {v6, v13, v5}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 392
    const-string v13, "Accept-Encoding"

    const-string v14, "identity"

    invoke-virtual {v6, v13, v14}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 394
    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v13

    .line 395
    .local v13, "code":I
    const/16 v14, 0x12d

    if-eq v13, v14, :cond_1

    const/16 v14, 0x12e

    if-eq v13, v14, :cond_1

    const/16 v14, 0x12f

    if-eq v13, v14, :cond_1

    const/16 v14, 0x133

    if-eq v13, v14, :cond_1

    const/16 v14, 0x134

    if-ne v13, v14, :cond_0

    goto :goto_1

    :cond_0
    move v14, v12

    goto :goto_2

    :cond_1
    :goto_1
    const/4 v14, 0x1

    .line 400
    .local v14, "isRedirect":Z
    :goto_2
    if-nez v14, :cond_19

    .line 402
    const/16 v8, 0xc8

    if-lt v13, v8, :cond_15

    const/16 v8, 0x12b

    if-le v13, v8, :cond_2

    goto/16 :goto_e

    .line 436
    .end local v11    # "redirect":I
    .end local v13    # "code":I
    .end local v14    # "isRedirect":Z
    :cond_2
    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->getContentLengthLong()J

    move-result-wide v13

    iput-wide v13, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->total:J

    .line 438
    if-eqz v1, :cond_4

    .line 440
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 441
    .local v0, "dest":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v8

    .line 442
    .local v8, "parent":Ljava/io/File;
    if-eqz v8, :cond_4

    invoke-virtual {v8}, Ljava/io/File;->exists()Z

    move-result v11

    if-nez v11, :cond_4

    invoke-virtual {v8}, Ljava/io/File;->mkdirs()Z

    move-result v11

    if-eqz v11, :cond_3

    goto :goto_3

    .line 443
    :cond_3
    new-instance v11, Ljava/lang/Exception;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "could not create "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .end local v6    # "connection":Ljava/net/HttpURLConnection;
    .end local v7    # "fileOut":Ljava/io/OutputStream;
    .end local v9    # "url":Ljava/lang/String;
    .end local p1    # "destPath":Ljava/lang/String;
    .end local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    throw v11

    .line 448
    .end local v0    # "dest":Ljava/io/File;
    .end local v8    # "parent":Ljava/io/File;
    .restart local v6    # "connection":Ljava/net/HttpURLConnection;
    .restart local v7    # "fileOut":Ljava/io/OutputStream;
    .restart local v9    # "url":Ljava/lang/String;
    .restart local p1    # "destPath":Ljava/lang/String;
    .restart local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :cond_4
    :goto_3
    if-eqz v1, :cond_5

    new-instance v0, Ljava/io/File;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-direct {v0, v8}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    goto :goto_4

    :cond_5
    const/4 v0, 0x0

    .line 450
    .local v0, "part":Ljava/io/File;
    :goto_4
    if-eqz v0, :cond_6

    iget-wide v13, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->total:J

    const-wide/32 v16, 0x800000

    cmp-long v8, v13, v16

    if-ltz v8, :cond_6

    const-string v8, "bytes"

    const-string v11, "Accept-Ranges"

    .line 452
    invoke-virtual {v6, v11}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v8, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_6

    const/4 v8, 0x1

    goto :goto_5

    :cond_6
    move v8, v12

    .line 454
    .local v8, "parallel":Z
    :goto_5
    if-eqz v8, :cond_7

    .line 456
    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 457
    const/4 v6, 0x0

    .line 459
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "Downloading "

    invoke-virtual {v11, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    iget-wide v13, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->total:J

    invoke-virtual {v11, v13, v14}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v13, " bytes over "

    invoke-virtual {v11, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const/16 v13, 0x18

    invoke-virtual {v11, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v13, " connections: "

    invoke-virtual {v11, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-static {v5, v11}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 460
    invoke-static {v10, v0, v2}, Lorg/emulationstation/frontend/HttpBridge;->downloadInParts(Ljava/lang/String;Ljava/io/File;Lorg/emulationstation/frontend/HttpBridge$Request;)V

    move/from16 v18, v8

    goto/16 :goto_9

    .line 464
    :cond_7
    new-instance v11, Ljava/io/BufferedInputStream;

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v13

    const/high16 v14, 0x40000

    invoke-direct {v11, v13, v14}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;I)V

    .line 465
    .local v11, "in":Ljava/io/InputStream;
    const/4 v13, 0x0

    .line 467
    .local v13, "memoryOut":Ljava/io/ByteArrayOutputStream;
    if-eqz v0, :cond_8

    .line 468
    new-instance v15, Ljava/io/BufferedOutputStream;

    new-instance v12, Ljava/io/FileOutputStream;

    invoke-direct {v12, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    invoke-direct {v15, v12, v14}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;I)V

    move-object v7, v15

    goto :goto_6

    .line 470
    :cond_8
    new-instance v12, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v12}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_1
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_1 .. :try_end_1} :catch_9
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_8
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    move-object v13, v12

    .line 472
    :goto_6
    :try_start_2
    new-array v12, v14, [B

    .line 475
    .local v12, "buffer":[B
    :goto_7
    invoke-virtual {v11, v12}, Ljava/io/InputStream;->read([B)I

    move-result v14

    move v15, v14

    .local v15, "read":I
    if-lez v14, :cond_b

    .line 477
    iget-boolean v14, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->cancelled:Z
    :try_end_2
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_2 .. :try_end_2} :catch_4
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_3
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    if-nez v14, :cond_a

    .line 480
    if-eqz v7, :cond_9

    .line 481
    const/4 v14, 0x0

    :try_start_3
    invoke-virtual {v7, v12, v14, v15}, Ljava/io/OutputStream;->write([BII)V
    :try_end_3
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_3 .. :try_end_3} :catch_9
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_8
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    goto :goto_8

    .line 483
    :cond_9
    const/4 v14, 0x0

    :try_start_4
    invoke-virtual {v13, v12, v14, v15}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 485
    :goto_8
    iget-object v14, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->downloadedBytes:Ljava/util/concurrent/atomic/AtomicLong;
    :try_end_4
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_4 .. :try_end_4} :catch_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    move-object/from16 v17, v7

    move/from16 v18, v8

    .end local v7    # "fileOut":Ljava/io/OutputStream;
    .end local v8    # "parallel":Z
    .local v17, "fileOut":Ljava/io/OutputStream;
    .local v18, "parallel":Z
    int-to-long v7, v15

    :try_start_5
    invoke-virtual {v14, v7, v8}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    move-object/from16 v7, v17

    move/from16 v8, v18

    goto :goto_7

    .line 478
    .end local v17    # "fileOut":Ljava/io/OutputStream;
    .end local v18    # "parallel":Z
    .restart local v7    # "fileOut":Ljava/io/OutputStream;
    .restart local v8    # "parallel":Z
    :cond_a
    move-object/from16 v17, v7

    move/from16 v18, v8

    .end local v7    # "fileOut":Ljava/io/OutputStream;
    .end local v8    # "parallel":Z
    .restart local v17    # "fileOut":Ljava/io/OutputStream;
    .restart local v18    # "parallel":Z
    new-instance v7, Lorg/emulationstation/frontend/HttpBridge$CancelledException;

    invoke-direct {v7}, Lorg/emulationstation/frontend/HttpBridge$CancelledException;-><init>()V

    .end local v6    # "connection":Ljava/net/HttpURLConnection;
    .end local v9    # "url":Ljava/lang/String;
    .end local v17    # "fileOut":Ljava/io/OutputStream;
    .end local p1    # "destPath":Ljava/lang/String;
    .end local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    throw v7

    .line 488
    .end local v18    # "parallel":Z
    .restart local v6    # "connection":Ljava/net/HttpURLConnection;
    .restart local v7    # "fileOut":Ljava/io/OutputStream;
    .restart local v8    # "parallel":Z
    .restart local v9    # "url":Ljava/lang/String;
    .restart local p1    # "destPath":Ljava/lang/String;
    .restart local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :cond_b
    move-object/from16 v17, v7

    move/from16 v18, v8

    .end local v7    # "fileOut":Ljava/io/OutputStream;
    .end local v8    # "parallel":Z
    .restart local v17    # "fileOut":Ljava/io/OutputStream;
    .restart local v18    # "parallel":Z
    invoke-virtual {v11}, Ljava/io/InputStream;->close()V

    .line 490
    if-eqz v17, :cond_c

    .line 492
    invoke-virtual/range {v17 .. v17}, Ljava/io/OutputStream;->close()V

    .line 493
    const/4 v7, 0x0

    .end local v17    # "fileOut":Ljava/io/OutputStream;
    .restart local v7    # "fileOut":Ljava/io/OutputStream;
    goto :goto_9

    .line 497
    .end local v7    # "fileOut":Ljava/io/OutputStream;
    .restart local v17    # "fileOut":Ljava/io/OutputStream;
    :cond_c
    invoke-virtual {v13}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v7

    iput-object v7, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->content:[B
    :try_end_5
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_5 .. :try_end_5} :catch_2
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_1
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    move-object/from16 v7, v17

    .line 501
    .end local v11    # "in":Ljava/io/InputStream;
    .end local v12    # "buffer":[B
    .end local v13    # "memoryOut":Ljava/io/ByteArrayOutputStream;
    .end local v15    # "read":I
    .end local v17    # "fileOut":Ljava/io/OutputStream;
    .restart local v7    # "fileOut":Ljava/io/OutputStream;
    :goto_9
    if-eqz v0, :cond_10

    .line 503
    :try_start_6
    new-instance v8, Ljava/io/File;

    invoke-direct {v8, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 505
    .local v8, "dest":Ljava/io/File;
    invoke-virtual {v8}, Ljava/io/File;->exists()Z

    move-result v11

    if-eqz v11, :cond_e

    invoke-virtual {v8}, Ljava/io/File;->delete()Z

    move-result v11

    if-eqz v11, :cond_d

    goto :goto_a

    .line 506
    :cond_d
    new-instance v11, Ljava/lang/Exception;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "could not replace "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .end local v6    # "connection":Ljava/net/HttpURLConnection;
    .end local v7    # "fileOut":Ljava/io/OutputStream;
    .end local v9    # "url":Ljava/lang/String;
    .end local p1    # "destPath":Ljava/lang/String;
    .end local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    throw v11

    .line 508
    .restart local v6    # "connection":Ljava/net/HttpURLConnection;
    .restart local v7    # "fileOut":Ljava/io/OutputStream;
    .restart local v9    # "url":Ljava/lang/String;
    .restart local p1    # "destPath":Ljava/lang/String;
    .restart local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :cond_e
    :goto_a
    invoke-virtual {v0, v8}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v11

    if-eqz v11, :cond_f

    .line 511
    const/4 v14, 0x0

    new-array v11, v14, [B

    iput-object v11, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->content:[B

    goto :goto_b

    .line 509
    :cond_f
    new-instance v11, Ljava/lang/Exception;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "could not rename "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .end local v6    # "connection":Ljava/net/HttpURLConnection;
    .end local v7    # "fileOut":Ljava/io/OutputStream;
    .end local v9    # "url":Ljava/lang/String;
    .end local p1    # "destPath":Ljava/lang/String;
    .end local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    throw v11

    .line 514
    .end local v8    # "dest":Ljava/io/File;
    .restart local v6    # "connection":Ljava/net/HttpURLConnection;
    .restart local v7    # "fileOut":Ljava/io/OutputStream;
    .restart local v9    # "url":Ljava/lang/String;
    .restart local p1    # "destPath":Ljava/lang/String;
    .restart local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :cond_10
    :goto_b
    const/4 v8, 0x1

    iput-boolean v8, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->downloadOk:Z

    .line 516
    iget-boolean v11, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->deferSuccess:Z

    if-nez v11, :cond_11

    .line 517
    iput v8, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I
    :try_end_6
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_6 .. :try_end_6} :catch_9
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_8
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 532
    .end local v0    # "part":Ljava/io/File;
    .end local v10    # "current":Ljava/lang/String;
    .end local v18    # "parallel":Z
    :cond_11
    if-eqz v7, :cond_12

    :try_start_7
    invoke-virtual {v7}, Ljava/io/OutputStream;->close()V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_0

    goto :goto_c

    :catch_0
    move-exception v0

    .line 533
    :cond_12
    :goto_c
    if-eqz v6, :cond_13

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 537
    :cond_13
    if-eqz v1, :cond_27

    iget-boolean v0, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->downloadOk:Z

    if-nez v0, :cond_27

    .line 539
    new-instance v0, Ljava/io/File;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 540
    .restart local v0    # "part":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v4

    if-eqz v4, :cond_14

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    move-result v4

    if-nez v4, :cond_14

    .line 541
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    :goto_d
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v5, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 542
    .end local v0    # "part":Ljava/io/File;
    :cond_14
    goto/16 :goto_17

    .line 532
    .end local v7    # "fileOut":Ljava/io/OutputStream;
    .restart local v17    # "fileOut":Ljava/io/OutputStream;
    :catchall_0
    move-exception v0

    move-object v7, v6

    move-object v6, v0

    goto/16 :goto_18

    .line 524
    :catch_1
    move-exception v0

    move-object/from16 v7, v17

    goto/16 :goto_13

    .line 519
    :catch_2
    move-exception v0

    move-object/from16 v7, v17

    goto/16 :goto_15

    .line 532
    .end local v17    # "fileOut":Ljava/io/OutputStream;
    .restart local v7    # "fileOut":Ljava/io/OutputStream;
    :catchall_1
    move-exception v0

    move-object/from16 v17, v7

    move-object v7, v6

    move-object v6, v0

    .end local v7    # "fileOut":Ljava/io/OutputStream;
    .restart local v17    # "fileOut":Ljava/io/OutputStream;
    goto/16 :goto_18

    .line 524
    .end local v17    # "fileOut":Ljava/io/OutputStream;
    .restart local v7    # "fileOut":Ljava/io/OutputStream;
    :catch_3
    move-exception v0

    move-object/from16 v17, v7

    .end local v7    # "fileOut":Ljava/io/OutputStream;
    .restart local v17    # "fileOut":Ljava/io/OutputStream;
    goto/16 :goto_13

    .line 519
    .end local v17    # "fileOut":Ljava/io/OutputStream;
    .restart local v7    # "fileOut":Ljava/io/OutputStream;
    :catch_4
    move-exception v0

    move-object/from16 v17, v7

    .end local v7    # "fileOut":Ljava/io/OutputStream;
    .restart local v17    # "fileOut":Ljava/io/OutputStream;
    goto/16 :goto_15

    .line 406
    .end local v17    # "fileOut":Ljava/io/OutputStream;
    .restart local v7    # "fileOut":Ljava/io/OutputStream;
    .restart local v10    # "current":Ljava/lang/String;
    .local v11, "redirect":I
    .local v13, "code":I
    .restart local v14    # "isRedirect":Z
    :cond_15
    :goto_e
    :try_start_8
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v12, " em "

    invoke-virtual {v8, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-static {v10}, Lorg/emulationstation/frontend/HttpBridge;->redactUrl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v8, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    iput-object v8, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->error:Ljava/lang/String;

    .line 407
    const/4 v8, 0x3

    iput v8, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I

    .line 408
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v8, " -> "

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {v10}, Lorg/emulationstation/frontend/HttpBridge;->redactUrl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_8
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_8 .. :try_end_8} :catch_9
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    .line 532
    if-eqz v7, :cond_16

    :try_start_9
    invoke-virtual {v7}, Ljava/io/OutputStream;->close()V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_5

    goto :goto_f

    :catch_5
    move-exception v0

    .line 533
    :cond_16
    :goto_f
    if-eqz v6, :cond_17

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 537
    :cond_17
    if-eqz v1, :cond_18

    iget-boolean v0, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->downloadOk:Z

    if-nez v0, :cond_18

    .line 539
    new-instance v0, Ljava/io/File;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 540
    .restart local v0    # "part":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v4

    if-eqz v4, :cond_18

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    move-result v4

    if-nez v4, :cond_18

    .line 541
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v5, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 409
    .end local v0    # "part":Ljava/io/File;
    :cond_18
    return-void

    .line 414
    :cond_19
    const/4 v8, 0x5

    const/4 v12, 0x4

    if-lt v11, v8, :cond_1d

    .line 416
    :try_start_a
    const-string v0, "too many redirects"

    iput-object v0, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->error:Ljava/lang/String;

    .line 417
    iput v12, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I
    :try_end_a
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_a .. :try_end_a} :catch_9
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_8
    .catchall {:try_start_a .. :try_end_a} :catchall_3

    .line 532
    if-eqz v7, :cond_1a

    :try_start_b
    invoke-virtual {v7}, Ljava/io/OutputStream;->close()V
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_6

    goto :goto_10

    :catch_6
    move-exception v0

    .line 533
    :cond_1a
    :goto_10
    if-eqz v6, :cond_1b

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 537
    :cond_1b
    if-eqz v1, :cond_1c

    iget-boolean v0, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->downloadOk:Z

    if-nez v0, :cond_1c

    .line 539
    new-instance v0, Ljava/io/File;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 540
    .restart local v0    # "part":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v4

    if-eqz v4, :cond_1c

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    move-result v4

    if-nez v4, :cond_1c

    .line 541
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v5, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 418
    .end local v0    # "part":Ljava/io/File;
    :cond_1c
    return-void

    .line 421
    :cond_1d
    :try_start_c
    const-string v8, "Location"

    invoke-virtual {v6, v8}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 422
    .local v8, "location":Ljava/lang/String;
    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 424
    if-eqz v8, :cond_1f

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v15

    if-eqz v15, :cond_1e

    goto :goto_11

    .line 431
    :cond_1e
    new-instance v12, Ljava/net/URL;

    new-instance v15, Ljava/net/URL;

    invoke-direct {v15, v10}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-direct {v12, v15, v8}, Ljava/net/URL;-><init>(Ljava/net/URL;Ljava/lang/String;)V

    invoke-virtual {v12}, Ljava/net/URL;->toString()Ljava/lang/String;

    move-result-object v12

    move-object v10, v12

    .line 385
    .end local v8    # "location":Ljava/lang/String;
    .end local v13    # "code":I
    .end local v14    # "isRedirect":Z
    add-int/lit8 v11, v11, 0x1

    goto/16 :goto_0

    .line 426
    .restart local v8    # "location":Ljava/lang/String;
    .restart local v13    # "code":I
    .restart local v14    # "isRedirect":Z
    :cond_1f
    :goto_11
    const-string v0, "redirect without a location"

    iput-object v0, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->error:Ljava/lang/String;

    .line 427
    iput v12, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I
    :try_end_c
    .catch Lorg/emulationstation/frontend/HttpBridge$CancelledException; {:try_start_c .. :try_end_c} :catch_9
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_8
    .catchall {:try_start_c .. :try_end_c} :catchall_3

    .line 532
    if-eqz v7, :cond_20

    :try_start_d
    invoke-virtual {v7}, Ljava/io/OutputStream;->close()V
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_7

    goto :goto_12

    :catch_7
    move-exception v0

    .line 533
    :cond_20
    :goto_12
    if-eqz v6, :cond_21

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 537
    :cond_21
    if-eqz v1, :cond_22

    iget-boolean v0, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->downloadOk:Z

    if-nez v0, :cond_22

    .line 539
    new-instance v0, Ljava/io/File;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 540
    .restart local v0    # "part":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v4

    if-eqz v4, :cond_22

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    move-result v4

    if-nez v4, :cond_22

    .line 541
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v5, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 428
    .end local v0    # "part":Ljava/io/File;
    :cond_22
    return-void

    .line 524
    .end local v8    # "location":Ljava/lang/String;
    .end local v10    # "current":Ljava/lang/String;
    .end local v11    # "redirect":I
    .end local v13    # "code":I
    .end local v14    # "isRedirect":Z
    :catch_8
    move-exception v0

    goto :goto_13

    .line 519
    :catch_9
    move-exception v0

    goto :goto_15

    .line 532
    .end local v9    # "url":Ljava/lang/String;
    .restart local p0    # "url":Ljava/lang/String;
    :catchall_2
    move-exception v0

    move-object/from16 v9, p0

    move-object/from16 v17, v7

    move-object v7, v6

    move-object v6, v0

    goto/16 :goto_18

    .line 524
    :catch_a
    move-exception v0

    move-object/from16 v9, p0

    .line 526
    .end local p0    # "url":Ljava/lang/String;
    .local v0, "e":Ljava/lang/Exception;
    .restart local v9    # "url":Ljava/lang/String;
    :goto_13
    :try_start_e
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "Request failed: "

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v5, v8, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 527
    invoke-static {v0}, Lorg/emulationstation/frontend/HttpBridge;->describeFailure(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v8

    iput-object v8, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->error:Ljava/lang/String;

    .line 528
    const/4 v8, 0x2

    iput v8, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_3

    .line 532
    .end local v0    # "e":Ljava/lang/Exception;
    if-eqz v7, :cond_23

    :try_start_f
    invoke-virtual {v7}, Ljava/io/OutputStream;->close()V
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_f} :catch_b

    goto :goto_14

    :catch_b
    move-exception v0

    .line 533
    :cond_23
    :goto_14
    if-eqz v6, :cond_24

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 537
    :cond_24
    if-eqz v1, :cond_27

    iget-boolean v0, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->downloadOk:Z

    if-nez v0, :cond_27

    .line 539
    new-instance v0, Ljava/io/File;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 540
    .local v0, "part":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v4

    if-eqz v4, :cond_14

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    move-result v4

    if-nez v4, :cond_14

    .line 541
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    goto/16 :goto_d

    .line 519
    .end local v0    # "part":Ljava/io/File;
    .end local v9    # "url":Ljava/lang/String;
    .restart local p0    # "url":Ljava/lang/String;
    :catch_c
    move-exception v0

    move-object/from16 v9, p0

    .line 521
    .end local p0    # "url":Ljava/lang/String;
    .local v0, "e":Lorg/emulationstation/frontend/HttpBridge$CancelledException;
    .restart local v9    # "url":Ljava/lang/String;
    :goto_15
    :try_start_10
    const-string v8, "cancelled"

    iput-object v8, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->error:Ljava/lang/String;

    .line 522
    const/4 v8, 0x2

    iput v8, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_3

    .line 532
    .end local v0    # "e":Lorg/emulationstation/frontend/HttpBridge$CancelledException;
    if-eqz v7, :cond_25

    :try_start_11
    invoke-virtual {v7}, Ljava/io/OutputStream;->close()V
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_11} :catch_d

    goto :goto_16

    :catch_d
    move-exception v0

    .line 533
    :cond_25
    :goto_16
    if-eqz v6, :cond_26

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 537
    :cond_26
    if-eqz v1, :cond_27

    iget-boolean v0, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->downloadOk:Z

    if-nez v0, :cond_27

    .line 539
    new-instance v0, Ljava/io/File;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 540
    .local v0, "part":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v4

    if-eqz v4, :cond_14

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    move-result v4

    if-nez v4, :cond_14

    .line 541
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    goto/16 :goto_d

    .line 544
    .end local v0    # "part":Ljava/io/File;
    :cond_27
    :goto_17
    return-void

    .line 532
    :catchall_3
    move-exception v0

    move-object/from16 v17, v7

    move-object v7, v6

    move-object v6, v0

    .end local v6    # "connection":Ljava/net/HttpURLConnection;
    .local v7, "connection":Ljava/net/HttpURLConnection;
    .restart local v17    # "fileOut":Ljava/io/OutputStream;
    :goto_18
    if-eqz v17, :cond_28

    :try_start_12
    invoke-virtual/range {v17 .. v17}, Ljava/io/OutputStream;->close()V
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_12} :catch_e

    goto :goto_19

    :catch_e
    move-exception v0

    .line 533
    :cond_28
    :goto_19
    if-eqz v7, :cond_29

    invoke-virtual {v7}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 537
    :cond_29
    if-eqz v1, :cond_2a

    iget-boolean v0, v2, Lorg/emulationstation/frontend/HttpBridge$Request;->downloadOk:Z

    if-nez v0, :cond_2a

    .line 539
    new-instance v0, Ljava/io/File;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 540
    .restart local v0    # "part":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v4

    if-eqz v4, :cond_2a

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    move-result v4

    if-nez v4, :cond_2a

    .line 541
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v5, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 543
    .end local v0    # "part":Ljava/io/File;
    :cond_2a
    throw v6
.end method

.method private static executePost(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;)V
    .locals 10
    .param p0, "url"    # Ljava/lang/String;
    .param p1, "formBody"    # Ljava/lang/String;
    .param p2, "request"    # Lorg/emulationstation/frontend/HttpBridge$Request;

    .line 174
    const/4 v0, 0x0

    .line 178
    .local v0, "connection":Ljava/net/HttpURLConnection;
    :try_start_0
    const-string v1, "UTF-8"

    invoke-virtual {p1, v1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v1

    .line 180
    .local v1, "body":[B
    new-instance v2, Ljava/net/URL;

    invoke-direct {v2, p0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v2

    check-cast v2, Ljava/net/HttpURLConnection;

    move-object v0, v2

    .line 181
    const/16 v2, 0x3a98

    invoke-virtual {v0, v2}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    .line 182
    const/16 v2, 0x7530

    invoke-virtual {v0, v2}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    .line 183
    const-string v2, "POST"

    invoke-virtual {v0, v2}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 184
    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Ljava/net/HttpURLConnection;->setDoOutput(Z)V

    .line 185
    array-length v3, v1

    invoke-virtual {v0, v3}, Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V

    .line 186
    const-string v3, "User-Agent"

    const-string v4, "WayOs"

    invoke-virtual {v0, v3, v4}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 187
    const-string v3, "Content-Type"

    const-string v4, "application/x-www-form-urlencoded; charset=UTF-8"

    invoke-virtual {v0, v3, v4}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 189
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v3

    .line 190
    .local v3, "out":Ljava/io/OutputStream;
    invoke-virtual {v3, v1}, Ljava/io/OutputStream;->write([B)V

    .line 191
    invoke-virtual {v3}, Ljava/io/OutputStream;->close()V

    .line 193
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v4

    .line 197
    .local v4, "code":I
    const/16 v5, 0x190

    if-lt v4, v5, :cond_0

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getErrorStream()Ljava/io/InputStream;

    move-result-object v5

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v5

    .line 198
    .local v5, "in":Ljava/io/InputStream;
    :goto_0
    new-instance v6, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v6}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 200
    .local v6, "memory":Ljava/io/ByteArrayOutputStream;
    if-eqz v5, :cond_2

    .line 202
    const/16 v7, 0x4000

    new-array v7, v7, [B

    .line 204
    .local v7, "buffer":[B
    :goto_1
    invoke-virtual {v5, v7}, Ljava/io/InputStream;->read([B)I

    move-result v8

    move v9, v8

    .local v9, "read":I
    if-lez v8, :cond_1

    .line 205
    const/4 v8, 0x0

    invoke-virtual {v6, v7, v8, v9}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_1

    .line 206
    :cond_1
    invoke-virtual {v5}, Ljava/io/InputStream;->close()V

    .line 209
    .end local v7    # "buffer":[B
    .end local v9    # "read":I
    :cond_2
    invoke-virtual {v6}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v7

    iput-object v7, p2, Lorg/emulationstation/frontend/HttpBridge$Request;->content:[B

    .line 211
    const/16 v7, 0xc8

    if-lt v4, v7, :cond_4

    const/16 v7, 0x12b

    if-le v4, v7, :cond_3

    goto :goto_3

    .line 218
    :cond_3
    iput v2, p2, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 229
    .end local v1    # "body":[B
    .end local v3    # "out":Ljava/io/OutputStream;
    .end local v4    # "code":I
    .end local v5    # "in":Ljava/io/InputStream;
    .end local v6    # "memory":Ljava/io/ByteArrayOutputStream;
    if-eqz v0, :cond_6

    .line 230
    :goto_2
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    goto :goto_4

    .line 213
    .restart local v1    # "body":[B
    .restart local v3    # "out":Ljava/io/OutputStream;
    .restart local v4    # "code":I
    .restart local v5    # "in":Ljava/io/InputStream;
    .restart local v6    # "memory":Ljava/io/ByteArrayOutputStream;
    :cond_4
    :goto_3
    :try_start_1
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "HTTP "

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    iput-object v2, p2, Lorg/emulationstation/frontend/HttpBridge$Request;->error:Ljava/lang/String;

    .line 214
    const/4 v2, 0x3

    iput v2, p2, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 229
    if-eqz v0, :cond_5

    .line 230
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 215
    :cond_5
    return-void

    .line 229
    .end local v1    # "body":[B
    .end local v3    # "out":Ljava/io/OutputStream;
    .end local v4    # "code":I
    .end local v5    # "in":Ljava/io/InputStream;
    .end local v6    # "memory":Ljava/io/ByteArrayOutputStream;
    :catchall_0
    move-exception v1

    goto :goto_5

    .line 220
    :catch_0
    move-exception v1

    .line 223
    .local v1, "e":Ljava/lang/Exception;
    :try_start_2
    const-string v2, "EmulationStation"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "POST failed: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " ("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ")"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 224
    invoke-static {v1}, Lorg/emulationstation/frontend/HttpBridge;->describeFailure(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p2, Lorg/emulationstation/frontend/HttpBridge$Request;->error:Ljava/lang/String;

    .line 225
    const/4 v2, 0x2

    iput v2, p2, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 229
    .end local v1    # "e":Ljava/lang/Exception;
    if-eqz v0, :cond_6

    .line 230
    goto :goto_2

    .line 232
    :cond_6
    :goto_4
    return-void

    .line 229
    :goto_5
    if-eqz v0, :cond_7

    .line 230
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 231
    :cond_7
    throw v1
.end method

.method private static extractAll(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;)V
    .locals 17
    .param p0, "zipPath"    # Ljava/lang/String;
    .param p1, "destDir"    # Ljava/lang/String;
    .param p2, "request"    # Lorg/emulationstation/frontend/HttpBridge$Request;

    .line 818
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    const-string v4, "EmulationStation"

    const/4 v5, 0x0

    .line 819
    .local v5, "zip":Ljava/util/zip/ZipInputStream;
    const/4 v6, 0x0

    .line 823
    .local v6, "extracted":I
    :try_start_0
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->getCanonicalFile()Ljava/io/File;

    move-result-object v0

    move-object v7, v0

    .line 824
    .local v7, "root":Ljava/io/File;
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    sget-object v8, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    move-object v8, v0

    .line 826
    .local v8, "rootPath":Ljava/lang/String;
    new-instance v0, Ljava/util/zip/ZipInputStream;

    new-instance v9, Ljava/io/BufferedInputStream;

    new-instance v10, Ljava/io/FileInputStream;

    invoke-direct {v10, v1}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    invoke-direct {v9, v10}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v0, v9}, Ljava/util/zip/ZipInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_3
    .catchall {:try_start_0 .. :try_end_0} :catchall_4

    move-object v5, v0

    .line 828
    const/high16 v0, 0x10000

    :try_start_1
    new-array v0, v0, [B

    move-object v9, v0

    .line 830
    .local v9, "buffer":[B
    :goto_0
    invoke-virtual {v5}, Ljava/util/zip/ZipInputStream;->getNextEntry()Ljava/util/zip/ZipEntry;

    move-result-object v0

    move-object v10, v0

    .local v10, "entry":Ljava/util/zip/ZipEntry;
    if-eqz v0, :cond_8

    .line 832
    new-instance v0, Ljava/io/File;

    invoke-virtual {v10}, Ljava/util/zip/ZipEntry;->getName()Ljava/lang/String;

    move-result-object v11

    invoke-direct {v0, v7, v11}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->getCanonicalFile()Ljava/io/File;

    move-result-object v0

    move-object v11, v0

    .line 834
    .local v11, "target":Ljava/io/File;
    invoke-virtual {v11}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_7

    .line 837
    invoke-virtual {v10}, Ljava/util/zip/ZipEntry;->isDirectory()Z

    move-result v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    if-eqz v0, :cond_0

    .line 839
    :try_start_2
    invoke-virtual {v11}, Ljava/io/File;->mkdirs()Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_3
    .catchall {:try_start_2 .. :try_end_2} :catchall_4

    .line 840
    goto :goto_0

    .line 843
    :cond_0
    :try_start_3
    invoke-virtual {v11}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v0
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    move-object v12, v0

    .line 844
    .local v12, "parent":Ljava/io/File;
    if-eqz v12, :cond_2

    :try_start_4
    invoke-virtual {v12}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual {v12}, Ljava/io/File;->mkdirs()Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_1

    .line 845
    :cond_1
    new-instance v0, Ljava/lang/Exception;

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const-string v14, "could not create "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-direct {v0, v13}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .end local v5    # "zip":Ljava/util/zip/ZipInputStream;
    .end local v6    # "extracted":I
    .end local p0    # "zipPath":Ljava/lang/String;
    .end local p1    # "destDir":Ljava/lang/String;
    .end local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    throw v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    .line 847
    .restart local v5    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v6    # "extracted":I
    .restart local p0    # "zipPath":Ljava/lang/String;
    .restart local p1    # "destDir":Ljava/lang/String;
    .restart local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :cond_2
    :goto_1
    :try_start_5
    new-instance v0, Ljava/io/File;

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    const-string v14, ".part"

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-direct {v0, v13}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    move-object v13, v0

    .line 848
    .local v13, "part":Ljava/io/File;
    new-instance v0, Ljava/io/FileOutputStream;

    invoke-direct {v0, v13}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_2
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    move-object v14, v0

    .line 852
    .local v14, "out":Ljava/io/OutputStream;
    :goto_2
    :try_start_6
    invoke-virtual {v5, v9}, Ljava/util/zip/ZipInputStream;->read([B)I

    move-result v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    move v15, v0

    .local v15, "read":I
    if-lez v0, :cond_3

    .line 853
    const/4 v0, 0x0

    :try_start_7
    invoke-virtual {v14, v9, v0, v15}, Ljava/io/OutputStream;->write([BII)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    goto :goto_2

    .line 857
    .end local v15    # "read":I
    :catchall_0
    move-exception v0

    move-object/from16 v16, v5

    goto :goto_4

    :cond_3
    :try_start_8
    invoke-virtual {v14}, Ljava/io/OutputStream;->close()V

    .line 858
    nop

    .line 860
    invoke-virtual {v11}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_5

    invoke-virtual {v11}, Ljava/io/File;->delete()Z

    move-result v0

    if-eqz v0, :cond_4

    move-object/from16 v16, v5

    goto :goto_3

    .line 861
    :cond_4
    new-instance v0, Ljava/lang/Exception;

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_2
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    move-object/from16 v16, v5

    .end local v5    # "zip":Ljava/util/zip/ZipInputStream;
    .local v16, "zip":Ljava/util/zip/ZipInputStream;
    :try_start_9
    const-string v5, "could not replace "

    invoke-virtual {v15, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v0, v5}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .end local v6    # "extracted":I
    .end local v16    # "zip":Ljava/util/zip/ZipInputStream;
    .end local p0    # "zipPath":Ljava/lang/String;
    .end local p1    # "destDir":Ljava/lang/String;
    .end local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    throw v0

    .line 860
    .restart local v5    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v6    # "extracted":I
    .restart local p0    # "zipPath":Ljava/lang/String;
    .restart local p1    # "destDir":Ljava/lang/String;
    .restart local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :cond_5
    move-object/from16 v16, v5

    .line 863
    .end local v5    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v16    # "zip":Ljava/util/zip/ZipInputStream;
    :goto_3
    invoke-virtual {v13, v11}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v0

    if-eqz v0, :cond_6

    .line 866
    nop

    .end local v11    # "target":Ljava/io/File;
    .end local v12    # "parent":Ljava/io/File;
    .end local v13    # "part":Ljava/io/File;
    .end local v14    # "out":Ljava/io/OutputStream;
    add-int/lit8 v6, v6, 0x1

    .line 867
    move-object/from16 v5, v16

    goto/16 :goto_0

    .line 864
    .restart local v11    # "target":Ljava/io/File;
    .restart local v12    # "parent":Ljava/io/File;
    .restart local v13    # "part":Ljava/io/File;
    .restart local v14    # "out":Ljava/io/OutputStream;
    :cond_6
    new-instance v0, Ljava/lang/Exception;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v15, "could not rename "

    invoke-virtual {v5, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v0, v5}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .end local v6    # "extracted":I
    .end local v16    # "zip":Ljava/util/zip/ZipInputStream;
    .end local p0    # "zipPath":Ljava/lang/String;
    .end local p1    # "destDir":Ljava/lang/String;
    .end local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    throw v0

    .line 857
    .restart local v5    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v6    # "extracted":I
    .restart local p0    # "zipPath":Ljava/lang/String;
    .restart local p1    # "destDir":Ljava/lang/String;
    .restart local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :catchall_1
    move-exception v0

    move-object/from16 v16, v5

    .end local v5    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v16    # "zip":Ljava/util/zip/ZipInputStream;
    :goto_4
    invoke-virtual {v14}, Ljava/io/OutputStream;->close()V

    .line 858
    nop

    .end local v6    # "extracted":I
    .end local v16    # "zip":Ljava/util/zip/ZipInputStream;
    .end local p0    # "zipPath":Ljava/lang/String;
    .end local p1    # "destDir":Ljava/lang/String;
    .end local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    throw v0

    .line 835
    .end local v12    # "parent":Ljava/io/File;
    .end local v13    # "part":Ljava/io/File;
    .end local v14    # "out":Ljava/io/OutputStream;
    .restart local v5    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v6    # "extracted":I
    .restart local p0    # "zipPath":Ljava/lang/String;
    .restart local p1    # "destDir":Ljava/lang/String;
    .restart local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :cond_7
    move-object/from16 v16, v5

    .end local v5    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v16    # "zip":Ljava/util/zip/ZipInputStream;
    new-instance v0, Ljava/lang/Exception;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "zip entry escapes the destination: "

    invoke-virtual {v5, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v10}, Ljava/util/zip/ZipEntry;->getName()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v5, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v0, v5}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .end local v6    # "extracted":I
    .end local v16    # "zip":Ljava/util/zip/ZipInputStream;
    .end local p0    # "zipPath":Ljava/lang/String;
    .end local p1    # "destDir":Ljava/lang/String;
    .end local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    throw v0

    .line 869
    .end local v11    # "target":Ljava/io/File;
    .restart local v5    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v6    # "extracted":I
    .restart local p0    # "zipPath":Ljava/lang/String;
    .restart local p1    # "destDir":Ljava/lang/String;
    .restart local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :cond_8
    move-object/from16 v16, v5

    .end local v5    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v16    # "zip":Ljava/util/zip/ZipInputStream;
    if-eqz v6, :cond_9

    .line 872
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Extracted "

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v5, " files from "

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v5, " into "

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 873
    const/4 v0, 0x1

    iput v0, v3, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_1
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    .line 883
    .end local v7    # "root":Ljava/io/File;
    .end local v8    # "rootPath":Ljava/lang/String;
    .end local v9    # "buffer":[B
    .end local v10    # "entry":Ljava/util/zip/ZipEntry;
    :try_start_a
    invoke-virtual/range {v16 .. v16}, Ljava/util/zip/ZipInputStream;->close()V
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_0

    goto :goto_5

    :catch_0
    move-exception v0

    .line 884
    :goto_5
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 885
    move-object/from16 v5, v16

    goto :goto_9

    .line 870
    .restart local v7    # "root":Ljava/io/File;
    .restart local v8    # "rootPath":Ljava/lang/String;
    .restart local v9    # "buffer":[B
    .restart local v10    # "entry":Ljava/util/zip/ZipEntry;
    :cond_9
    :try_start_b
    new-instance v0, Ljava/lang/Exception;

    const-string v5, "the zip is empty"

    invoke-direct {v0, v5}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .end local v6    # "extracted":I
    .end local v16    # "zip":Ljava/util/zip/ZipInputStream;
    .end local p0    # "zipPath":Ljava/lang/String;
    .end local p1    # "destDir":Ljava/lang/String;
    .end local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    throw v0
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_1
    .catchall {:try_start_b .. :try_end_b} :catchall_2

    .line 883
    .end local v7    # "root":Ljava/io/File;
    .end local v8    # "rootPath":Ljava/lang/String;
    .end local v9    # "buffer":[B
    .end local v10    # "entry":Ljava/util/zip/ZipEntry;
    .restart local v6    # "extracted":I
    .restart local v16    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local p0    # "zipPath":Ljava/lang/String;
    .restart local p1    # "destDir":Ljava/lang/String;
    .restart local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :catchall_2
    move-exception v0

    move-object v4, v0

    move-object/from16 v5, v16

    goto :goto_a

    .line 875
    :catch_1
    move-exception v0

    move-object/from16 v5, v16

    goto :goto_6

    .line 883
    .end local v16    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v5    # "zip":Ljava/util/zip/ZipInputStream;
    :catchall_3
    move-exception v0

    move-object/from16 v16, v5

    move-object v4, v0

    .end local v5    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v16    # "zip":Ljava/util/zip/ZipInputStream;
    goto :goto_a

    .line 875
    .end local v16    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v5    # "zip":Ljava/util/zip/ZipInputStream;
    :catch_2
    move-exception v0

    move-object/from16 v16, v5

    .end local v5    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v16    # "zip":Ljava/util/zip/ZipInputStream;
    goto :goto_6

    .line 883
    .end local v16    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v5    # "zip":Ljava/util/zip/ZipInputStream;
    :catchall_4
    move-exception v0

    move-object v4, v0

    goto :goto_a

    .line 875
    :catch_3
    move-exception v0

    .line 877
    .local v0, "e":Ljava/lang/Exception;
    :goto_6
    :try_start_c
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "Could not extract "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v4, v7, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 878
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_a

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v4

    goto :goto_7

    :cond_a
    move-object v4, v0

    :goto_7
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v3, Lorg/emulationstation/frontend/HttpBridge$Request;->error:Ljava/lang/String;

    .line 879
    const/4 v4, 0x4

    iput v4, v3, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_4

    .line 883
    .end local v0    # "e":Ljava/lang/Exception;
    if-eqz v5, :cond_b

    :try_start_d
    invoke-virtual {v5}, Ljava/util/zip/ZipInputStream;->close()V
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_4

    goto :goto_8

    :catch_4
    move-exception v0

    .line 884
    :cond_b
    :goto_8
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 885
    nop

    .line 886
    :goto_9
    return-void

    .line 883
    :goto_a
    if-eqz v5, :cond_c

    :try_start_e
    invoke-virtual {v5}, Ljava/util/zip/ZipInputStream;->close()V
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_e} :catch_5

    goto :goto_b

    :catch_5
    move-exception v0

    .line 884
    :cond_c
    :goto_b
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 885
    throw v4
.end method

.method private static extractCores(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;)V
    .locals 11
    .param p0, "zipPath"    # Ljava/lang/String;
    .param p1, "destDir"    # Ljava/lang/String;
    .param p2, "request"    # Lorg/emulationstation/frontend/HttpBridge$Request;

    .line 754
    const/4 v0, 0x0

    .line 755
    .local v0, "zip":Ljava/util/zip/ZipInputStream;
    const/4 v1, 0x0

    .line 759
    .local v1, "extracted":I
    :try_start_0
    new-instance v2, Ljava/util/zip/ZipInputStream;

    new-instance v3, Ljava/io/BufferedInputStream;

    new-instance v4, Ljava/io/FileInputStream;

    invoke-direct {v4, p0}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    invoke-direct {v3, v4}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v2, v3}, Ljava/util/zip/ZipInputStream;-><init>(Ljava/io/InputStream;)V

    move-object v0, v2

    .line 761
    const/high16 v2, 0x10000

    new-array v2, v2, [B

    .line 763
    .local v2, "buffer":[B
    :cond_0
    :goto_0
    invoke-virtual {v0}, Ljava/util/zip/ZipInputStream;->getNextEntry()Ljava/util/zip/ZipEntry;

    move-result-object v3

    move-object v4, v3

    .local v4, "entry":Ljava/util/zip/ZipEntry;
    if-eqz v3, :cond_6

    .line 765
    new-instance v3, Ljava/io/File;

    invoke-virtual {v4}, Ljava/util/zip/ZipEntry;->getName()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v3

    .line 767
    .local v3, "name":Ljava/lang/String;
    invoke-virtual {v4}, Ljava/util/zip/ZipEntry;->isDirectory()Z

    move-result v5

    if-nez v5, :cond_0

    const-string v5, ".so"

    invoke-virtual {v3, v5}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_1

    .line 768
    goto :goto_0

    .line 770
    :cond_1
    new-instance v5, Ljava/io/File;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, ".part"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, p1, v6}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 771
    .local v5, "part":Ljava/io/File;
    new-instance v6, Ljava/io/File;

    invoke-direct {v6, p1, v3}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 773
    .local v6, "dest":Ljava/io/File;
    new-instance v7, Ljava/io/FileOutputStream;

    invoke-direct {v7, v5}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 777
    .local v7, "out":Ljava/io/OutputStream;
    :goto_1
    :try_start_1
    invoke-virtual {v0, v2}, Ljava/util/zip/ZipInputStream;->read([B)I

    move-result v8

    move v9, v8

    .local v9, "read":I
    if-lez v8, :cond_2

    .line 778
    const/4 v8, 0x0

    invoke-virtual {v7, v2, v8, v9}, Ljava/io/OutputStream;->write([BII)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    .line 782
    .end local v9    # "read":I
    :cond_2
    :try_start_2
    invoke-virtual {v7}, Ljava/io/OutputStream;->close()V

    .line 783
    nop

    .line 785
    invoke-virtual {v6}, Ljava/io/File;->exists()Z

    move-result v8

    if-eqz v8, :cond_4

    invoke-virtual {v6}, Ljava/io/File;->delete()Z

    move-result v8

    if-eqz v8, :cond_3

    goto :goto_2

    .line 786
    :cond_3
    new-instance v8, Ljava/lang/Exception;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "could not replace "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-direct {v8, v9}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .end local v0    # "zip":Ljava/util/zip/ZipInputStream;
    .end local v1    # "extracted":I
    .end local p0    # "zipPath":Ljava/lang/String;
    .end local p1    # "destDir":Ljava/lang/String;
    .end local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    throw v8

    .line 788
    .restart local v0    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v1    # "extracted":I
    .restart local p0    # "zipPath":Ljava/lang/String;
    .restart local p1    # "destDir":Ljava/lang/String;
    .restart local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :cond_4
    :goto_2
    invoke-virtual {v5, v6}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v8

    if-eqz v8, :cond_5

    .line 791
    nop

    .end local v3    # "name":Ljava/lang/String;
    .end local v5    # "part":Ljava/io/File;
    .end local v6    # "dest":Ljava/io/File;
    .end local v7    # "out":Ljava/io/OutputStream;
    add-int/lit8 v1, v1, 0x1

    .line 792
    goto/16 :goto_0

    .line 789
    .restart local v3    # "name":Ljava/lang/String;
    .restart local v5    # "part":Ljava/io/File;
    .restart local v6    # "dest":Ljava/io/File;
    .restart local v7    # "out":Ljava/io/OutputStream;
    :cond_5
    new-instance v8, Ljava/lang/Exception;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "could not rename "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-direct {v8, v9}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .end local v0    # "zip":Ljava/util/zip/ZipInputStream;
    .end local v1    # "extracted":I
    .end local p0    # "zipPath":Ljava/lang/String;
    .end local p1    # "destDir":Ljava/lang/String;
    .end local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    throw v8

    .line 782
    .restart local v0    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v1    # "extracted":I
    .restart local p0    # "zipPath":Ljava/lang/String;
    .restart local p1    # "destDir":Ljava/lang/String;
    .restart local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :catchall_0
    move-exception v8

    invoke-virtual {v7}, Ljava/io/OutputStream;->close()V

    .line 783
    nop

    .end local v0    # "zip":Ljava/util/zip/ZipInputStream;
    .end local v1    # "extracted":I
    .end local p0    # "zipPath":Ljava/lang/String;
    .end local p1    # "destDir":Ljava/lang/String;
    .end local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    throw v8

    .line 794
    .end local v3    # "name":Ljava/lang/String;
    .end local v5    # "part":Ljava/io/File;
    .end local v6    # "dest":Ljava/io/File;
    .end local v7    # "out":Ljava/io/OutputStream;
    .restart local v0    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v1    # "extracted":I
    .restart local p0    # "zipPath":Ljava/lang/String;
    .restart local p1    # "destDir":Ljava/lang/String;
    .restart local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :cond_6
    if-eqz v1, :cond_7

    .line 797
    const/4 v3, 0x1

    iput v3, p2, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 807
    .end local v2    # "buffer":[B
    .end local v4    # "entry":Ljava/util/zip/ZipEntry;
    :try_start_3
    invoke-virtual {v0}, Ljava/util/zip/ZipInputStream;->close()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    goto :goto_3

    :catch_0
    move-exception v2

    .line 808
    :goto_3
    new-instance v2, Ljava/io/File;

    invoke-direct {v2, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    :goto_4
    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    .line 809
    goto :goto_7

    .line 795
    .restart local v2    # "buffer":[B
    .restart local v4    # "entry":Ljava/util/zip/ZipEntry;
    :cond_7
    :try_start_4
    new-instance v3, Ljava/lang/Exception;

    const-string v5, "the zip has no .so inside"

    invoke-direct {v3, v5}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .end local v0    # "zip":Ljava/util/zip/ZipInputStream;
    .end local v1    # "extracted":I
    .end local p0    # "zipPath":Ljava/lang/String;
    .end local p1    # "destDir":Ljava/lang/String;
    .end local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    throw v3
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 807
    .end local v2    # "buffer":[B
    .end local v4    # "entry":Ljava/util/zip/ZipEntry;
    .restart local v0    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v1    # "extracted":I
    .restart local p0    # "zipPath":Ljava/lang/String;
    .restart local p1    # "destDir":Ljava/lang/String;
    .restart local p2    # "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    :catchall_1
    move-exception v2

    goto :goto_8

    .line 799
    :catch_1
    move-exception v2

    .line 801
    .local v2, "e":Ljava/lang/Exception;
    :try_start_5
    const-string v3, "EmulationStation"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Could not extract core from "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 802
    invoke-virtual {v2}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_8

    invoke-virtual {v2}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v3

    goto :goto_5

    :cond_8
    move-object v3, v2

    :goto_5
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, p2, Lorg/emulationstation/frontend/HttpBridge$Request;->error:Ljava/lang/String;

    .line 803
    const/4 v3, 0x4

    iput v3, p2, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 807
    .end local v2    # "e":Ljava/lang/Exception;
    if-eqz v0, :cond_9

    :try_start_6
    invoke-virtual {v0}, Ljava/util/zip/ZipInputStream;->close()V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_2

    goto :goto_6

    :catch_2
    move-exception v2

    .line 808
    :cond_9
    :goto_6
    new-instance v2, Ljava/io/File;

    invoke-direct {v2, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    goto :goto_4

    .line 810
    :goto_7
    return-void

    .line 807
    :goto_8
    if-eqz v0, :cond_a

    :try_start_7
    invoke-virtual {v0}, Ljava/util/zip/ZipInputStream;->close()V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_3

    goto :goto_9

    :catch_3
    move-exception v3

    .line 808
    :cond_a
    :goto_9
    new-instance v3, Ljava/io/File;

    invoke-direct {v3, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    .line 809
    throw v2
.end method

.method private static normalizeUrl(Ljava/lang/String;)Ljava/lang/String;
    .locals 10
    .param p0, "raw"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 349
    const/4 v0, 0x0

    .line 351
    .local v0, "needs":Z
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    if-ge v1, v2, :cond_2

    .line 353
    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v2

    .line 354
    .local v2, "c":C
    const/16 v3, 0x20

    if-eq v2, v3, :cond_1

    const/16 v3, 0x7f

    if-le v2, v3, :cond_0

    goto :goto_1

    .line 351
    .end local v2    # "c":C
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 356
    .restart local v2    # "c":C
    :cond_1
    :goto_1
    const/4 v0, 0x1

    .line 357
    nop

    .line 361
    .end local v1    # "i":I
    .end local v2    # "c":C
    :cond_2
    if-nez v0, :cond_3

    .line 362
    return-object p0

    .line 364
    :cond_3
    new-instance v1, Ljava/net/URL;

    invoke-direct {v1, p0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 366
    .local v1, "parsed":Ljava/net/URL;
    new-instance v2, Ljava/net/URI;

    .line 367
    invoke-virtual {v1}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1}, Ljava/net/URL;->getUserInfo()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1}, Ljava/net/URL;->getPort()I

    move-result v6

    .line 368
    invoke-virtual {v1}, Ljava/net/URL;->getPath()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v1}, Ljava/net/URL;->getQuery()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1}, Ljava/net/URL;->getRef()Ljava/lang/String;

    move-result-object v9

    invoke-direct/range {v2 .. v9}, Ljava/net/URI;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/net/URI;->toASCIIString()Ljava/lang/String;

    move-result-object v2

    .line 366
    return-object v2
.end method

.method public static poll(I)I
    .locals 2
    .param p0, "id"    # I

    .line 890
    sget-object v0, Lorg/emulationstation/frontend/HttpBridge;->REQUESTS:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/emulationstation/frontend/HttpBridge$Request;

    .line 891
    .local v0, "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    if-nez v0, :cond_0

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    iget v1, v0, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I

    :goto_0
    return v1
.end method

.method public static progress(I)[J
    .locals 7
    .param p0, "id"    # I

    .line 909
    sget-object v0, Lorg/emulationstation/frontend/HttpBridge;->REQUESTS:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/emulationstation/frontend/HttpBridge$Request;

    .line 910
    .local v0, "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    const/4 v1, 0x2

    if-nez v0, :cond_0

    .line 911
    new-array v1, v1, [J

    fill-array-data v1, :array_0

    return-object v1

    .line 913
    :cond_0
    iget-object v2, v0, Lorg/emulationstation/frontend/HttpBridge$Request;->downloadedBytes:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v2

    iget-wide v4, v0, Lorg/emulationstation/frontend/HttpBridge$Request;->total:J

    new-array v1, v1, [J

    const/4 v6, 0x0

    aput-wide v2, v1, v6

    const/4 v2, 0x1

    aput-wide v4, v1, v2

    return-object v1

    :array_0
    .array-data 8
        0x0
        -0x1
    .end array-data
.end method

.method private static redactUrl(Ljava/lang/String;)Ljava/lang/String;
    .locals 6
    .param p0, "url"    # Ljava/lang/String;

    .line 327
    const-string v0, "/drawers.json/"

    .line 328
    .local v0, "marker":Ljava/lang/String;
    const-string v1, "/drawers.json/"

    invoke-virtual {p0, v1}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v2

    .line 330
    .local v2, "at":I
    if-gez v2, :cond_0

    .line 331
    return-object p0

    .line 333
    :cond_0
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    add-int/2addr v1, v2

    .line 334
    .local v1, "from":I
    const/16 v3, 0x2f

    invoke-virtual {p0, v3, v1}, Ljava/lang/String;->indexOf(II)I

    move-result v3

    .line 336
    .local v3, "to":I
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    invoke-virtual {p0, v5, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "<chave>"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    if-gez v3, :cond_1

    const-string v5, ""

    goto :goto_0

    :cond_1
    invoke-virtual {p0, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    :goto_0
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    return-object v4
.end method

.method public static release(I)V
    .locals 2
    .param p0, "id"    # I

    .line 929
    sget-object v0, Lorg/emulationstation/frontend/HttpBridge;->REQUESTS:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/emulationstation/frontend/HttpBridge$Request;

    .line 930
    .local v0, "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    if-eqz v0, :cond_0

    .line 931
    const/4 v1, 0x1

    iput-boolean v1, v0, Lorg/emulationstation/frontend/HttpBridge$Request;->cancelled:Z

    .line 932
    :cond_0
    return-void
.end method

.method public static start(Ljava/lang/String;)I
    .locals 2
    .param p0, "url"    # Ljava/lang/String;

    .line 138
    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p0, v0, v0, v1}, Lorg/emulationstation/frontend/HttpBridge;->startInternal(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)I

    move-result v0

    return v0
.end method

.method public static startCoreDownload(Ljava/lang/String;Ljava/lang/String;)I
    .locals 2
    .param p0, "url"    # Ljava/lang/String;
    .param p1, "destDir"    # Ljava/lang/String;

    .line 250
    new-instance v0, Ljava/io/File;

    const-string v1, ".core-download.zip"

    invoke-direct {v0, p1, v1}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {p0, v0, p1, v1}, Lorg/emulationstation/frontend/HttpBridge;->startInternal(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)I

    move-result v0

    return v0
.end method

.method public static startDownload(Ljava/lang/String;Ljava/lang/String;)I
    .locals 2
    .param p0, "url"    # Ljava/lang/String;
    .param p1, "destPath"    # Ljava/lang/String;

    .line 240
    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p0, p1, v0, v1}, Lorg/emulationstation/frontend/HttpBridge;->startInternal(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)I

    move-result v0

    return v0
.end method

.method private static startInternal(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)I
    .locals 9
    .param p0, "url"    # Ljava/lang/String;
    .param p1, "destPath"    # Ljava/lang/String;
    .param p2, "extractDir"    # Ljava/lang/String;
    .param p3, "extractAll"    # Z

    .line 265
    sget-object v0, Lorg/emulationstation/frontend/HttpBridge;->NEXT_ID:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v1

    .line 266
    .local v1, "id":I
    new-instance v0, Lorg/emulationstation/frontend/HttpBridge$Request;

    const/4 v2, 0x0

    invoke-direct {v0, v2}, Lorg/emulationstation/frontend/HttpBridge$Request;-><init>(Lorg/emulationstation/frontend/HttpBridge-IA;)V

    move-object v6, v0

    .line 267
    .local v6, "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    const/4 v0, 0x1

    const/4 v2, 0x0

    if-eqz p2, :cond_0

    move v3, v0

    goto :goto_0

    :cond_0
    move v3, v2

    :goto_0
    iput-boolean v3, v6, Lorg/emulationstation/frontend/HttpBridge$Request;->deferSuccess:Z

    .line 269
    if-eqz p1, :cond_3

    .line 271
    iput-boolean v0, v6, Lorg/emulationstation/frontend/HttpBridge$Request;->isFile:Z

    .line 274
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v0

    .line 275
    .local v0, "name":Ljava/lang/String;
    const/16 v3, 0x2e

    invoke-virtual {v0, v3}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v3

    .line 276
    .local v3, "dot":I
    if-lez v3, :cond_1

    .line 277
    invoke-virtual {v0, v2, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    .line 279
    :cond_1
    if-eqz p2, :cond_2

    const-string v2, "emulador"

    goto :goto_1

    :cond_2
    move-object v2, v0

    :goto_1
    iput-object v2, v6, Lorg/emulationstation/frontend/HttpBridge$Request;->title:Ljava/lang/String;

    .line 282
    .end local v0    # "name":Ljava/lang/String;
    .end local v3    # "dot":I
    :cond_3
    sget-object v0, Lorg/emulationstation/frontend/HttpBridge;->REQUESTS:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2, v6}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 286
    if-eqz p1, :cond_4

    :try_start_0
    sget-object v0, Lorg/emulationstation/frontend/HttpBridge;->FILE_POOL:Ljava/util/concurrent/ExecutorService;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    .line 309
    :catch_0
    move-exception v0

    move-object v4, p0

    move-object v5, p1

    move-object v7, p2

    move v8, p3

    goto :goto_3

    .line 286
    :cond_4
    :try_start_1
    sget-object v0, Lorg/emulationstation/frontend/HttpBridge;->POOL:Ljava/util/concurrent/ExecutorService;

    :goto_2
    new-instance v3, Lorg/emulationstation/frontend/HttpBridge$2;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2

    move-object v4, p0

    move-object v5, p1

    move-object v7, p2

    move v8, p3

    .end local p0    # "url":Ljava/lang/String;
    .end local p1    # "destPath":Ljava/lang/String;
    .end local p2    # "extractDir":Ljava/lang/String;
    .end local p3    # "extractAll":Z
    .local v4, "url":Ljava/lang/String;
    .local v5, "destPath":Ljava/lang/String;
    .local v7, "extractDir":Ljava/lang/String;
    .local v8, "extractAll":Z
    :try_start_2
    invoke-direct/range {v3 .. v8}, Lorg/emulationstation/frontend/HttpBridge$2;-><init>(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;Ljava/lang/String;Z)V

    invoke-interface {v0, v3}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 306
    if-eqz v5, :cond_5

    .line 307
    invoke-static {}, Lorg/emulationstation/frontend/DownloadService;->ensureRunning()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 314
    :cond_5
    goto :goto_4

    .line 309
    :catch_1
    move-exception v0

    goto :goto_3

    .end local v4    # "url":Ljava/lang/String;
    .end local v5    # "destPath":Ljava/lang/String;
    .end local v7    # "extractDir":Ljava/lang/String;
    .end local v8    # "extractAll":Z
    .restart local p0    # "url":Ljava/lang/String;
    .restart local p1    # "destPath":Ljava/lang/String;
    .restart local p2    # "extractDir":Ljava/lang/String;
    .restart local p3    # "extractAll":Z
    :catch_2
    move-exception v0

    move-object v4, p0

    move-object v5, p1

    move-object v7, p2

    move v8, p3

    .line 311
    .end local p0    # "url":Ljava/lang/String;
    .end local p1    # "destPath":Ljava/lang/String;
    .end local p2    # "extractDir":Ljava/lang/String;
    .end local p3    # "extractAll":Z
    .local v0, "e":Ljava/lang/Exception;
    .restart local v4    # "url":Ljava/lang/String;
    .restart local v5    # "destPath":Ljava/lang/String;
    .restart local v7    # "extractDir":Ljava/lang/String;
    .restart local v8    # "extractAll":Z
    :goto_3
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p1, "Could not queue request for "

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "EmulationStation"

    invoke-static {p1, p0, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 312
    const/4 p0, 0x2

    iput p0, v6, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I

    .line 313
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    iput-object p0, v6, Lorg/emulationstation/frontend/HttpBridge$Request;->error:Ljava/lang/String;

    .line 316
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_4
    return v1
.end method

.method public static startPost(Ljava/lang/String;Ljava/lang/String;)I
    .locals 5
    .param p0, "url"    # Ljava/lang/String;
    .param p1, "formBody"    # Ljava/lang/String;

    .line 148
    sget-object v0, Lorg/emulationstation/frontend/HttpBridge;->NEXT_ID:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    .line 149
    .local v0, "id":I
    new-instance v1, Lorg/emulationstation/frontend/HttpBridge$Request;

    const/4 v2, 0x0

    invoke-direct {v1, v2}, Lorg/emulationstation/frontend/HttpBridge$Request;-><init>(Lorg/emulationstation/frontend/HttpBridge-IA;)V

    .line 150
    .local v1, "request":Lorg/emulationstation/frontend/HttpBridge$Request;
    sget-object v2, Lorg/emulationstation/frontend/HttpBridge;->REQUESTS:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3, v1}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 154
    :try_start_0
    sget-object v2, Lorg/emulationstation/frontend/HttpBridge;->POOL:Ljava/util/concurrent/ExecutorService;

    new-instance v3, Lorg/emulationstation/frontend/HttpBridge$1;

    invoke-direct {v3, p0, p1, v1}, Lorg/emulationstation/frontend/HttpBridge$1;-><init>(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;)V

    invoke-interface {v2, v3}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 167
    goto :goto_0

    .line 162
    :catch_0
    move-exception v2

    .line 164
    .local v2, "e":Ljava/lang/Exception;
    const-string v3, "EmulationStation"

    const-string v4, "Could not queue POST"

    invoke-static {v3, v4, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 165
    const/4 v3, 0x2

    iput v3, v1, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I

    .line 166
    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, v1, Lorg/emulationstation/frontend/HttpBridge$Request;->error:Ljava/lang/String;

    .line 169
    .end local v2    # "e":Ljava/lang/Exception;
    :goto_0
    return v0
.end method

.method public static startZipDownload(Ljava/lang/String;Ljava/lang/String;)I
    .locals 2
    .param p0, "url"    # Ljava/lang/String;
    .param p1, "destDir"    # Ljava/lang/String;

    .line 260
    new-instance v0, Ljava/io/File;

    const-string v1, ".pack-download.zip"

    invoke-direct {v0, p1, v1}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {p0, v0, p1, v1}, Lorg/emulationstation/frontend/HttpBridge;->startInternal(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)I

    move-result v0

    return v0
.end method
