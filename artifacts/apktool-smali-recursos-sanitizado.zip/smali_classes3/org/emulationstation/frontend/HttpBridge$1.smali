.class Lorg/emulationstation/frontend/HttpBridge$1;
.super Ljava/lang/Object;
.source "HttpBridge.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/emulationstation/frontend/HttpBridge;->startPost(Ljava/lang/String;Ljava/lang/String;)I
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$formBody:Ljava/lang/String;

.field final synthetic val$request:Lorg/emulationstation/frontend/HttpBridge$Request;

.field final synthetic val$url:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 154
    iput-object p1, p0, Lorg/emulationstation/frontend/HttpBridge$1;->val$url:Ljava/lang/String;

    iput-object p2, p0, Lorg/emulationstation/frontend/HttpBridge$1;->val$formBody:Ljava/lang/String;

    iput-object p3, p0, Lorg/emulationstation/frontend/HttpBridge$1;->val$request:Lorg/emulationstation/frontend/HttpBridge$Request;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 158
    iget-object v0, p0, Lorg/emulationstation/frontend/HttpBridge$1;->val$url:Ljava/lang/String;

    iget-object v1, p0, Lorg/emulationstation/frontend/HttpBridge$1;->val$formBody:Ljava/lang/String;

    iget-object v2, p0, Lorg/emulationstation/frontend/HttpBridge$1;->val$request:Lorg/emulationstation/frontend/HttpBridge$Request;

    invoke-static {v0, v1, v2}, Lorg/emulationstation/frontend/HttpBridge;->-$$Nest$smexecutePost(Ljava/lang/String;Ljava/lang/String;Lorg/emulationstation/frontend/HttpBridge$Request;)V

    .line 159
    return-void
.end method
