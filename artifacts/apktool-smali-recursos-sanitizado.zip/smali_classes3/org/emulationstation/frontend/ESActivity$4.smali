.class Lorg/emulationstation/frontend/ESActivity$4;
.super Ljava/lang/Object;
.source "ESActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/emulationstation/frontend/ESActivity;->requestStorageAccess()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$activity:Lorg/emulationstation/frontend/ESActivity;


# direct methods
.method constructor <init>(Lorg/emulationstation/frontend/ESActivity;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 730
    iput-object p1, p0, Lorg/emulationstation/frontend/ESActivity$4;->val$activity:Lorg/emulationstation/frontend/ESActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 734
    iget-object v0, p0, Lorg/emulationstation/frontend/ESActivity$4;->val$activity:Lorg/emulationstation/frontend/ESActivity;

    invoke-static {v0}, Lorg/emulationstation/frontend/ESActivity;->-$$Nest$mstartStorageRequest(Lorg/emulationstation/frontend/ESActivity;)V

    .line 735
    return-void
.end method
