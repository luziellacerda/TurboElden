.class Lorg/emulationstation/frontend/LoadingOverlay$1;
.super Ljava/lang/Object;
.source "LoadingOverlay.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/emulationstation/frontend/LoadingOverlay;->show(Landroid/app/Activity;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$activity:Landroid/app/Activity;

.field final synthetic val$name:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;Landroid/app/Activity;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 122
    iput-object p1, p0, Lorg/emulationstation/frontend/LoadingOverlay$1;->val$name:Ljava/lang/String;

    iput-object p2, p0, Lorg/emulationstation/frontend/LoadingOverlay$1;->val$activity:Landroid/app/Activity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    .line 126
    invoke-static {}, Lorg/emulationstation/frontend/LoadingOverlay;->-$$Nest$sfgetsView()Lorg/emulationstation/frontend/LoadingOverlay;

    move-result-object v0

    const/high16 v1, 0x3f800000    # 1.0f

    if-eqz v0, :cond_0

    .line 128
    invoke-static {}, Lorg/emulationstation/frontend/LoadingOverlay;->-$$Nest$sfgetsView()Lorg/emulationstation/frontend/LoadingOverlay;

    move-result-object v0

    iget-object v2, p0, Lorg/emulationstation/frontend/LoadingOverlay$1;->val$name:Ljava/lang/String;

    invoke-static {v0, v2}, Lorg/emulationstation/frontend/LoadingOverlay;->-$$Nest$fputmName(Lorg/emulationstation/frontend/LoadingOverlay;Ljava/lang/String;)V

    .line 129
    invoke-static {}, Lorg/emulationstation/frontend/LoadingOverlay;->-$$Nest$sfgetsView()Lorg/emulationstation/frontend/LoadingOverlay;

    move-result-object v0

    invoke-virtual {v0}, Lorg/emulationstation/frontend/LoadingOverlay;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->cancel()V

    .line 130
    invoke-static {}, Lorg/emulationstation/frontend/LoadingOverlay;->-$$Nest$sfgetsView()Lorg/emulationstation/frontend/LoadingOverlay;

    move-result-object v0

    invoke-virtual {v0, v1}, Lorg/emulationstation/frontend/LoadingOverlay;->setAlpha(F)V

    .line 131
    return-void

    .line 134
    :cond_0
    new-instance v0, Lorg/emulationstation/frontend/LoadingOverlay;

    iget-object v2, p0, Lorg/emulationstation/frontend/LoadingOverlay$1;->val$activity:Landroid/app/Activity;

    iget-object v3, p0, Lorg/emulationstation/frontend/LoadingOverlay$1;->val$name:Ljava/lang/String;

    const/4 v4, 0x0

    invoke-direct {v0, v2, v3, v4}, Lorg/emulationstation/frontend/LoadingOverlay;-><init>(Landroid/content/Context;Ljava/lang/String;Lorg/emulationstation/frontend/LoadingOverlay-IA;)V

    invoke-static {v0}, Lorg/emulationstation/frontend/LoadingOverlay;->-$$Nest$sfputsView(Lorg/emulationstation/frontend/LoadingOverlay;)V

    .line 135
    invoke-static {}, Lorg/emulationstation/frontend/LoadingOverlay;->-$$Nest$sfgetsView()Lorg/emulationstation/frontend/LoadingOverlay;

    move-result-object v0

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Lorg/emulationstation/frontend/LoadingOverlay;->setAlpha(F)V

    .line 136
    iget-object v0, p0, Lorg/emulationstation/frontend/LoadingOverlay$1;->val$activity:Landroid/app/Activity;

    invoke-static {}, Lorg/emulationstation/frontend/LoadingOverlay;->-$$Nest$sfgetsView()Lorg/emulationstation/frontend/LoadingOverlay;

    move-result-object v2

    new-instance v3, Landroid/view/ViewGroup$LayoutParams;

    const/4 v4, -0x1

    invoke-direct {v3, v4, v4}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v2, v3}, Landroid/app/Activity;->addContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 137
    invoke-static {}, Lorg/emulationstation/frontend/LoadingOverlay;->-$$Nest$sfgetsView()Lorg/emulationstation/frontend/LoadingOverlay;

    move-result-object v0

    invoke-virtual {v0}, Lorg/emulationstation/frontend/LoadingOverlay;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const-wide/16 v1, 0xa0

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    .line 138
    return-void
.end method
