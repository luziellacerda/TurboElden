.class Lorg/emulationstation/frontend/DownloadService$1;
.super Ljava/lang/Object;
.source "DownloadService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/emulationstation/frontend/DownloadService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lorg/emulationstation/frontend/DownloadService;


# direct methods
.method constructor <init>(Lorg/emulationstation/frontend/DownloadService;)V
    .locals 0
    .param p1, "this$0"    # Lorg/emulationstation/frontend/DownloadService;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 136
    iput-object p1, p0, Lorg/emulationstation/frontend/DownloadService$1;->this$0:Lorg/emulationstation/frontend/DownloadService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .line 140
    invoke-static {}, Lorg/emulationstation/frontend/HttpBridge;->activeFileDownloads()Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;

    move-result-object v0

    iget v0, v0, Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;->count:I

    .line 146
    iget-object v1, p0, Lorg/emulationstation/frontend/DownloadService$1;->this$0:Lorg/emulationstation/frontend/DownloadService;

    .line 140
    if-nez v0, :cond_0

    .line 142
    invoke-virtual {v1}, Lorg/emulationstation/frontend/DownloadService;->stopSelf()V

    .line 143
    return-void

    .line 146
    :cond_0
    const-string v0, "notification"

    invoke-virtual {v1, v0}, Lorg/emulationstation/frontend/DownloadService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    .line 147
    .local v0, "manager":Landroid/app/NotificationManager;
    if-eqz v0, :cond_1

    .line 148
    iget-object v1, p0, Lorg/emulationstation/frontend/DownloadService$1;->this$0:Lorg/emulationstation/frontend/DownloadService;

    invoke-static {v1}, Lorg/emulationstation/frontend/DownloadService;->-$$Nest$mbuildProgress(Lorg/emulationstation/frontend/DownloadService;)Landroid/app/Notification;

    move-result-object v1

    const/16 v2, 0x1b59

    invoke-virtual {v0, v2, v1}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    .line 150
    :cond_1
    iget-object v1, p0, Lorg/emulationstation/frontend/DownloadService$1;->this$0:Lorg/emulationstation/frontend/DownloadService;

    invoke-static {v1}, Lorg/emulationstation/frontend/DownloadService;->-$$Nest$fgetmHandler(Lorg/emulationstation/frontend/DownloadService;)Landroid/os/Handler;

    move-result-object v1

    const-wide/16 v2, 0x3e8

    invoke-virtual {v1, p0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 151
    return-void
.end method
