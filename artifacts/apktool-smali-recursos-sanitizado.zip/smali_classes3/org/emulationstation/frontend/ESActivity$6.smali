.class Lorg/emulationstation/frontend/ESActivity$6;
.super Ljava/lang/Object;
.source "ESActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/emulationstation/frontend/ESActivity;->restartApp()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$activity:Lorg/emulationstation/frontend/ESActivity;


# direct methods
.method constructor <init>(Lorg/emulationstation/frontend/ESActivity;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 813
    iput-object p1, p0, Lorg/emulationstation/frontend/ESActivity$6;->val$activity:Lorg/emulationstation/frontend/ESActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 817
    const-string v0, "EmulationStation"

    const-string v1, "Restarting the app in a fresh process"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 819
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lorg/emulationstation/frontend/ESActivity$6;->val$activity:Lorg/emulationstation/frontend/ESActivity;

    const-class v2, Lorg/emulationstation/frontend/RestartActivity;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 820
    .local v0, "restart":Landroid/content/Intent;
    const-string v1, "pid"

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 821
    const/high16 v1, 0x10000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 822
    iget-object v1, p0, Lorg/emulationstation/frontend/ESActivity$6;->val$activity:Lorg/emulationstation/frontend/ESActivity;

    invoke-virtual {v1, v0}, Lorg/emulationstation/frontend/ESActivity;->startActivity(Landroid/content/Intent;)V

    .line 823
    return-void
.end method
