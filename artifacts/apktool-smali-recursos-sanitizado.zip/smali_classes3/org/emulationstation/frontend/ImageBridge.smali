.class public final Lorg/emulationstation/frontend/ImageBridge;
.super Ljava/lang/Object;
.source "ImageBridge.java"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static decode([B)[I
    .locals 1
    .param p0, "data"    # [B

    .line 24
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lorg/emulationstation/frontend/ImageBridge;->decode([BI)[I

    move-result-object v0

    return-object v0
.end method

.method public static decode([BI)[I
    .locals 14
    .param p0, "data"    # [B
    .param p1, "wantedHeight"    # I

    .line 37
    const-string v1, "EmulationStation"

    const/4 v2, 0x0

    if-eqz p0, :cond_4

    array-length v0, p0

    if-nez v0, :cond_0

    goto :goto_1

    .line 42
    :cond_0
    :try_start_0
    new-instance v0, Landroid/graphics/BitmapFactory$Options;

    invoke-direct {v0}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    .line 44
    .local v0, "options":Landroid/graphics/BitmapFactory$Options;
    const/4 v3, 0x1

    const/4 v4, 0x0

    if-lez p1, :cond_2

    .line 46
    iput-boolean v3, v0, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    .line 47
    array-length v5, p0

    invoke-static {p0, v4, v5, v0}, Landroid/graphics/BitmapFactory;->decodeByteArray([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    .line 49
    const/4 v5, 0x1

    .line 50
    .local v5, "sample":I
    :goto_0
    iget v6, v0, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    if-lez v6, :cond_1

    iget v6, v0, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    mul-int/lit8 v7, v5, 0x2

    div-int/2addr v6, v7

    if-lt v6, p1, :cond_1

    .line 51
    mul-int/lit8 v5, v5, 0x2

    goto :goto_0

    .line 53
    :cond_1
    new-instance v6, Landroid/graphics/BitmapFactory$Options;

    invoke-direct {v6}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    move-object v0, v6

    .line 54
    iput v5, v0, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    .line 57
    .end local v5    # "sample":I
    :cond_2
    sget-object v5, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    iput-object v5, v0, Landroid/graphics/BitmapFactory$Options;->inPreferredConfig:Landroid/graphics/Bitmap$Config;

    .line 58
    iput-boolean v4, v0, Landroid/graphics/BitmapFactory$Options;->inScaled:Z

    .line 62
    iput-boolean v4, v0, Landroid/graphics/BitmapFactory$Options;->inPremultiplied:Z

    .line 64
    array-length v5, p0

    invoke-static {p0, v4, v5, v0}, Landroid/graphics/BitmapFactory;->decodeByteArray([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object v5

    move-object v6, v5

    .line 65
    .local v6, "bitmap":Landroid/graphics/Bitmap;
    if-nez v6, :cond_3

    .line 66
    return-object v2

    .line 68
    :cond_3
    invoke-virtual {v6}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v9

    .line 69
    .local v9, "width":I
    invoke-virtual {v6}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v13

    .line 71
    .local v13, "height":I
    mul-int v5, v9, v13

    add-int/lit8 v5, v5, 0x2

    new-array v7, v5, [I

    .line 72
    .local v7, "result":[I
    aput v9, v7, v4

    .line 73
    aput v13, v7, v3

    .line 75
    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v8, 0x2

    move v12, v9

    invoke-virtual/range {v6 .. v13}, Landroid/graphics/Bitmap;->getPixels([IIIIIII)V

    .line 76
    invoke-virtual {v6}, Landroid/graphics/Bitmap;->recycle()V
    :try_end_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 78
    return-object v7

    .line 87
    .end local v0    # "options":Landroid/graphics/BitmapFactory$Options;
    .end local v6    # "bitmap":Landroid/graphics/Bitmap;
    .end local v7    # "result":[I
    .end local v9    # "width":I
    .end local v13    # "height":I
    :catch_0
    move-exception v0

    .line 89
    .local v0, "e":Ljava/lang/Exception;
    const-string v3, "Could not decode an image"

    invoke-static {v1, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 90
    return-object v2

    .line 80
    .end local v0    # "e":Ljava/lang/Exception;
    :catch_1
    move-exception v0

    .line 84
    .local v0, "e":Ljava/lang/OutOfMemoryError;
    const-string v3, "Out of memory decoding an image"

    invoke-static {v1, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 85
    return-object v2

    .line 38
    .end local v0    # "e":Ljava/lang/OutOfMemoryError;
    :cond_4
    :goto_1
    return-object v2
.end method
