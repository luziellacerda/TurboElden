.class public final synthetic Lorg/emulationstation/frontend/LoadingOverlay-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
