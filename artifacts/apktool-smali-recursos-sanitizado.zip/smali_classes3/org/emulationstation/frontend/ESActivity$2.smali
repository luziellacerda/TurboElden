.class Lorg/emulationstation/frontend/ESActivity$2;
.super Ljava/lang/Object;
.source "ESActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/emulationstation/frontend/ESActivity;->onActivityResult(IILandroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lorg/emulationstation/frontend/ESActivity;

.field final synthetic val$uri:Landroid/net/Uri;


# direct methods
.method constructor <init>(Lorg/emulationstation/frontend/ESActivity;Landroid/net/Uri;)V
    .locals 0
    .param p1, "this$0"    # Lorg/emulationstation/frontend/ESActivity;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 237
    iput-object p2, p0, Lorg/emulationstation/frontend/ESActivity$2;->val$uri:Landroid/net/Uri;

    iput-object p1, p0, Lorg/emulationstation/frontend/ESActivity$2;->this$0:Lorg/emulationstation/frontend/ESActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 241
    iget-object v0, p0, Lorg/emulationstation/frontend/ESActivity$2;->val$uri:Landroid/net/Uri;

    invoke-static {v0}, Lorg/emulationstation/frontend/ESActivity;->-$$Nest$smsaveProfileImage(Landroid/net/Uri;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x2

    goto :goto_0

    :cond_0
    const/4 v0, 0x3

    :goto_0
    invoke-static {v0}, Lorg/emulationstation/frontend/ESActivity;->-$$Nest$sfputsProfilePickState(I)V

    .line 242
    return-void
.end method
