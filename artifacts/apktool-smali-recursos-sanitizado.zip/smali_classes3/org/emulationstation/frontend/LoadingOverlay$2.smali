.class Lorg/emulationstation/frontend/LoadingOverlay$2;
.super Ljava/lang/Object;
.source "LoadingOverlay.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/emulationstation/frontend/LoadingOverlay;->hide(Landroid/app/Activity;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .line 148
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .line 152
    invoke-static {}, Lorg/emulationstation/frontend/LoadingOverlay;->-$$Nest$sfgetsView()Lorg/emulationstation/frontend/LoadingOverlay;

    move-result-object v0

    .line 153
    .local v0, "view":Lorg/emulationstation/frontend/LoadingOverlay;
    if-nez v0, :cond_0

    .line 154
    return-void

    .line 156
    :cond_0
    const/4 v1, 0x0

    invoke-static {v1}, Lorg/emulationstation/frontend/LoadingOverlay;->-$$Nest$sfputsView(Lorg/emulationstation/frontend/LoadingOverlay;)V

    .line 157
    invoke-virtual {v0}, Lorg/emulationstation/frontend/LoadingOverlay;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    const-wide/16 v2, 0xf0

    invoke-virtual {v1, v2, v3}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    new-instance v2, Lorg/emulationstation/frontend/LoadingOverlay$2$1;

    invoke-direct {v2, p0, v0}, Lorg/emulationstation/frontend/LoadingOverlay$2$1;-><init>(Lorg/emulationstation/frontend/LoadingOverlay$2;Lorg/emulationstation/frontend/LoadingOverlay;)V

    invoke-virtual {v1, v2}, Landroid/view/ViewPropertyAnimator;->withEndAction(Ljava/lang/Runnable;)Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    .line 165
    invoke-virtual {v1}, Landroid/view/ViewPropertyAnimator;->start()V

    .line 166
    return-void
.end method
