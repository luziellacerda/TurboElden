.class final Lorg/emulationstation/frontend/HttpBridge$Request;
.super Ljava/lang/Object;
.source "HttpBridge.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/emulationstation/frontend/HttpBridge;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Request"
.end annotation


# instance fields
.field volatile cancelled:Z

.field volatile content:[B

.field volatile deferSuccess:Z

.field volatile downloadOk:Z

.field final downloadedBytes:Ljava/util/concurrent/atomic/AtomicLong;

.field volatile error:Ljava/lang/String;

.field volatile isFile:Z

.field volatile status:I

.field volatile title:Ljava/lang/String;

.field volatile total:J

.field volatile userCancelled:Z


# direct methods
.method private constructor <init>()V
    .locals 5

    .line 78
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 80
    const/4 v0, 0x0

    iput v0, p0, Lorg/emulationstation/frontend/HttpBridge$Request;->status:I

    .line 82
    const-string v1, ""

    iput-object v1, p0, Lorg/emulationstation/frontend/HttpBridge$Request;->error:Ljava/lang/String;

    .line 86
    new-instance v2, Ljava/util/concurrent/atomic/AtomicLong;

    const-wide/16 v3, 0x0

    invoke-direct {v2, v3, v4}, Ljava/util/concurrent/atomic/AtomicLong;-><init>(J)V

    iput-object v2, p0, Lorg/emulationstation/frontend/HttpBridge$Request;->downloadedBytes:Ljava/util/concurrent/atomic/AtomicLong;

    .line 87
    const-wide/16 v2, -0x1

    iput-wide v2, p0, Lorg/emulationstation/frontend/HttpBridge$Request;->total:J

    .line 88
    iput-boolean v0, p0, Lorg/emulationstation/frontend/HttpBridge$Request;->cancelled:Z

    .line 92
    iput-boolean v0, p0, Lorg/emulationstation/frontend/HttpBridge$Request;->deferSuccess:Z

    .line 93
    iput-boolean v0, p0, Lorg/emulationstation/frontend/HttpBridge$Request;->downloadOk:Z

    .line 96
    iput-boolean v0, p0, Lorg/emulationstation/frontend/HttpBridge$Request;->isFile:Z

    .line 97
    iput-object v1, p0, Lorg/emulationstation/frontend/HttpBridge$Request;->title:Ljava/lang/String;

    .line 101
    iput-boolean v0, p0, Lorg/emulationstation/frontend/HttpBridge$Request;->userCancelled:Z

    return-void
.end method

.method synthetic constructor <init>(Lorg/emulationstation/frontend/HttpBridge-IA;)V
    .locals 0

    invoke-direct {p0}, Lorg/emulationstation/frontend/HttpBridge$Request;-><init>()V

    return-void
.end method
