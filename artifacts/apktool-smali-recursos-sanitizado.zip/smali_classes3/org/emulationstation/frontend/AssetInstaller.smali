.class public final Lorg/emulationstation/frontend/AssetInstaller;
.super Ljava/lang/Object;
.source "AssetInstaller.java"


# static fields
.field private static final ASSET_ROOT:Ljava/lang/String; = "resources"

.field private static final BIOS_ROOT:Ljava/lang/String; = "bios"

.field private static final MARKER_NAME:Ljava/lang/String; = ".installed-version"

.field private static final PACKS:[[Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$smextractPack(Landroid/content/res/AssetManager;Ljava/lang/String;Ljava/io/File;)I
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/emulationstation/frontend/AssetInstaller;->extractPack(Landroid/content/res/AssetManager;Ljava/lang/String;Ljava/io/File;)I

    move-result p0

    return p0
.end method

.method static constructor <clinit>()V
    .locals 5

    .line 82
    const/4 v0, 0x1

    new-array v1, v0, [[Ljava/lang/String;

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "packs/Dolphin.zip"

    const/4 v4, 0x0

    aput-object v3, v2, v4

    const-string v3, ".pack-dolphin_libretro_android.so.ok"

    aput-object v3, v2, v0

    aput-object v2, v1, v4

    sput-object v1, Lorg/emulationstation/frontend/AssetInstaller;->PACKS:[[Ljava/lang/String;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 33
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static closeQuietly(Ljava/io/Closeable;)V
    .locals 1
    .param p0, "closeable"    # Ljava/io/Closeable;

    .line 332
    if-nez p0, :cond_0

    .line 333
    return-void

    .line 337
    :cond_0
    :try_start_0
    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 341
    goto :goto_0

    .line 339
    :catch_0
    move-exception v0

    .line 342
    :goto_0
    return-void
.end method

.method private static copyAssetDir(Landroid/content/res/AssetManager;Ljava/lang/String;Ljava/io/File;)V
    .locals 6
    .param p0, "assets"    # Landroid/content/res/AssetManager;
    .param p1, "assetPath"    # Ljava/lang/String;
    .param p2, "target"    # Ljava/io/File;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 237
    invoke-virtual {p0, p1}, Landroid/content/res/AssetManager;->list(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 239
    .local v0, "entries":[Ljava/lang/String;
    if-eqz v0, :cond_4

    array-length v1, v0

    if-nez v1, :cond_0

    goto :goto_2

    .line 245
    :cond_0
    invoke-virtual {p2}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_2

    invoke-virtual {p2}, Ljava/io/File;->mkdirs()Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_0

    .line 246
    :cond_1
    new-instance v1, Ljava/io/IOException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "could not create "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 248
    :cond_2
    :goto_0
    array-length v1, v0

    const/4 v2, 0x0

    :goto_1
    if-ge v2, v1, :cond_3

    aget-object v3, v0, v2

    .line 249
    .local v3, "entry":Ljava/lang/String;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "/"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/io/File;

    invoke-direct {v5, p2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {p0, v4, v5}, Lorg/emulationstation/frontend/AssetInstaller;->copyAssetDir(Landroid/content/res/AssetManager;Ljava/lang/String;Ljava/io/File;)V

    .line 248
    .end local v3    # "entry":Ljava/lang/String;
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    .line 250
    :cond_3
    return-void

    .line 241
    :cond_4
    :goto_2
    invoke-static {p0, p1, p2}, Lorg/emulationstation/frontend/AssetInstaller;->copyAssetFile(Landroid/content/res/AssetManager;Ljava/lang/String;Ljava/io/File;)V

    .line 242
    return-void
.end method

.method private static copyAssetFile(Landroid/content/res/AssetManager;Ljava/lang/String;Ljava/io/File;)V
    .locals 6
    .param p0, "assets"    # Landroid/content/res/AssetManager;
    .param p1, "assetPath"    # Ljava/lang/String;
    .param p2, "target"    # Ljava/io/File;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 254
    invoke-virtual {p2}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v0

    .line 255
    .local v0, "parent":Ljava/io/File;
    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_1

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    .line 256
    :cond_0
    new-instance v1, Ljava/io/IOException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "could not create "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 258
    :cond_1
    :goto_0
    const/4 v1, 0x0

    .line 259
    .local v1, "in":Ljava/io/InputStream;
    const/4 v2, 0x0

    .line 263
    .local v2, "out":Ljava/io/OutputStream;
    :try_start_0
    invoke-virtual {p0, p1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v3

    move-object v1, v3

    .line 264
    new-instance v3, Ljava/io/FileOutputStream;

    invoke-direct {v3, p2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    move-object v2, v3

    .line 266
    const/16 v3, 0x4000

    new-array v3, v3, [B

    .line 269
    .local v3, "buffer":[B
    :goto_1
    invoke-virtual {v1, v3}, Ljava/io/InputStream;->read([B)I

    move-result v4

    move v5, v4

    .local v5, "read":I
    if-lez v4, :cond_2

    .line 270
    const/4 v4, 0x0

    invoke-virtual {v2, v3, v4, v5}, Ljava/io/OutputStream;->write([BII)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    .line 274
    .end local v3    # "buffer":[B
    .end local v5    # "read":I
    :cond_2
    invoke-static {v1}, Lorg/emulationstation/frontend/AssetInstaller;->closeQuietly(Ljava/io/Closeable;)V

    .line 275
    invoke-static {v2}, Lorg/emulationstation/frontend/AssetInstaller;->closeQuietly(Ljava/io/Closeable;)V

    .line 276
    nop

    .line 277
    return-void

    .line 274
    :catchall_0
    move-exception v3

    invoke-static {v1}, Lorg/emulationstation/frontend/AssetInstaller;->closeQuietly(Ljava/io/Closeable;)V

    .line 275
    invoke-static {v2}, Lorg/emulationstation/frontend/AssetInstaller;->closeQuietly(Ljava/io/Closeable;)V

    .line 276
    throw v3
.end method

.method private static extractPack(Landroid/content/res/AssetManager;Ljava/lang/String;Ljava/io/File;)I
    .locals 11
    .param p0, "assets"    # Landroid/content/res/AssetManager;
    .param p1, "assetPath"    # Ljava/lang/String;
    .param p2, "destDir"    # Ljava/io/File;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 154
    invoke-virtual {p2}, Ljava/io/File;->exists()Z

    move-result v0

    const-string v1, "could not create "

    if-nez v0, :cond_1

    invoke-virtual {p2}, Ljava/io/File;->mkdirs()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 155
    :cond_0
    new-instance v0, Ljava/io/IOException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 157
    :cond_1
    :goto_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p2}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    sget-object v2, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 158
    .local v0, "rootPath":Ljava/lang/String;
    new-instance v2, Ljava/util/zip/ZipInputStream;

    new-instance v3, Ljava/io/BufferedInputStream;

    invoke-virtual {p0, p1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v2, v3}, Ljava/util/zip/ZipInputStream;-><init>(Ljava/io/InputStream;)V

    .line 159
    .local v2, "zip":Ljava/util/zip/ZipInputStream;
    const/4 v3, 0x0

    .line 164
    .local v3, "files":I
    const/high16 v4, 0x10000

    :try_start_0
    new-array v4, v4, [B

    .line 166
    .local v4, "buffer":[B
    :goto_1
    invoke-virtual {v2}, Ljava/util/zip/ZipInputStream;->getNextEntry()Ljava/util/zip/ZipEntry;

    move-result-object v5

    move-object v6, v5

    .local v6, "entry":Ljava/util/zip/ZipEntry;
    if-eqz v5, :cond_7

    .line 168
    new-instance v5, Ljava/io/File;

    invoke-virtual {v6}, Ljava/util/zip/ZipEntry;->getName()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v5, p2, v7}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v5}, Ljava/io/File;->getCanonicalFile()Ljava/io/File;

    move-result-object v5

    .line 169
    .local v5, "target":Ljava/io/File;
    invoke-virtual {v5}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_6

    .line 172
    invoke-virtual {v6}, Ljava/util/zip/ZipEntry;->isDirectory()Z

    move-result v7

    if-eqz v7, :cond_2

    .line 174
    invoke-virtual {v5}, Ljava/io/File;->mkdirs()Z

    .line 175
    goto :goto_1

    .line 178
    :cond_2
    invoke-virtual {v5}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v7

    .line 179
    .local v7, "parent":Ljava/io/File;
    if-eqz v7, :cond_4

    invoke-virtual {v7}, Ljava/io/File;->exists()Z

    move-result v8

    if-nez v8, :cond_4

    invoke-virtual {v7}, Ljava/io/File;->mkdirs()Z

    move-result v8

    if-eqz v8, :cond_3

    goto :goto_2

    .line 180
    :cond_3
    new-instance v8, Ljava/io/IOException;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v8, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .end local v0    # "rootPath":Ljava/lang/String;
    .end local v2    # "zip":Ljava/util/zip/ZipInputStream;
    .end local v3    # "files":I
    .end local p0    # "assets":Landroid/content/res/AssetManager;
    .end local p1    # "assetPath":Ljava/lang/String;
    .end local p2    # "destDir":Ljava/io/File;
    throw v8

    .line 182
    .restart local v0    # "rootPath":Ljava/lang/String;
    .restart local v2    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v3    # "files":I
    .restart local p0    # "assets":Landroid/content/res/AssetManager;
    .restart local p1    # "assetPath":Ljava/lang/String;
    .restart local p2    # "destDir":Ljava/io/File;
    :cond_4
    :goto_2
    new-instance v8, Ljava/io/FileOutputStream;

    invoke-direct {v8, v5}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 186
    .local v8, "out":Ljava/io/OutputStream;
    :goto_3
    :try_start_1
    invoke-virtual {v2, v4}, Ljava/util/zip/ZipInputStream;->read([B)I

    move-result v9

    move v10, v9

    .local v10, "read":I
    if-lez v9, :cond_5

    .line 187
    const/4 v9, 0x0

    invoke-virtual {v8, v4, v9, v10}, Ljava/io/OutputStream;->write([BII)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_3

    .line 191
    .end local v10    # "read":I
    :cond_5
    :try_start_2
    invoke-virtual {v8}, Ljava/io/OutputStream;->close()V

    .line 192
    nop

    .line 194
    nop

    .end local v5    # "target":Ljava/io/File;
    .end local v7    # "parent":Ljava/io/File;
    .end local v8    # "out":Ljava/io/OutputStream;
    add-int/lit8 v3, v3, 0x1

    .line 195
    goto :goto_1

    .line 191
    .restart local v5    # "target":Ljava/io/File;
    .restart local v7    # "parent":Ljava/io/File;
    .restart local v8    # "out":Ljava/io/OutputStream;
    :catchall_0
    move-exception v1

    invoke-virtual {v8}, Ljava/io/OutputStream;->close()V

    .line 192
    nop

    .end local v0    # "rootPath":Ljava/lang/String;
    .end local v2    # "zip":Ljava/util/zip/ZipInputStream;
    .end local v3    # "files":I
    .end local p0    # "assets":Landroid/content/res/AssetManager;
    .end local p1    # "assetPath":Ljava/lang/String;
    .end local p2    # "destDir":Ljava/io/File;
    throw v1

    .line 170
    .end local v7    # "parent":Ljava/io/File;
    .end local v8    # "out":Ljava/io/OutputStream;
    .restart local v0    # "rootPath":Ljava/lang/String;
    .restart local v2    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v3    # "files":I
    .restart local p0    # "assets":Landroid/content/res/AssetManager;
    .restart local p1    # "assetPath":Ljava/lang/String;
    .restart local p2    # "destDir":Ljava/io/File;
    :cond_6
    new-instance v1, Ljava/io/IOException;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "zip entry escapes the folder: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v6}, Ljava/util/zip/ZipEntry;->getName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v1, v7}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .end local v0    # "rootPath":Ljava/lang/String;
    .end local v2    # "zip":Ljava/util/zip/ZipInputStream;
    .end local v3    # "files":I
    .end local p0    # "assets":Landroid/content/res/AssetManager;
    .end local p1    # "assetPath":Ljava/lang/String;
    .end local p2    # "destDir":Ljava/io/File;
    throw v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 199
    .end local v4    # "buffer":[B
    .end local v5    # "target":Ljava/io/File;
    .end local v6    # "entry":Ljava/util/zip/ZipEntry;
    .restart local v0    # "rootPath":Ljava/lang/String;
    .restart local v2    # "zip":Ljava/util/zip/ZipInputStream;
    .restart local v3    # "files":I
    .restart local p0    # "assets":Landroid/content/res/AssetManager;
    .restart local p1    # "assetPath":Ljava/lang/String;
    .restart local p2    # "destDir":Ljava/io/File;
    :cond_7
    invoke-virtual {v2}, Ljava/util/zip/ZipInputStream;->close()V

    .line 200
    nop

    .line 202
    return v3

    .line 199
    :catchall_1
    move-exception v1

    invoke-virtual {v2}, Ljava/util/zip/ZipInputStream;->close()V

    .line 200
    throw v1
.end method

.method public static installIfNeeded(Landroid/content/Context;Ljava/io/File;)V
    .locals 7
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "homeDir"    # Ljava/io/File;

    .line 42
    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    new-instance v1, Ljava/io/File;

    const-string v2, ".emulationstation/bios"

    invoke-direct {v1, p1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const-string v3, "bios"

    invoke-static {v0, v3, v1}, Lorg/emulationstation/frontend/AssetInstaller;->installMissing(Landroid/content/res/AssetManager;Ljava/lang/String;Ljava/io/File;)V

    .line 44
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {p0, v0}, Lorg/emulationstation/frontend/AssetInstaller;->installPacks(Landroid/content/Context;Ljava/io/File;)V

    .line 46
    new-instance v0, Ljava/io/File;

    const-string v1, ".emulationstation/resources"

    invoke-direct {v0, p1, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 47
    .local v0, "target":Ljava/io/File;
    new-instance v1, Ljava/io/File;

    const-string v2, ".installed-version"

    invoke-direct {v1, v0, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 51
    .local v1, "marker":Ljava/io/File;
    invoke-static {p0}, Lorg/emulationstation/frontend/AssetInstaller;->installStamp(Landroid/content/Context;)J

    move-result-wide v2

    .line 53
    .local v2, "version":J
    invoke-static {v1}, Lorg/emulationstation/frontend/AssetInstaller;->readMarker(Ljava/io/File;)J

    move-result-wide v4

    cmp-long v4, v2, v4

    if-nez v4, :cond_0

    .line 54
    return-void

    .line 56
    :cond_0
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Installing resources into "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const-string v5, "EmulationStation"

    invoke-static {v5, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 58
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v4

    if-nez v4, :cond_1

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    move-result v4

    if-nez v4, :cond_1

    .line 60
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Could not create "

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v6, " - is storage access granted?"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v5, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 61
    return-void

    .line 66
    :cond_1
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v4

    const-string v6, "resources"

    invoke-static {v4, v6, v0}, Lorg/emulationstation/frontend/AssetInstaller;->copyAssetDir(Landroid/content/res/AssetManager;Ljava/lang/String;Ljava/io/File;)V

    .line 67
    invoke-static {v1, v2, v3}, Lorg/emulationstation/frontend/AssetInstaller;->writeMarker(Ljava/io/File;J)V

    .line 69
    const-string v4, "Resources installed."

    invoke-static {v5, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 74
    goto :goto_0

    .line 71
    :catch_0
    move-exception v4

    .line 73
    .local v4, "e":Ljava/io/IOException;
    const-string v6, "Failed to install resources"

    invoke-static {v5, v6, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 75
    .end local v4    # "e":Ljava/io/IOException;
    :goto_0
    return-void
.end method

.method private static installMissing(Landroid/content/res/AssetManager;Ljava/lang/String;Ljava/io/File;)V
    .locals 7
    .param p0, "assets"    # Landroid/content/res/AssetManager;
    .param p1, "assetPath"    # Ljava/lang/String;
    .param p2, "target"    # Ljava/io/File;

    .line 214
    const-string v0, "EmulationStation"

    :try_start_0
    invoke-virtual {p0, p1}, Landroid/content/res/AssetManager;->list(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 216
    .local v1, "entries":[Ljava/lang/String;
    if-eqz v1, :cond_2

    array-length v2, v1

    if-nez v2, :cond_0

    goto :goto_1

    .line 226
    :cond_0
    array-length v2, v1

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_1

    aget-object v4, v1, v3

    .line 227
    .local v4, "entry":Ljava/lang/String;
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "/"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/io/File;

    invoke-direct {v6, p2, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {p0, v5, v6}, Lorg/emulationstation/frontend/AssetInstaller;->installMissing(Landroid/content/res/AssetManager;Ljava/lang/String;Ljava/io/File;)V

    .line 226
    .end local v4    # "entry":Ljava/lang/String;
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 232
    .end local v1    # "entries":[Ljava/lang/String;
    :cond_1
    goto :goto_2

    .line 218
    .restart local v1    # "entries":[Ljava/lang/String;
    :cond_2
    :goto_1
    invoke-virtual {p2}, Ljava/io/File;->exists()Z

    move-result v2

    if-nez v2, :cond_3

    .line 220
    invoke-static {p0, p1, p2}, Lorg/emulationstation/frontend/AssetInstaller;->copyAssetFile(Landroid/content/res/AssetManager;Ljava/lang/String;Ljava/io/File;)V

    .line 221
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Installed "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 223
    :cond_3
    return-void

    .line 229
    .end local v1    # "entries":[Ljava/lang/String;
    :catch_0
    move-exception v1

    .line 231
    .local v1, "e":Ljava/io/IOException;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Failed to install "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 233
    .end local v1    # "e":Ljava/io/IOException;
    :goto_2
    return-void
.end method

.method private static installPacks(Landroid/content/Context;Ljava/io/File;)V
    .locals 7
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "systemDir"    # Ljava/io/File;

    .line 96
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 98
    .local v0, "pending":Ljava/util/List;, "Ljava/util/List<[Ljava/lang/String;>;"
    sget-object v1, Lorg/emulationstation/frontend/AssetInstaller;->PACKS:[[Ljava/lang/String;

    array-length v2, v1

    const/4 v3, 0x0

    :goto_0
    const/4 v4, 0x1

    if-ge v3, v2, :cond_1

    aget-object v5, v1, v3

    .line 100
    .local v5, "pack":[Ljava/lang/String;
    new-instance v6, Ljava/io/File;

    aget-object v4, v5, v4

    invoke-direct {v6, p1, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/io/File;->exists()Z

    move-result v4

    if-nez v4, :cond_0

    .line 101
    invoke-interface {v0, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 98
    .end local v5    # "pack":[Ljava/lang/String;
    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 104
    :cond_1
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_2

    .line 105
    return-void

    .line 107
    :cond_2
    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v1

    .line 109
    .local v1, "assets":Landroid/content/res/AssetManager;
    new-instance v2, Ljava/lang/Thread;

    new-instance v3, Lorg/emulationstation/frontend/AssetInstaller$1;

    invoke-direct {v3, v0, p1, v1}, Lorg/emulationstation/frontend/AssetInstaller$1;-><init>(Ljava/util/List;Ljava/io/File;Landroid/content/res/AssetManager;)V

    const-string v5, "es-pack-installer"

    invoke-direct {v2, v3, v5}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 148
    .local v2, "worker":Ljava/lang/Thread;
    invoke-virtual {v2, v4}, Ljava/lang/Thread;->setPriority(I)V

    .line 149
    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    .line 150
    return-void
.end method

.method private static installStamp(Landroid/content/Context;)J
    .locals 3
    .param p0, "context"    # Landroid/content/Context;

    .line 283
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v0

    .line 284
    .local v0, "info":Landroid/content/pm/PackageInfo;
    iget-wide v1, v0, Landroid/content/pm/PackageInfo;->lastUpdateTime:J
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-wide v1

    .line 286
    .end local v0    # "info":Landroid/content/pm/PackageInfo;
    :catch_0
    move-exception v0

    .line 288
    .local v0, "e":Ljava/lang/Exception;
    const-wide/16 v1, -0x1

    return-wide v1
.end method

.method private static readMarker(Ljava/io/File;)J
    .locals 4
    .param p0, "marker"    # Ljava/io/File;

    .line 294
    const/4 v0, 0x0

    .line 298
    .local v0, "reader":Ljava/io/BufferedReader;
    :try_start_0
    new-instance v1, Ljava/io/BufferedReader;

    new-instance v2, Ljava/io/FileReader;

    invoke-direct {v2, p0}, Ljava/io/FileReader;-><init>(Ljava/io/File;)V

    invoke-direct {v1, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    move-object v0, v1

    .line 299
    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 307
    invoke-static {v0}, Lorg/emulationstation/frontend/AssetInstaller;->closeQuietly(Ljava/io/Closeable;)V

    .line 299
    return-wide v1

    .line 307
    :catchall_0
    move-exception v1

    invoke-static {v0}, Lorg/emulationstation/frontend/AssetInstaller;->closeQuietly(Ljava/io/Closeable;)V

    .line 308
    throw v1

    .line 301
    :catch_0
    move-exception v1

    .line 303
    .local v1, "e":Ljava/lang/Exception;
    nop

    .line 307
    invoke-static {v0}, Lorg/emulationstation/frontend/AssetInstaller;->closeQuietly(Ljava/io/Closeable;)V

    .line 303
    const-wide/16 v2, -0x1

    return-wide v2
.end method

.method private static writeMarker(Ljava/io/File;J)V
    .locals 5
    .param p0, "marker"    # Ljava/io/File;
    .param p1, "version"    # J

    .line 313
    const/4 v0, 0x0

    .line 317
    .local v0, "writer":Ljava/io/FileWriter;
    :try_start_0
    new-instance v1, Ljava/io/FileWriter;

    invoke-direct {v1, p0}, Ljava/io/FileWriter;-><init>(Ljava/io/File;)V

    move-object v0, v1

    .line 318
    invoke-static {p1, p2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/io/FileWriter;->write(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 326
    nop

    :goto_0
    invoke-static {v0}, Lorg/emulationstation/frontend/AssetInstaller;->closeQuietly(Ljava/io/Closeable;)V

    .line 327
    goto :goto_1

    .line 326
    :catchall_0
    move-exception v1

    goto :goto_2

    .line 320
    :catch_0
    move-exception v1

    .line 322
    .local v1, "e":Ljava/io/IOException;
    :try_start_1
    const-string v2, "EmulationStation"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Could not write "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " - resources will be reinstalled on every boot"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 326
    nop

    .end local v1    # "e":Ljava/io/IOException;
    goto :goto_0

    .line 328
    :goto_1
    return-void

    .line 326
    :goto_2
    invoke-static {v0}, Lorg/emulationstation/frontend/AssetInstaller;->closeQuietly(Ljava/io/Closeable;)V

    .line 327
    throw v1
.end method
