.class final Lorg/emulationstation/frontend/HttpBridge$DownloadSnapshot;
.super Ljava/lang/Object;
.source "HttpBridge.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/emulationstation/frontend/HttpBridge;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "DownloadSnapshot"
.end annotation


# instance fields
.field count:I

.field downloaded:J

.field firstTitle:Ljava/lang/String;

.field total:J


# direct methods
.method constructor <init>()V
    .locals 0

    .line 105
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
