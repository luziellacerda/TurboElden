.class Lorg/emulationstation/frontend/ESActivity$3;
.super Ljava/lang/Object;
.source "ESActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/emulationstation/frontend/ESActivity;->requestNotificationPermission()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .line 360
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .line 364
    invoke-static {}, Lorg/emulationstation/frontend/ESActivity;->-$$Nest$sfgetsInstance()Lorg/emulationstation/frontend/ESActivity;

    move-result-object v0

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "android.permission.POST_NOTIFICATIONS"

    aput-object v3, v1, v2

    const/16 v2, 0x1093

    invoke-virtual {v0, v1, v2}, Lorg/emulationstation/frontend/ESActivity;->requestPermissions([Ljava/lang/String;I)V

    .line 365
    return-void
.end method
