package android.content.p001pm;

public class CrossProfileApps {
    static {
        throw new NoClassDefFoundError();
    }
}
