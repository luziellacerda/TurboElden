package android.content.p001pm;

public class LauncherApps$ArchiveCompatibilityParams {
    static {
        throw new NoClassDefFoundError();
    }
}
