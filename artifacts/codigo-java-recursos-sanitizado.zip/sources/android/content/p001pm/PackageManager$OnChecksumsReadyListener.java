package android.content.p001pm;

public interface PackageManager$OnChecksumsReadyListener {
    static {
        throw new NoClassDefFoundError();
    }
}
