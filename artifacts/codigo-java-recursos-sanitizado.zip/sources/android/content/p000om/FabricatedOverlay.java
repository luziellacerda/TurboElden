package android.content.p000om;

public class FabricatedOverlay {
    static {
        throw new NoClassDefFoundError();
    }
}
