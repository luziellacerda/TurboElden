package android.content.p000om;

public class OverlayManager {
    static {
        throw new NoClassDefFoundError();
    }
}
