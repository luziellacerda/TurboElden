package android.content.res.loader;

public interface AssetsProvider {
    static {
        throw new NoClassDefFoundError();
    }
}
