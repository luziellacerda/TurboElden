package android.content.res.loader;

public class ResourcesLoader {
    static {
        throw new NoClassDefFoundError();
    }
}
