package android.content.res.loader;

import java.io.Closeable;

public class ResourcesProvider implements AutoCloseable, Closeable {
    static {
        throw new NoClassDefFoundError();
    }
}
