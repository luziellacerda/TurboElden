package android.content.res;

public interface FontScaleConverter {
    static {
        throw new NoClassDefFoundError();
    }
}
