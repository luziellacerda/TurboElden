package android.credentials;

public class CreateCredentialException extends Exception {
    static {
        throw new NoClassDefFoundError();
    }
}
