package android.credentials;

public class GetCredentialException extends Exception {
    static {
        throw new NoClassDefFoundError();
    }
}
