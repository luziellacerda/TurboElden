package android.credentials;

public class ClearCredentialStateException extends Exception {
    static {
        throw new NoClassDefFoundError();
    }
}
