package android.icu.text;

public class CaseMap {
    static {
        throw new NoClassDefFoundError();
    }
}
