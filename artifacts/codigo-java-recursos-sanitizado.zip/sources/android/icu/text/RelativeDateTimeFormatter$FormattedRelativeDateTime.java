package android.icu.text;

public class RelativeDateTimeFormatter$FormattedRelativeDateTime implements FormattedValue {
    static {
        throw new NoClassDefFoundError();
    }
}
