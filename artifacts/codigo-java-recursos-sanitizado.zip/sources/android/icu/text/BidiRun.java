package android.icu.text;

public class BidiRun {
    static {
        throw new NoClassDefFoundError();
    }
}
