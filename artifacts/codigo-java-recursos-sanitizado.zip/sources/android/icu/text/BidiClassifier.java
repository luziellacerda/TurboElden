package android.icu.text;

public class BidiClassifier {
    static {
        throw new NoClassDefFoundError();
    }
}
