package android.icu.text;

public class Bidi {
    static {
        throw new NoClassDefFoundError();
    }
}
