package android.icu.text;

public class DisplayOptions$Builder {
    static {
        throw new NoClassDefFoundError();
    }
}
