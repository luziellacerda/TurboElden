package android.icu.text;

public class Transliterator {

    public class Position {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
