package android.icu.text;

public class ConstrainedFieldPosition {
    static {
        throw new NoClassDefFoundError();
    }
}
