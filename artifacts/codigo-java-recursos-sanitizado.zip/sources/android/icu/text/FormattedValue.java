package android.icu.text;

public interface FormattedValue extends CharSequence {
    static {
        throw new NoClassDefFoundError();
    }
}
