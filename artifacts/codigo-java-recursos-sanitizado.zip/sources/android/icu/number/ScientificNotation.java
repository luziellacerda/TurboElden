package android.icu.number;

public class ScientificNotation extends Notation {
    static {
        throw new NoClassDefFoundError();
    }
}
