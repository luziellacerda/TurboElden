package android.icu.number;

public class CurrencyPrecision extends Precision {
    static {
        throw new NoClassDefFoundError();
    }
}
