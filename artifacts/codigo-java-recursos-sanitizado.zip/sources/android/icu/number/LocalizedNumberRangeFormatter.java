package android.icu.number;

public class LocalizedNumberRangeFormatter extends NumberRangeFormatterSettings {
    static {
        throw new NoClassDefFoundError();
    }
}
