package android.icu.number;

import android.icu.text.FormattedValue;

public class FormattedNumberRange implements FormattedValue {
    static {
        throw new NoClassDefFoundError();
    }
}
