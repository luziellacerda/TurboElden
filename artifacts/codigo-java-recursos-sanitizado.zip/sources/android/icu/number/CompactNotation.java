package android.icu.number;

public class CompactNotation extends Notation {
    static {
        throw new NoClassDefFoundError();
    }
}
