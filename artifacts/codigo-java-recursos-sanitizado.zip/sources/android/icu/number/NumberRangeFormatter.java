package android.icu.number;

public class NumberRangeFormatter {
    static {
        throw new NoClassDefFoundError();
    }
}
