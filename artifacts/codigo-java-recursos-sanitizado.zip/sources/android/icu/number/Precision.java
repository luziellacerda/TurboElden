package android.icu.number;

public class Precision {
    static {
        throw new NoClassDefFoundError();
    }
}
