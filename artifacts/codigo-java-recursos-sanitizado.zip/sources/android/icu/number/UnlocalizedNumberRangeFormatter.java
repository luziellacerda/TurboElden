package android.icu.number;

public class UnlocalizedNumberRangeFormatter extends NumberRangeFormatterSettings {
    static {
        throw new NoClassDefFoundError();
    }
}
