package android.icu.number;

public class SimpleNotation extends Notation {
    static {
        throw new NoClassDefFoundError();
    }
}
