package android.icu.number;

import android.icu.text.FormattedValue;

public class FormattedNumber implements FormattedValue {
    static {
        throw new NoClassDefFoundError();
    }
}
