package android.icu.number;

public class UnlocalizedNumberFormatter extends NumberFormatterSettings {
    static {
        throw new NoClassDefFoundError();
    }
}
