package android.icu.number;

public class LocalizedNumberFormatter extends NumberFormatterSettings {
    static {
        throw new NoClassDefFoundError();
    }
}
