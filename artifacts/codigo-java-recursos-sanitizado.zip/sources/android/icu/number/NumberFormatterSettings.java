package android.icu.number;

public class NumberFormatterSettings {
    static {
        throw new NoClassDefFoundError();
    }
}
