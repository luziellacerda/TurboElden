package android.icu.number;

public class Scale {
    static {
        throw new NoClassDefFoundError();
    }
}
