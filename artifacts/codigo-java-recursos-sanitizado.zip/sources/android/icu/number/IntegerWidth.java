package android.icu.number;

public class IntegerWidth {
    static {
        throw new NoClassDefFoundError();
    }
}
