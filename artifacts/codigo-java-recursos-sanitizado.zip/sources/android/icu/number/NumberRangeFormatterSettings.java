package android.icu.number;

public class NumberRangeFormatterSettings {
    static {
        throw new NoClassDefFoundError();
    }
}
