package android.icu.number;

public class FractionPrecision extends Precision {
    static {
        throw new NoClassDefFoundError();
    }
}
