package android.icu.number;

public class Notation {
    static {
        throw new NoClassDefFoundError();
    }
}
