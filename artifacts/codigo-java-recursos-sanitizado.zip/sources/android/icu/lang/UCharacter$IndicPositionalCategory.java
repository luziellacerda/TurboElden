package android.icu.lang;

public interface UCharacter$IndicPositionalCategory {
    static {
        throw new NoClassDefFoundError();
    }
}
