package android.icu.lang;

public interface UCharacter$VerticalOrientation {
    static {
        throw new NoClassDefFoundError();
    }
}
