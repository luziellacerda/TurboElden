package android.icu.lang;

public interface UCharacter$IndicSyllabicCategory {
    static {
        throw new NoClassDefFoundError();
    }
}
