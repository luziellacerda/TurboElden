package android.icu.util;

public class IllformedLocaleException extends RuntimeException {
    static {
        throw new NoClassDefFoundError();
    }
}
