package android.opengl;

public class EGLSync extends EGLObjectHandle {
    static {
        throw new NoClassDefFoundError();
    }
}
