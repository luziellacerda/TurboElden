package android.opengl;

public class EGLImage extends EGLObjectHandle {
    static {
        throw new NoClassDefFoundError();
    }
}
