package android.adservices.appsetid;

public class AppSetIdManager {
    static {
        throw new NoClassDefFoundError();
    }
}
