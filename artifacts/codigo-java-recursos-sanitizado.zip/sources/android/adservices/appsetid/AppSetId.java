package android.adservices.appsetid;

public class AppSetId {
    static {
        throw new NoClassDefFoundError();
    }
}
