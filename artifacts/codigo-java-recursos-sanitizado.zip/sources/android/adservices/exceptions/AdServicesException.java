package android.adservices.exceptions;

public class AdServicesException extends Exception {
    static {
        throw new NoClassDefFoundError();
    }
}
