package android.adservices.common;

public class AdServicesPermissions {
    static {
        throw new NoClassDefFoundError();
    }
}
