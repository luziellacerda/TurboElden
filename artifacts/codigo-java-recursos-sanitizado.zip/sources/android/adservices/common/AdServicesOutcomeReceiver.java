package android.adservices.common;

public interface AdServicesOutcomeReceiver {
    static {
        throw new NoClassDefFoundError();
    }
}
