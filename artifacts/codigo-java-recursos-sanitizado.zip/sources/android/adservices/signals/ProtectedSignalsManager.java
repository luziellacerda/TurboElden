package android.adservices.signals;

public class ProtectedSignalsManager {
    static {
        throw new NoClassDefFoundError();
    }
}
