package android.adservices.customaudience;

public class AddCustomAudienceOverrideRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
