package android.adservices.customaudience;

public class RemoveCustomAudienceOverrideRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
