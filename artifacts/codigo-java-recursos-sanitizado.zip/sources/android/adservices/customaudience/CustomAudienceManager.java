package android.adservices.customaudience;

public class CustomAudienceManager {
    static {
        throw new NoClassDefFoundError();
    }
}
