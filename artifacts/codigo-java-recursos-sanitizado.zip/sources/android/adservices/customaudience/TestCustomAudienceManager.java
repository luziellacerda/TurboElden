package android.adservices.customaudience;

public class TestCustomAudienceManager {
    static {
        throw new NoClassDefFoundError();
    }
}
