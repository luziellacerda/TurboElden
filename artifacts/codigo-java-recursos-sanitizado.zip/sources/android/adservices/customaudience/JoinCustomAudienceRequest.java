package android.adservices.customaudience;

public class JoinCustomAudienceRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
