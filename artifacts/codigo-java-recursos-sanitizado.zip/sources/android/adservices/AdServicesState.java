package android.adservices;

public class AdServicesState {
    static {
        throw new NoClassDefFoundError();
    }
}
