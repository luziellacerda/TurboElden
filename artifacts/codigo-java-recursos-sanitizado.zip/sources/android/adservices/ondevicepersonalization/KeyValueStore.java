package android.adservices.ondevicepersonalization;

public interface KeyValueStore {
    static {
        throw new NoClassDefFoundError();
    }
}
