package android.adservices.ondevicepersonalization;

public class FederatedComputeScheduler {

    public class Params {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
