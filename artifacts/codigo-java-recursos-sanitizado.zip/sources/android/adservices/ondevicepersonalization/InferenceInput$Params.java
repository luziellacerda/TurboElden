package android.adservices.ondevicepersonalization;

public class InferenceInput$Params {
    static {
        throw new NoClassDefFoundError();
    }
}
