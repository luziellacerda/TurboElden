package android.adservices.ondevicepersonalization;

public interface IsolatedWorker {
    static {
        throw new NoClassDefFoundError();
    }
}
