package android.adservices.ondevicepersonalization;

import android.app.Service;

public class IsolatedService extends Service {
    static {
        throw new NoClassDefFoundError();
    }
}
