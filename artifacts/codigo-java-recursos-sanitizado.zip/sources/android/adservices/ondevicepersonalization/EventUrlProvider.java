package android.adservices.ondevicepersonalization;

public class EventUrlProvider {
    static {
        throw new NoClassDefFoundError();
    }
}
