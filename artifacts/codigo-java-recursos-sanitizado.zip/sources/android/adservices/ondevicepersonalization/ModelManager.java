package android.adservices.ondevicepersonalization;

public class ModelManager {
    static {
        throw new NoClassDefFoundError();
    }
}
