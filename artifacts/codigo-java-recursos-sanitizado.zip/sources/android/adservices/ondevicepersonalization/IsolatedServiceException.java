package android.adservices.ondevicepersonalization;

public final class IsolatedServiceException extends Exception {
    static {
        throw new NoClassDefFoundError();
    }
}
