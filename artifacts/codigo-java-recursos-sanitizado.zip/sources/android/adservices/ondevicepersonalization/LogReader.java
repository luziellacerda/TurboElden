package android.adservices.ondevicepersonalization;

public class LogReader {
    static {
        throw new NoClassDefFoundError();
    }
}
