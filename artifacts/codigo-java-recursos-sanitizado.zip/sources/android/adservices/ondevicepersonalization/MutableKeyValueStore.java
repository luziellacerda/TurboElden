package android.adservices.ondevicepersonalization;

public interface MutableKeyValueStore extends KeyValueStore {
    static {
        throw new NoClassDefFoundError();
    }
}
