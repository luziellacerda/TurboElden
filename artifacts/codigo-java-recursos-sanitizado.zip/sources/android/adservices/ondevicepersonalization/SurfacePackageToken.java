package android.adservices.ondevicepersonalization;

public class SurfacePackageToken {
    static {
        throw new NoClassDefFoundError();
    }
}
