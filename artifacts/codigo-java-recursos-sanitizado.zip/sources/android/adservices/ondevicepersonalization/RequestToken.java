package android.adservices.ondevicepersonalization;

public class RequestToken {
    static {
        throw new NoClassDefFoundError();
    }
}
