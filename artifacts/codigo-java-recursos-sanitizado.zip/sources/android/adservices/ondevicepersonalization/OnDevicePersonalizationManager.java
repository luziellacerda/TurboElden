package android.adservices.ondevicepersonalization;

public class OnDevicePersonalizationManager {

    public class ExecuteResult {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
