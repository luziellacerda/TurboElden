package android.adservices.ondevicepersonalization;

public class OnDevicePersonalizationException extends Exception {
    static {
        throw new NoClassDefFoundError();
    }
}
