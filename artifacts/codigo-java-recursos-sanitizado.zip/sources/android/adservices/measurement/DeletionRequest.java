package android.adservices.measurement;

public class DeletionRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
