package android.adservices.measurement;

public class MeasurementManager {
    static {
        throw new NoClassDefFoundError();
    }
}
