package android.adservices.adselection;

public class ReportImpressionRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
