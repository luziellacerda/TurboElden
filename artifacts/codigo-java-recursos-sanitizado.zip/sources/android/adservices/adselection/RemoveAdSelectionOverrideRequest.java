package android.adservices.adselection;

public class RemoveAdSelectionOverrideRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
