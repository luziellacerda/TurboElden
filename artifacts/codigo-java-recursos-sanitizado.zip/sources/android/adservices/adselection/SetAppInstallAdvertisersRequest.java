package android.adservices.adselection;

public class SetAppInstallAdvertisersRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
