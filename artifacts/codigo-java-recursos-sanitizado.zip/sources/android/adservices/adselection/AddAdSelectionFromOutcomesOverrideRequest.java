package android.adservices.adselection;

public class AddAdSelectionFromOutcomesOverrideRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
