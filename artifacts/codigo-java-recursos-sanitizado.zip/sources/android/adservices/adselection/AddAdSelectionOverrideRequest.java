package android.adservices.adselection;

public class AddAdSelectionOverrideRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
