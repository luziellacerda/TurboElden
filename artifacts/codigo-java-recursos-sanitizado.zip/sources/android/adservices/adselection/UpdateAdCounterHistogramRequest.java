package android.adservices.adselection;

public class UpdateAdCounterHistogramRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
