package android.adservices.adselection;

public class AdSelectionOutcome {
    static {
        throw new NoClassDefFoundError();
    }
}
