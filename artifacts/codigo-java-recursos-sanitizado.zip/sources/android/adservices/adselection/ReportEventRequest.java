package android.adservices.adselection;

public class ReportEventRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
