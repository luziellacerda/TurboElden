package android.adservices.adselection;

public class AdSelectionManager {
    static {
        throw new NoClassDefFoundError();
    }
}
