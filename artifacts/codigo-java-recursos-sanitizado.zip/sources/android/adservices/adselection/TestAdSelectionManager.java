package android.adservices.adselection;

public class TestAdSelectionManager {
    static {
        throw new NoClassDefFoundError();
    }
}
