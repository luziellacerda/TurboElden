package android.adservices.adselection;

public class RemoveAdSelectionFromOutcomesOverrideRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
