package android.adservices.adid;

public class AdIdManager {
    static {
        throw new NoClassDefFoundError();
    }
}
