package android.adservices.adid;

public class AdId {
    static {
        throw new NoClassDefFoundError();
    }
}
