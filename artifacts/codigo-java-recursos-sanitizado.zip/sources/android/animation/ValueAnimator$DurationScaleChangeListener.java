package android.animation;

public interface ValueAnimator$DurationScaleChangeListener {
    static {
        throw new NoClassDefFoundError();
    }
}
