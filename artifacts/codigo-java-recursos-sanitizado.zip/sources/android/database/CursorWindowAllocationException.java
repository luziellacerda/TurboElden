package android.database;

public class CursorWindowAllocationException extends RuntimeException {
    static {
        throw new NoClassDefFoundError();
    }
}
