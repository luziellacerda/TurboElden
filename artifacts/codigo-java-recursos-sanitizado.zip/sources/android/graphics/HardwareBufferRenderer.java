package android.graphics;

public class HardwareBufferRenderer implements AutoCloseable {
    static {
        throw new NoClassDefFoundError();
    }
}
