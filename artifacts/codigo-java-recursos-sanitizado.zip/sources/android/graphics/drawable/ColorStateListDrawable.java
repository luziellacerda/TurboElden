package android.graphics.drawable;

public class ColorStateListDrawable extends Drawable implements Drawable.Callback {
    static {
        throw new NoClassDefFoundError();
    }
}
