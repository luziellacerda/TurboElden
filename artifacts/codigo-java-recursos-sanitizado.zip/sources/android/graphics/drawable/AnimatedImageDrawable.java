package android.graphics.drawable;

public class AnimatedImageDrawable extends Drawable implements Animatable2 {
    static {
        throw new NoClassDefFoundError();
    }
}
