package android.graphics.text;

public class MeasuredText {
    static {
        throw new NoClassDefFoundError();
    }
}
