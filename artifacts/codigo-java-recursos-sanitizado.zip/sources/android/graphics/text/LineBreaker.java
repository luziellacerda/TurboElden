package android.graphics.text;

public class LineBreaker {

    public class ParagraphConstraints {
        static {
            throw new NoClassDefFoundError();
        }
    }

    public class Result {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
