package android.graphics.text;

public class TextRunShaper {
    static {
        throw new NoClassDefFoundError();
    }
}
