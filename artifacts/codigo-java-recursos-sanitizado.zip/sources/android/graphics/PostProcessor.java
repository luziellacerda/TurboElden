package android.graphics;

public interface PostProcessor {
    static {
        throw new NoClassDefFoundError();
    }
}
