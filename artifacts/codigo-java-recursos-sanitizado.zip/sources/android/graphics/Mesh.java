package android.graphics;

public class Mesh {
    static {
        throw new NoClassDefFoundError();
    }
}
