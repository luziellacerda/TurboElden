package android.graphics;

public class Matrix44 {
    static {
        throw new NoClassDefFoundError();
    }
}
