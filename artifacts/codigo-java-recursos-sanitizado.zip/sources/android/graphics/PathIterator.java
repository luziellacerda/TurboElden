package android.graphics;

import java.util.Iterator;

public class PathIterator implements Iterator {

    public class Segment {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
