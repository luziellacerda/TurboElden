package android.graphics;

public class ImageDecoder$Source {
    static {
        throw new NoClassDefFoundError();
    }
}
