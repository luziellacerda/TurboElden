package android.graphics;

public class MeshSpecification {

    public class Attribute {
        static {
            throw new NoClassDefFoundError();
        }
    }

    public class Varying {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
