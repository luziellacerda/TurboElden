package android.graphics;

public class RuntimeShader extends Shader {
    static {
        throw new NoClassDefFoundError();
    }
}
