package android.graphics;

public class ImageDecoder$ImageInfo {
    static {
        throw new NoClassDefFoundError();
    }
}
