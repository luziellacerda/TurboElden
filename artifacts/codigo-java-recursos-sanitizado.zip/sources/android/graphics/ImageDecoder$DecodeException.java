package android.graphics;

import java.io.IOException;

public final class ImageDecoder$DecodeException extends IOException {
    static {
        throw new NoClassDefFoundError();
    }
}
