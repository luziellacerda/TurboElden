package android.graphics;

public class HardwareRenderer {
    static {
        throw new NoClassDefFoundError();
    }
}
