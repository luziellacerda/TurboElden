package android.app;

public class StatusBarManager {
    static {
        throw new NoClassDefFoundError();
    }
}
