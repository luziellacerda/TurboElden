package android.app.blob;

import java.io.Closeable;

public class BlobStoreManager {

    public class Session implements Closeable {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
