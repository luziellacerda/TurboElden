package android.app;

import android.os.Parcelable;

public final class BackgroundServiceStartNotAllowedException extends ServiceStartNotAllowedException implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}
