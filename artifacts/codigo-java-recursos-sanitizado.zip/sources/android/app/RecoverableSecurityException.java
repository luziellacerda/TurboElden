package android.app;

import android.os.Parcelable;

public final class RecoverableSecurityException extends SecurityException implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}
