package android.app.sdksandbox;

public final class RequestSurfacePackageException extends Exception {
    static {
        throw new NoClassDefFoundError();
    }
}
