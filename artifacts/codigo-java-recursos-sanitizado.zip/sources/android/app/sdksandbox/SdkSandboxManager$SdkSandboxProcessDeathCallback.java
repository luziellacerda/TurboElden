package android.app.sdksandbox;

public interface SdkSandboxManager$SdkSandboxProcessDeathCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
