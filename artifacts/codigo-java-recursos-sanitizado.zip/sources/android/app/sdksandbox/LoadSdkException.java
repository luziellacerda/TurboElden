package android.app.sdksandbox;

import android.os.Parcelable;

public final class LoadSdkException extends Exception implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}
