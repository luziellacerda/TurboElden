package android.app.sdksandbox;

public class SandboxedSdkProvider {
    static {
        throw new NoClassDefFoundError();
    }
}
