package android.app.sdksandbox.sdkprovider;

public class SdkSandboxController {
    static {
        throw new NoClassDefFoundError();
    }
}
