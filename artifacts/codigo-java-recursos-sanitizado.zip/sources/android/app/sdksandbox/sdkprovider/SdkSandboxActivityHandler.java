package android.app.sdksandbox.sdkprovider;

public interface SdkSandboxActivityHandler {
    static {
        throw new NoClassDefFoundError();
    }
}
