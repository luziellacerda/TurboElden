package android.app;

import android.os.Parcelable;

public class LocaleConfig implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}
