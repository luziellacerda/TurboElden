package android.app;

public class GrammaticalInflectionManager {
    static {
        throw new NoClassDefFoundError();
    }
}
