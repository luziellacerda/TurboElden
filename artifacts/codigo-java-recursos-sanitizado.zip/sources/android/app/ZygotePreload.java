package android.app;

public interface ZygotePreload {
    static {
        throw new NoClassDefFoundError();
    }
}
