package android.app;

import android.os.Parcelable;

public final class StartForegroundCalledOnStoppedServiceException extends IllegalStateException implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}
