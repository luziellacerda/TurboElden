package android.app;

public class Notification$CallStyle extends Notification.Style {
    static {
        throw new NoClassDefFoundError();
    }
}
