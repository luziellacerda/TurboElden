package android.app;

public interface KeyguardManager$KeyguardLockedStateListener {
    static {
        throw new NoClassDefFoundError();
    }
}
