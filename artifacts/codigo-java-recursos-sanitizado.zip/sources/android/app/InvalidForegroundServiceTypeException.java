package android.app;

import android.os.Parcelable;

public final class InvalidForegroundServiceTypeException extends ForegroundServiceTypeException implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}
