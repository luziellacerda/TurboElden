package android.app;

public class ForegroundServiceTypeException extends ServiceStartNotAllowedException {
    static {
        throw new NoClassDefFoundError();
    }
}
