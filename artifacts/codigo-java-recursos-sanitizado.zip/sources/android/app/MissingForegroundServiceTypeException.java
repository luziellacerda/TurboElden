package android.app;

import android.os.Parcelable;

public final class MissingForegroundServiceTypeException extends ForegroundServiceTypeException implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}
