package android.app;

public class LocaleManager {
    static {
        throw new NoClassDefFoundError();
    }
}
