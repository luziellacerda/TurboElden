package android.app;

public class TaskInfo {
    static {
        throw new NoClassDefFoundError();
    }
}
