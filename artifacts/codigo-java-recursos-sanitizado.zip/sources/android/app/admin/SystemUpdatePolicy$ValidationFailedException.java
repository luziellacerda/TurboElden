package android.app.admin;

import android.os.Parcelable;

public final class SystemUpdatePolicy$ValidationFailedException extends IllegalArgumentException implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}
