package android.app.admin;

public class DevicePolicyManager$InstallSystemUpdateCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
