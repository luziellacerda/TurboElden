package android.app.admin;

import android.content.BroadcastReceiver;

public class PolicyUpdateReceiver extends BroadcastReceiver {
    static {
        throw new NoClassDefFoundError();
    }
}
