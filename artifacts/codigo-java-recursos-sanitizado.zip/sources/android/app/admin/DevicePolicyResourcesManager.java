package android.app.admin;

public class DevicePolicyResourcesManager {
    static {
        throw new NoClassDefFoundError();
    }
}
