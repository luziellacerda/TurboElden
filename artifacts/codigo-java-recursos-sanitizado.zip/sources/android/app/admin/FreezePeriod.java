package android.app.admin;

public class FreezePeriod {
    static {
        throw new NoClassDefFoundError();
    }
}
