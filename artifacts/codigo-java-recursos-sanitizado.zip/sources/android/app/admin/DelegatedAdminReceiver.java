package android.app.admin;

import android.content.BroadcastReceiver;

public class DelegatedAdminReceiver extends BroadcastReceiver {
    static {
        throw new NoClassDefFoundError();
    }
}
