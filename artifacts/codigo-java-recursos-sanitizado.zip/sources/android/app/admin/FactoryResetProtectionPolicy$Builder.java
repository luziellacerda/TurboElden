package android.app.admin;

public class FactoryResetProtectionPolicy$Builder {
    static {
        throw new NoClassDefFoundError();
    }
}
