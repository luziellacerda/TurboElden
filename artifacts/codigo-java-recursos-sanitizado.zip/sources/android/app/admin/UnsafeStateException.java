package android.app.admin;

import android.os.Parcelable;

public final class UnsafeStateException extends IllegalStateException implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}
