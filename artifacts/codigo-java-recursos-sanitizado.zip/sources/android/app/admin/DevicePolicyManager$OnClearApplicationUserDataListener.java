package android.app.admin;

public interface DevicePolicyManager$OnClearApplicationUserDataListener {
    static {
        throw new NoClassDefFoundError();
    }
}
