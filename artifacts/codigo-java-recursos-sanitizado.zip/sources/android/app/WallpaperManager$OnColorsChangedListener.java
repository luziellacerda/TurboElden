package android.app;

public interface WallpaperManager$OnColorsChangedListener {
    static {
        throw new NoClassDefFoundError();
    }
}
