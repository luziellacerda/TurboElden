package android.app;

public class Person$Builder {
    static {
        throw new NoClassDefFoundError();
    }
}
