package android.app.appsearch;

import java.io.Closeable;

public class SearchResults implements Closeable {
    static {
        throw new NoClassDefFoundError();
    }
}
