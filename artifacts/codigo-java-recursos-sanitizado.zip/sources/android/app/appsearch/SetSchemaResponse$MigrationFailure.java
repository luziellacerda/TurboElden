package android.app.appsearch;

import android.os.Parcelable;

public class SetSchemaResponse$MigrationFailure implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}
