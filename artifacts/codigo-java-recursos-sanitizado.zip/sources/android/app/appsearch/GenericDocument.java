package android.app.appsearch;

public class GenericDocument {

    public class Builder {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
