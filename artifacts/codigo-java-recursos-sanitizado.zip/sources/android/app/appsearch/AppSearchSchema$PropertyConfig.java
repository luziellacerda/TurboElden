package android.app.appsearch;

public class AppSearchSchema$PropertyConfig {
    static {
        throw new NoClassDefFoundError();
    }
}
