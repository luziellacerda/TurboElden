package android.app.appsearch;

import java.io.Closeable;

public class GlobalSearchSession implements Closeable {
    static {
        throw new NoClassDefFoundError();
    }
}
