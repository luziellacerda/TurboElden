package android.app.appsearch.observer;

public interface ObserverCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
