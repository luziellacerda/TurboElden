package android.app.appsearch;

public class PropertyPath implements Iterable {

    public class PathSegment {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
