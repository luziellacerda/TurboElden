package android.app.appsearch;

public class Migrator {
    static {
        throw new NoClassDefFoundError();
    }
}
