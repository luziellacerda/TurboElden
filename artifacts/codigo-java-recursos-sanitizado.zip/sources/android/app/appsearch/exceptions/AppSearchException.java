package android.app.appsearch.exceptions;

public class AppSearchException extends Exception {
    static {
        throw new NoClassDefFoundError();
    }
}
