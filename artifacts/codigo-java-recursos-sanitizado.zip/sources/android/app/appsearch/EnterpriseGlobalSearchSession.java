package android.app.appsearch;

public class EnterpriseGlobalSearchSession {
    static {
        throw new NoClassDefFoundError();
    }
}
