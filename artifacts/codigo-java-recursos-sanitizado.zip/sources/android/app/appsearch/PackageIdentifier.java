package android.app.appsearch;

public class PackageIdentifier {
    static {
        throw new NoClassDefFoundError();
    }
}
