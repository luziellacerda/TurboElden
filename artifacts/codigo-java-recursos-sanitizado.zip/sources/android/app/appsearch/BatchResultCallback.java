package android.app.appsearch;

public interface BatchResultCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
