package android.app.appsearch;

public class AppSearchManager {
    static {
        throw new NoClassDefFoundError();
    }
}
