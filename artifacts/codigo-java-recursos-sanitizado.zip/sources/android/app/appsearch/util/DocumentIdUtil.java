package android.app.appsearch.util;

public class DocumentIdUtil {
    static {
        throw new NoClassDefFoundError();
    }
}
