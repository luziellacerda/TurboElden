package android.app.slice;

import android.content.ContentProvider;

public class SliceProvider extends ContentProvider {
    static {
        throw new NoClassDefFoundError();
    }
}
