package android.app.slice;

public class SliceManager {
    static {
        throw new NoClassDefFoundError();
    }
}
