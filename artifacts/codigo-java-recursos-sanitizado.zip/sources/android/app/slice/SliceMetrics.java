package android.app.slice;

public class SliceMetrics {
    static {
        throw new NoClassDefFoundError();
    }
}
