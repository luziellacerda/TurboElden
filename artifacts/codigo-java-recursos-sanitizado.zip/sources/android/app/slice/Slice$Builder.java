package android.app.slice;

public class Slice$Builder {
    static {
        throw new NoClassDefFoundError();
    }
}
