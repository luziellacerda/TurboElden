package android.app;

public class BroadcastOptions {
    static {
        throw new NoClassDefFoundError();
    }
}
