package android.app;

public class AppOpsManager$OnOpNotedCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
