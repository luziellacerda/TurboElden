package android.crypto.hpke;

public interface HpkeSpi {
    static {
        throw new NoClassDefFoundError();
    }
}
