package android.media.session;

public interface MediaSessionManager$OnMediaKeyEventSessionChangedListener {
    static {
        throw new NoClassDefFoundError();
    }
}
