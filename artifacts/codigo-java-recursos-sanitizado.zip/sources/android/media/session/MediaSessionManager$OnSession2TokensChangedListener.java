package android.media.session;

public interface MediaSessionManager$OnSession2TokensChangedListener {
    static {
        throw new NoClassDefFoundError();
    }
}
