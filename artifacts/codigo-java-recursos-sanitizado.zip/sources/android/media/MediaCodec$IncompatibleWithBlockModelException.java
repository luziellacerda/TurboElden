package android.media;

public class MediaCodec$IncompatibleWithBlockModelException extends RuntimeException {
    static {
        throw new NoClassDefFoundError();
    }
}
