package android.media.metrics;

public class Event {
    static {
        throw new NoClassDefFoundError();
    }
}
