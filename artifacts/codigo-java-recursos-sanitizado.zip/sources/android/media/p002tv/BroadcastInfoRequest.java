package android.media.p002tv;

import android.os.Parcelable;

public class BroadcastInfoRequest implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}
