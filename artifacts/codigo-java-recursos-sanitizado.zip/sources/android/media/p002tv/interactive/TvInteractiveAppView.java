package android.media.p002tv.interactive;

import android.view.ViewGroup;

public class TvInteractiveAppView extends ViewGroup {

    public interface OnUnhandledInputEventListener {
        static {
            throw new NoClassDefFoundError();
        }
    }

    public class TvInteractiveAppCallback {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
