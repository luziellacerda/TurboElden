package android.media.p002tv.interactive;

public class TvInteractiveAppManager$TvInteractiveAppCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
