package android.media.p002tv.interactive;

import android.app.Service;
import android.view.KeyEvent;

public class TvInteractiveAppService extends Service {

    public class Session implements KeyEvent.Callback {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
