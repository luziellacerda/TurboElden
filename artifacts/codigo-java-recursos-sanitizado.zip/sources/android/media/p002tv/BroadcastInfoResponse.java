package android.media.p002tv;

import android.os.Parcelable;

public class BroadcastInfoResponse implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}
