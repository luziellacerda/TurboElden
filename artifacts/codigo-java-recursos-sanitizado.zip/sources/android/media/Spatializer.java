package android.media;

public class Spatializer {

    public interface OnHeadTrackerAvailableListener {
        static {
            throw new NoClassDefFoundError();
        }
    }

    public interface OnSpatializerStateChangedListener {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
