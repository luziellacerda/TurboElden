package android.media;

public interface MediaCodec$OnFirstTunnelFrameReadyListener {
    static {
        throw new NoClassDefFoundError();
    }
}
