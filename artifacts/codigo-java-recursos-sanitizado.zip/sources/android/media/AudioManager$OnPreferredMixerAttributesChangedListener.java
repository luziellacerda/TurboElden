package android.media;

public interface AudioManager$OnPreferredMixerAttributesChangedListener {
    static {
        throw new NoClassDefFoundError();
    }
}
