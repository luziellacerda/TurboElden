package android.media;

public interface MicrophoneDirection {
    static {
        throw new NoClassDefFoundError();
    }
}
