package android.media;

import android.os.Parcelable;

public class AudioProfile implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}
