package android.media;

public final class MediaCasException$InsufficientResourceException extends MediaCasException {
    static {
        throw new NoClassDefFoundError();
    }
}
