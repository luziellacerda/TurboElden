package android.media;

public interface AudioMetadataReadMap {
    static {
        throw new NoClassDefFoundError();
    }
}
