package android.media;

import android.os.Parcelable;

public class AudioDescriptor implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}
