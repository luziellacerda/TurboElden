package android.media;

public interface MediaPlayer$OnSubtitleDataListener {
    static {
        throw new NoClassDefFoundError();
    }
}
