package android.media;

public interface AudioRecordingMonitor {
    static {
        throw new NoClassDefFoundError();
    }
}
