package android.media;

import android.app.Service;

public class MediaSession2Service extends Service {

    public class MediaNotification {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
