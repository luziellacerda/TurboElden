package android.media;

public class LoudnessCodecController implements AutoCloseable {

    public interface OnLoudnessCodecUpdateListener {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
