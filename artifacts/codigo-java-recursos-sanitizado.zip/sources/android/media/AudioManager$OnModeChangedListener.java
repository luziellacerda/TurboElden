package android.media;

public interface AudioManager$OnModeChangedListener {
    static {
        throw new NoClassDefFoundError();
    }
}
