package android.media;

public class MediaCodec$InvalidBufferFlagsException extends RuntimeException {
    static {
        throw new NoClassDefFoundError();
    }
}
