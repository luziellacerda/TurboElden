package android.media;

public interface MediaRouter2$OnGetControllerHintsListener {
    static {
        throw new NoClassDefFoundError();
    }
}
