package android.media;

public interface MediaPlayer$OnMediaTimeDiscontinuityListener {
    static {
        throw new NoClassDefFoundError();
    }
}
