package android.media;

public final class MediaDrm$SessionException extends RuntimeException implements MediaDrmThrowable {
    static {
        throw new NoClassDefFoundError();
    }
}
