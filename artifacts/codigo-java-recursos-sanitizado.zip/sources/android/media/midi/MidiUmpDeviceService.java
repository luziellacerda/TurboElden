package android.media.midi;

import android.app.Service;

public class MidiUmpDeviceService extends Service {
    static {
        throw new NoClassDefFoundError();
    }
}
