package android.media;

public class MediaCommunicationManager {
    static {
        throw new NoClassDefFoundError();
    }
}
