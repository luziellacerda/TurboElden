package android.media;

public class MediaCodec$ParameterDescriptor {
    static {
        throw new NoClassDefFoundError();
    }
}
