package android.media;

import java.io.IOException;

public final class MediaParser$ParsingException extends IOException {
    static {
        throw new NoClassDefFoundError();
    }
}
