package android.media;

import java.io.IOException;

public final class MediaParser$UnrecognizedInputFormatException extends IOException {
    static {
        throw new NoClassDefFoundError();
    }
}
