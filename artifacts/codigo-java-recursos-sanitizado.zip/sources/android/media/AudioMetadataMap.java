package android.media;

public interface AudioMetadataMap extends AudioMetadataReadMap {
    static {
        throw new NoClassDefFoundError();
    }
}
