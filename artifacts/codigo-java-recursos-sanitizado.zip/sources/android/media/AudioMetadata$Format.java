package android.media;

public class AudioMetadata$Format {
    static {
        throw new NoClassDefFoundError();
    }
}
