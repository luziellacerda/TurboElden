package android.media;

public class MediaSession2 implements AutoCloseable {

    public class SessionCallback {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
