package android.media;

public interface AudioMetadata$Key {
    static {
        throw new NoClassDefFoundError();
    }
}
