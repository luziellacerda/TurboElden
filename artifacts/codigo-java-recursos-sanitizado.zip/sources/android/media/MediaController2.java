package android.media;

public class MediaController2 implements AutoCloseable {

    public class ControllerCallback {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
