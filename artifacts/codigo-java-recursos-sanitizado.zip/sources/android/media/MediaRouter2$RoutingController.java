package android.media;

public class MediaRouter2$RoutingController {
    static {
        throw new NoClassDefFoundError();
    }
}
