package android.media;

public interface AudioManager$OnCommunicationDeviceChangedListener {
    static {
        throw new NoClassDefFoundError();
    }
}
