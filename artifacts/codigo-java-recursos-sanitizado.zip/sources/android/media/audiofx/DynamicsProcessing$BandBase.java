package android.media.audiofx;

public class DynamicsProcessing$BandBase {
    static {
        throw new NoClassDefFoundError();
    }
}
