package android.media.audiofx;

public class DynamicsProcessing$BandStage extends DynamicsProcessing$Stage {
    static {
        throw new NoClassDefFoundError();
    }
}
