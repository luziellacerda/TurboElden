package android.media.audiofx;

public class DynamicsProcessing$Stage {
    static {
        throw new NoClassDefFoundError();
    }
}
