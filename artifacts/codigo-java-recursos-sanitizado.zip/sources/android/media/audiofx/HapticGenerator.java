package android.media.audiofx;

public class HapticGenerator extends AudioEffect implements AutoCloseable {
    static {
        throw new NoClassDefFoundError();
    }
}
