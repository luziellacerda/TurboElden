package android.media;

public interface MediaDrm$OnSessionLostStateListener {
    static {
        throw new NoClassDefFoundError();
    }
}
