package android.media;

public interface AudioTrack$OnCodecFormatChangedListener {
    static {
        throw new NoClassDefFoundError();
    }
}
