package android.hardware.lights;

public class LightsManager {

    public class LightsSession implements AutoCloseable {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
