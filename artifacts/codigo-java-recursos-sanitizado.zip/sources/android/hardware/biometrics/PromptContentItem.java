package android.hardware.biometrics;

public interface PromptContentItem {
    static {
        throw new NoClassDefFoundError();
    }
}
