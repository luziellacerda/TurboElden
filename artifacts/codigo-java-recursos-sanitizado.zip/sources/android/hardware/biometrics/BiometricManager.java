package android.hardware.biometrics;

public class BiometricManager {

    public interface Authenticators {
        static {
            throw new NoClassDefFoundError();
        }
    }

    public class Strings {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
