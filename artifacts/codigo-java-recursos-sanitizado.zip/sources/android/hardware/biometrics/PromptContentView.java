package android.hardware.biometrics;

public interface PromptContentView {
    static {
        throw new NoClassDefFoundError();
    }
}
