package android.hardware.biometrics;

public class BiometricPrompt {

    public class AuthenticationCallback {
        static {
            throw new NoClassDefFoundError();
        }
    }

    public class AuthenticationResult {
        static {
            throw new NoClassDefFoundError();
        }
    }

    public class Builder {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
