package android.hardware;

public class SensorPrivacyManager$Sensors {
    static {
        throw new NoClassDefFoundError();
    }
}
