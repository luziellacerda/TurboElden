package android.hardware;

public class BatteryState {
    static {
        throw new NoClassDefFoundError();
    }
}
