package android.hardware.camera2;

public class CameraExtensionSession implements AutoCloseable {

    public class ExtensionCaptureCallback {
        static {
            throw new NoClassDefFoundError();
        }
    }

    public class StateCallback {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
