package android.hardware.camera2.params;

public class MultiResolutionStreamInfo {
    static {
        throw new NoClassDefFoundError();
    }
}
