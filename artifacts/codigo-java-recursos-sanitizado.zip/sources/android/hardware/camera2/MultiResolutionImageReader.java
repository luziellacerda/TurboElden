package android.hardware.camera2;

public class MultiResolutionImageReader implements AutoCloseable {
    static {
        throw new NoClassDefFoundError();
    }
}
