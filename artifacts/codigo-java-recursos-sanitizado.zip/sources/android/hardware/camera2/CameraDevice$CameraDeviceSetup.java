package android.hardware.camera2;

public class CameraDevice$CameraDeviceSetup {
    static {
        throw new NoClassDefFoundError();
    }
}
