package android.hardware.camera2;

public class CameraOfflineSession extends CameraCaptureSession {

    public class CameraOfflineSessionCallback {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
