package android.companion;

public class DeviceNotAssociatedException extends RuntimeException {
    static {
        throw new NoClassDefFoundError();
    }
}
