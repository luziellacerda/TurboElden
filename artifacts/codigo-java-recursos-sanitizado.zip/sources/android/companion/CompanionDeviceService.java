package android.companion;

import android.app.Service;

public class CompanionDeviceService extends Service {
    static {
        throw new NoClassDefFoundError();
    }
}
