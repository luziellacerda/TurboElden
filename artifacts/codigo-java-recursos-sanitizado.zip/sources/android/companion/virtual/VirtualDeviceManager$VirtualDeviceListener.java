package android.companion.virtual;

public interface VirtualDeviceManager$VirtualDeviceListener {
    static {
        throw new NoClassDefFoundError();
    }
}
