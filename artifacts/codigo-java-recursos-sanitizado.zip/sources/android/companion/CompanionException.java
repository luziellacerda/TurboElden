package android.companion;

public class CompanionException extends RuntimeException {
    static {
        throw new NoClassDefFoundError();
    }
}
