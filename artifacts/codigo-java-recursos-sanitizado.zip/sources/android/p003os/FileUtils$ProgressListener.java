package android.p003os;

public interface FileUtils$ProgressListener {
    static {
        throw new NoClassDefFoundError();
    }
}
