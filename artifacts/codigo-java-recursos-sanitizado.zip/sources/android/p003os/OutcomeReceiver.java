package android.p003os;

public interface OutcomeReceiver {
    static {
        throw new NoClassDefFoundError();
    }
}
