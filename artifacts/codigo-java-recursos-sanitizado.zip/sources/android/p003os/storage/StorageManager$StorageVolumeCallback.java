package android.p003os.storage;

public class StorageManager$StorageVolumeCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
