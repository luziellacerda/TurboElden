package android.p003os.strictmode;

public final class ExplicitGcViolation extends Violation {
    static {
        throw new NoClassDefFoundError();
    }
}
