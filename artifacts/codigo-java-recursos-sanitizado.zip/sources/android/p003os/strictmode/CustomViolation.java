package android.p003os.strictmode;

public final class CustomViolation extends Violation {
    static {
        throw new NoClassDefFoundError();
    }
}
