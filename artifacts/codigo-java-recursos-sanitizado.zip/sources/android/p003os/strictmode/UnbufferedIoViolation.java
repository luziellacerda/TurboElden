package android.p003os.strictmode;

public final class UnbufferedIoViolation extends Violation {
    static {
        throw new NoClassDefFoundError();
    }
}
