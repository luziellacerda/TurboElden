package android.p003os.strictmode;

public final class IntentReceiverLeakedViolation extends Violation {
    static {
        throw new NoClassDefFoundError();
    }
}
