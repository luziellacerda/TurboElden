package android.p003os.strictmode;

public final class SqliteObjectLeakedViolation extends Violation {
    static {
        throw new NoClassDefFoundError();
    }
}
