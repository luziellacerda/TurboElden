package android.p003os.strictmode;

public final class DiskWriteViolation extends Violation {
    static {
        throw new NoClassDefFoundError();
    }
}
