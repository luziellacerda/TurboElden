package android.p003os.strictmode;

public final class NonSdkApiUsedViolation extends Violation {
    static {
        throw new NoClassDefFoundError();
    }
}
