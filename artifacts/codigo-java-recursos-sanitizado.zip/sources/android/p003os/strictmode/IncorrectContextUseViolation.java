package android.p003os.strictmode;

public final class IncorrectContextUseViolation extends Violation {
    static {
        throw new NoClassDefFoundError();
    }
}
