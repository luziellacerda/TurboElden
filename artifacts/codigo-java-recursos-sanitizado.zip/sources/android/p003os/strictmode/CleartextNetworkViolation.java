package android.p003os.strictmode;

public final class CleartextNetworkViolation extends Violation {
    static {
        throw new NoClassDefFoundError();
    }
}
