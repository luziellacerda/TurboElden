package android.p003os.strictmode;

public final class DiskReadViolation extends Violation {
    static {
        throw new NoClassDefFoundError();
    }
}
