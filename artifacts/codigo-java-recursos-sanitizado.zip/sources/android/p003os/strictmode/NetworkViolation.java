package android.p003os.strictmode;

public final class NetworkViolation extends Violation {
    static {
        throw new NoClassDefFoundError();
    }
}
