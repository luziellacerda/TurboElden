package android.p003os.strictmode;

public final class ImplicitDirectBootViolation extends Violation {
    static {
        throw new NoClassDefFoundError();
    }
}
