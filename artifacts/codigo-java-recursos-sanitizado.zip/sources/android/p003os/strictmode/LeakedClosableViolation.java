package android.p003os.strictmode;

public final class LeakedClosableViolation extends Violation {
    static {
        throw new NoClassDefFoundError();
    }
}
