package android.p003os.strictmode;

public class InstanceCountViolation extends Violation {
    static {
        throw new NoClassDefFoundError();
    }
}
