package android.p003os.strictmode;

public final class ContentUriWithoutPermissionViolation extends Violation {
    static {
        throw new NoClassDefFoundError();
    }
}
