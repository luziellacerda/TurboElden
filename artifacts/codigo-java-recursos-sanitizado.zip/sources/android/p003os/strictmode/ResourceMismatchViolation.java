package android.p003os.strictmode;

public final class ResourceMismatchViolation extends Violation {
    static {
        throw new NoClassDefFoundError();
    }
}
