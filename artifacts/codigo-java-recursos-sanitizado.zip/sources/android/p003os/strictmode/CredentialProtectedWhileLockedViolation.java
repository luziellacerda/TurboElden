package android.p003os.strictmode;

public final class CredentialProtectedWhileLockedViolation extends Violation {
    static {
        throw new NoClassDefFoundError();
    }
}
