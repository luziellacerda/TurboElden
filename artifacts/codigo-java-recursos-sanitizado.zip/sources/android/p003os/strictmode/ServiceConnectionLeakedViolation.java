package android.p003os.strictmode;

public final class ServiceConnectionLeakedViolation extends Violation {
    static {
        throw new NoClassDefFoundError();
    }
}
