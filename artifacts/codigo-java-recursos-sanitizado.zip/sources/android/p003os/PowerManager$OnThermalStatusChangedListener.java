package android.p003os;

public interface PowerManager$OnThermalStatusChangedListener {
    static {
        throw new NoClassDefFoundError();
    }
}
