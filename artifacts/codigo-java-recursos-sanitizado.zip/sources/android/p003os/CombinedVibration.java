package android.p003os;

import android.os.Parcelable;

public class CombinedVibration implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}
