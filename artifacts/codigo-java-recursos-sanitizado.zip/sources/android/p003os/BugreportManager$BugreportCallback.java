package android.p003os;

public class BugreportManager$BugreportCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
