package android.p003os;

public class SecurityStateManager {
    static {
        throw new NoClassDefFoundError();
    }
}
