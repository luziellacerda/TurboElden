package android.p003os.ext;

public class SdkExtensions {
    static {
        throw new NoClassDefFoundError();
    }
}
