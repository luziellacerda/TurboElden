package android.p003os;

import java.io.Closeable;

public class PerformanceHintManager$Session implements Closeable {
    static {
        throw new NoClassDefFoundError();
    }
}
