package android.p003os;

public class Build$Partition {
    static {
        throw new NoClassDefFoundError();
    }
}
