package android.p003os;

public interface PowerManager$WakeLockStateListener {
    static {
        throw new NoClassDefFoundError();
    }
}
