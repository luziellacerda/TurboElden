package android.p003os;

public class LimitExceededException extends IllegalStateException {
    static {
        throw new NoClassDefFoundError();
    }
}
