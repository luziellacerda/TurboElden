package android.net;

public interface TransportInfo {
    static {
        throw new NoClassDefFoundError();
    }
}
