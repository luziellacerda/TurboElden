package android.net.wifi;

public class WifiConfiguration$GroupMgmtCipher {
    static {
        throw new NoClassDefFoundError();
    }
}
