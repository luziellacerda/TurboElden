package android.net.wifi;

import android.os.Parcelable;

public class ScanResult$InformationElement implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}
