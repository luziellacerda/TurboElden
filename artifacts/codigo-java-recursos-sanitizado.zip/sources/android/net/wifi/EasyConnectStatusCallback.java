package android.net.wifi;

public class EasyConnectStatusCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
