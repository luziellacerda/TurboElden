package android.net.wifi;

public class WifiManager$SubsystemRestartTrackingCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
