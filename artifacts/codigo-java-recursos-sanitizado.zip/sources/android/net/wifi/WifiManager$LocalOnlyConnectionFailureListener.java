package android.net.wifi;

public interface WifiManager$LocalOnlyConnectionFailureListener {
    static {
        throw new NoClassDefFoundError();
    }
}
