package android.net.wifi;

public interface WifiManager$SuggestionUserApprovalStatusListener {
    static {
        throw new NoClassDefFoundError();
    }
}
