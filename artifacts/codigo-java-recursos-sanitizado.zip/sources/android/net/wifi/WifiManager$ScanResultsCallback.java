package android.net.wifi;

public class WifiManager$ScanResultsCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
