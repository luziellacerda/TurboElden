package android.net.wifi;

public interface WifiManager$SuggestionConnectionStatusListener {
    static {
        throw new NoClassDefFoundError();
    }
}
