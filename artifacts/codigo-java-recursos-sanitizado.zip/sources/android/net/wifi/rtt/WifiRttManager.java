package android.net.wifi.rtt;

public class WifiRttManager {
    static {
        throw new NoClassDefFoundError();
    }
}
