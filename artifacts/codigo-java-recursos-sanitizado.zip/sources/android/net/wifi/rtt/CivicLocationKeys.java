package android.net.wifi.rtt;

public class CivicLocationKeys {
    static {
        throw new NoClassDefFoundError();
    }
}
