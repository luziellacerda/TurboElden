package android.net.wifi.rtt;

public class RangingResultCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
