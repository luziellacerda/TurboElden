package android.net.wifi;

public class WifiManager$InterfaceCreationImpact {
    static {
        throw new NoClassDefFoundError();
    }
}
