package android.net.wifi.p2p;

public interface WifiP2pManager$ExternalApproverRequestListener {
    static {
        throw new NoClassDefFoundError();
    }
}
