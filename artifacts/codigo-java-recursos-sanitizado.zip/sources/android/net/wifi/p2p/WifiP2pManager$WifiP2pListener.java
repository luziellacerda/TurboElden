package android.net.wifi.p2p;

public interface WifiP2pManager$WifiP2pListener {
    static {
        throw new NoClassDefFoundError();
    }
}
