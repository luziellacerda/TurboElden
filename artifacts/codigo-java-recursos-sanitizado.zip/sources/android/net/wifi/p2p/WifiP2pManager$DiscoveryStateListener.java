package android.net.wifi.p2p;

public interface WifiP2pManager$DiscoveryStateListener {
    static {
        throw new NoClassDefFoundError();
    }
}
