package android.net.wifi.p2p;

public interface WifiP2pManager$P2pStateListener {
    static {
        throw new NoClassDefFoundError();
    }
}
