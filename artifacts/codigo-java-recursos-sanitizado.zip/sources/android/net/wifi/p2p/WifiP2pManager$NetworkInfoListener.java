package android.net.wifi.p2p;

public interface WifiP2pManager$NetworkInfoListener {
    static {
        throw new NoClassDefFoundError();
    }
}
