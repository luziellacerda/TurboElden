package android.net.wifi.p2p;

public interface WifiP2pManager$DeviceInfoListener {
    static {
        throw new NoClassDefFoundError();
    }
}
