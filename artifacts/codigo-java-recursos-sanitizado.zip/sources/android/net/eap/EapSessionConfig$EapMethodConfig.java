package android.net.eap;

public class EapSessionConfig$EapMethodConfig {
    static {
        throw new NoClassDefFoundError();
    }
}
