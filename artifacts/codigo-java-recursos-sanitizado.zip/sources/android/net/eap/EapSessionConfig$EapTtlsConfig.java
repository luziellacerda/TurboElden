package android.net.eap;

public class EapSessionConfig$EapTtlsConfig extends EapSessionConfig$EapMethodConfig {
    static {
        throw new NoClassDefFoundError();
    }
}
