package android.net.eap;

public class EapSessionConfig$EapAkaPrimeConfig extends EapSessionConfig$EapAkaConfig {
    static {
        throw new NoClassDefFoundError();
    }
}
