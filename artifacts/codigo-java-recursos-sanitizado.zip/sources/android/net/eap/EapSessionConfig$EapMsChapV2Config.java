package android.net.eap;

public class EapSessionConfig$EapMsChapV2Config extends EapSessionConfig$EapMethodConfig {
    static {
        throw new NoClassDefFoundError();
    }
}
