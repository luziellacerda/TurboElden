package android.net.eap;

public class EapInfo {
    static {
        throw new NoClassDefFoundError();
    }
}
