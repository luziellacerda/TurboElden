package android.net.eap;

public class EapSessionConfig$EapAkaConfig extends EapSessionConfig$EapMethodConfig {
    static {
        throw new NoClassDefFoundError();
    }
}
