package android.net.eap;

public class EapSessionConfig$EapSimConfig extends EapSessionConfig$EapMethodConfig {
    static {
        throw new NoClassDefFoundError();
    }
}
