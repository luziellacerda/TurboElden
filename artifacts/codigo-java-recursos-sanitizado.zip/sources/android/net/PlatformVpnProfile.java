package android.net;

public class PlatformVpnProfile {
    static {
        throw new NoClassDefFoundError();
    }
}
