package android.net.nsd;

public interface NsdManager$ServiceInfoCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
