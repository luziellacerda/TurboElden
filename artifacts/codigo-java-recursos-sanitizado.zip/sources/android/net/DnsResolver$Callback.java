package android.net;

public interface DnsResolver$Callback {
    static {
        throw new NoClassDefFoundError();
    }
}
