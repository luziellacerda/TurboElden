package android.net;

public class VpnManager {
    static {
        throw new NoClassDefFoundError();
    }
}
