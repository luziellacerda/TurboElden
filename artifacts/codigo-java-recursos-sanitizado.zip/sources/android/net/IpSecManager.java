package android.net;

import android.util.AndroidException;

public class IpSecManager {

    public final class ResourceUnavailableException extends AndroidException {
        static {
            throw new NoClassDefFoundError();
        }
    }

    public final class SpiUnavailableException extends AndroidException {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
