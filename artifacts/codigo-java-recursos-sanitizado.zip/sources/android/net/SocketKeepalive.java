package android.net;

public class SocketKeepalive implements AutoCloseable {

    public class Callback {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
