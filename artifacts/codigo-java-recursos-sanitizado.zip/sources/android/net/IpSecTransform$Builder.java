package android.net;

public class IpSecTransform$Builder {
    static {
        throw new NoClassDefFoundError();
    }
}
