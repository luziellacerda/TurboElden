package android.net.vcn;

public class VcnManager {

    public class VcnStatusCallback {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
