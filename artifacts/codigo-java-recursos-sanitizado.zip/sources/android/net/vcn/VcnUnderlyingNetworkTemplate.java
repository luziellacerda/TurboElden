package android.net.vcn;

public class VcnUnderlyingNetworkTemplate {
    static {
        throw new NoClassDefFoundError();
    }
}
