package android.net;

public class InetAddresses {
    static {
        throw new NoClassDefFoundError();
    }
}
