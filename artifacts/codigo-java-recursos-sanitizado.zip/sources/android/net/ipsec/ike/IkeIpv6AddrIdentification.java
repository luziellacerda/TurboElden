package android.net.ipsec.ike;

public class IkeIpv6AddrIdentification extends IkeIdentification {
    static {
        throw new NoClassDefFoundError();
    }
}
