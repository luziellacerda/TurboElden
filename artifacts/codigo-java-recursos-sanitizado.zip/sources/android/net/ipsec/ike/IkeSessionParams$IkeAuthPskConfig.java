package android.net.ipsec.ike;

public class IkeSessionParams$IkeAuthPskConfig extends IkeSessionParams$IkeAuthConfig {
    static {
        throw new NoClassDefFoundError();
    }
}
