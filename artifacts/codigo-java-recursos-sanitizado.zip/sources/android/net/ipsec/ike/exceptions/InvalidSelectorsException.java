package android.net.ipsec.ike.exceptions;

public final class InvalidSelectorsException extends IkeProtocolException {
    static {
        throw new NoClassDefFoundError();
    }
}
