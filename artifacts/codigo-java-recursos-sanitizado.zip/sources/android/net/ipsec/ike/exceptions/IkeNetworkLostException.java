package android.net.ipsec.ike.exceptions;

public final class IkeNetworkLostException extends IkeNonProtocolException {
    static {
        throw new NoClassDefFoundError();
    }
}
