package android.net.ipsec.ike.exceptions;

public final class IkeIOException extends IkeNonProtocolException {
    static {
        throw new NoClassDefFoundError();
    }
}
