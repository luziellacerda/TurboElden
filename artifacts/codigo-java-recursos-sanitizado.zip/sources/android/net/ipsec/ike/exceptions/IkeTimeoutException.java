package android.net.ipsec.ike.exceptions;

import java.io.IOException;

public final class IkeTimeoutException extends IOException {
    static {
        throw new NoClassDefFoundError();
    }
}
