package android.net.ipsec.ike.exceptions;

public class IkeException extends Exception {
    static {
        throw new NoClassDefFoundError();
    }
}
