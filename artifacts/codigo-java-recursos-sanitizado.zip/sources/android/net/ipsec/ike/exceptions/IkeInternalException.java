package android.net.ipsec.ike.exceptions;

public final class IkeInternalException extends IkeNonProtocolException {
    static {
        throw new NoClassDefFoundError();
    }
}
