package android.net.ipsec.ike.exceptions;

public class IkeProtocolException extends IkeException {
    static {
        throw new NoClassDefFoundError();
    }
}
