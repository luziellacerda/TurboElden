package android.net.ipsec.ike.exceptions;

public final class InvalidKeException extends IkeProtocolException {
    static {
        throw new NoClassDefFoundError();
    }
}
