package android.net.ipsec.ike.exceptions;

public final class InvalidMajorVersionException extends IkeProtocolException {
    static {
        throw new NoClassDefFoundError();
    }
}
