package android.net.ipsec.ike.exceptions;

public class IkeNonProtocolException extends IkeException {
    static {
        throw new NoClassDefFoundError();
    }
}
