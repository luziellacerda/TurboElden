package android.net.ipsec.ike;

public class IkeIdentification {
    static {
        throw new NoClassDefFoundError();
    }
}
