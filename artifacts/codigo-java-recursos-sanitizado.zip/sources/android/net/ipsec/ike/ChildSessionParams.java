package android.net.ipsec.ike;

public class ChildSessionParams {
    static {
        throw new NoClassDefFoundError();
    }
}
