package android.net.ipsec.ike;

public interface TunnelModeChildSessionParams$ConfigRequestIpv6Address extends TunnelModeChildSessionParams$TunnelModeChildConfigRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
