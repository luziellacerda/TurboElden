package android.net.ipsec.ike;

public class IkeSessionParams$IkeAuthDigitalSignLocalConfig extends IkeSessionParams$IkeAuthConfig {
    static {
        throw new NoClassDefFoundError();
    }
}
