package android.net.ipsec.ike;

public class IkeFqdnIdentification extends IkeIdentification {
    static {
        throw new NoClassDefFoundError();
    }
}
