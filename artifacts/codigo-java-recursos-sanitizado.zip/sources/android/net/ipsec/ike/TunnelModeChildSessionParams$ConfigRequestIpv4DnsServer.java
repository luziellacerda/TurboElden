package android.net.ipsec.ike;

public interface TunnelModeChildSessionParams$ConfigRequestIpv4DnsServer extends TunnelModeChildSessionParams$TunnelModeChildConfigRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
