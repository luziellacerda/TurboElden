package android.net.ipsec.ike;

public class IkeSessionParams$IkeAuthDigitalSignRemoteConfig extends IkeSessionParams$IkeAuthConfig {
    static {
        throw new NoClassDefFoundError();
    }
}
