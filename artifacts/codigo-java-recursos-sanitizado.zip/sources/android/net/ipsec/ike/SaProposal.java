package android.net.ipsec.ike;

public class SaProposal {
    static {
        throw new NoClassDefFoundError();
    }
}
