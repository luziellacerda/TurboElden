package android.net.ipsec.ike;

public interface TunnelModeChildSessionParams$ConfigRequestIpv4Address extends TunnelModeChildSessionParams$TunnelModeChildConfigRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
