package android.net.ipsec.ike;

public interface TunnelModeChildSessionParams$ConfigRequestIpv6DnsServer extends TunnelModeChildSessionParams$TunnelModeChildConfigRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
