package android.net.ipsec.ike;

public interface IkeSessionCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
