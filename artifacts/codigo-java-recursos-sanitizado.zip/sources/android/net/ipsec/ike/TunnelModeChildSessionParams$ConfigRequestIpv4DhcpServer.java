package android.net.ipsec.ike;

public interface TunnelModeChildSessionParams$ConfigRequestIpv4DhcpServer extends TunnelModeChildSessionParams$TunnelModeChildConfigRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
