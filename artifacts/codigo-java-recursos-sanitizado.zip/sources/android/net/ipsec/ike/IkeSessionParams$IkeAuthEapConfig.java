package android.net.ipsec.ike;

public class IkeSessionParams$IkeAuthEapConfig extends IkeSessionParams$IkeAuthConfig {
    static {
        throw new NoClassDefFoundError();
    }
}
