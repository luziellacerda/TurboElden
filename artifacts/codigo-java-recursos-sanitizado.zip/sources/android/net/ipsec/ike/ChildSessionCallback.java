package android.net.ipsec.ike;

public interface ChildSessionCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
