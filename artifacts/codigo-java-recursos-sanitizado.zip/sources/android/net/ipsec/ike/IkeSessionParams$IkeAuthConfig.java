package android.net.ipsec.ike;

public class IkeSessionParams$IkeAuthConfig {
    static {
        throw new NoClassDefFoundError();
    }
}
