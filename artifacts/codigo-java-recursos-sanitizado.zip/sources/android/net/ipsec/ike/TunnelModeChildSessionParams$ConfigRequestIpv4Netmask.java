package android.net.ipsec.ike;

public interface TunnelModeChildSessionParams$ConfigRequestIpv4Netmask extends TunnelModeChildSessionParams$TunnelModeChildConfigRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
