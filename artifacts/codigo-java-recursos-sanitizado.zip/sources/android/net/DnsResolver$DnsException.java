package android.net;

public class DnsResolver$DnsException extends Exception {
    static {
        throw new NoClassDefFoundError();
    }
}
