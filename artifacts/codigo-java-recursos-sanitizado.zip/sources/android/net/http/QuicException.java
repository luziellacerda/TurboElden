package android.net.http;

public class QuicException extends NetworkException {
    static {
        throw new NoClassDefFoundError();
    }
}
