package android.net.http;

public class UrlResponseInfo {
    static {
        throw new NoClassDefFoundError();
    }
}
