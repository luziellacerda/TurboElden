package android.net.http;

public class BidirectionalStream {

    public class Builder {
        static {
            throw new NoClassDefFoundError();
        }
    }

    public interface Callback {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
