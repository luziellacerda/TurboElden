package android.net.http;

public class UploadDataSink {
    static {
        throw new NoClassDefFoundError();
    }
}
