package android.net.http;

public class ConnectionMigrationOptions {
    static {
        throw new NoClassDefFoundError();
    }
}
