package android.net.http;

import java.util.concurrent.RejectedExecutionException;

public final class InlineExecutionProhibitedException extends RejectedExecutionException {
    static {
        throw new NoClassDefFoundError();
    }
}
