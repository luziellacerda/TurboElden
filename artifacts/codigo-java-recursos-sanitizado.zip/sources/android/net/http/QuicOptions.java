package android.net.http;

public class QuicOptions {
    static {
        throw new NoClassDefFoundError();
    }
}
