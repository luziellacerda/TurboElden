package android.net.http;

import java.io.IOException;

public class HttpException extends IOException {
    static {
        throw new NoClassDefFoundError();
    }
}
