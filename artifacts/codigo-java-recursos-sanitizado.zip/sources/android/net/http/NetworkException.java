package android.net.http;

public class NetworkException extends HttpException {
    static {
        throw new NoClassDefFoundError();
    }
}
