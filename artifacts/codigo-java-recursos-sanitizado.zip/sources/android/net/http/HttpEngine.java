package android.net.http;

public class HttpEngine {

    public class Builder {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
