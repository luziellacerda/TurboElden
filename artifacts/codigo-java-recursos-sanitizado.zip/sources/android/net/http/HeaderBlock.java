package android.net.http;

public class HeaderBlock {
    static {
        throw new NoClassDefFoundError();
    }
}
