package android.net.http;

public class UrlRequest {

    public class Builder {
        static {
            throw new NoClassDefFoundError();
        }
    }

    public interface Callback {
        static {
            throw new NoClassDefFoundError();
        }
    }

    public class Status {
        static {
            throw new NoClassDefFoundError();
        }
    }

    public interface StatusListener {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
