package android.net.http;

public class CallbackException extends HttpException {
    static {
        throw new NoClassDefFoundError();
    }
}
