package android.net.http;

public class DnsOptions$StaleDnsOptions {
    static {
        throw new NoClassDefFoundError();
    }
}
