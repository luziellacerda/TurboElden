package android.net;

public class ConnectivityDiagnosticsManager {

    public class ConnectivityDiagnosticsCallback {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
