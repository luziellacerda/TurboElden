package android.net.ssl;

public class SSLEngines {
    static {
        throw new NoClassDefFoundError();
    }
}
