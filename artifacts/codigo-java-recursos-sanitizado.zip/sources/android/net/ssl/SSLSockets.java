package android.net.ssl;

public class SSLSockets {
    static {
        throw new NoClassDefFoundError();
    }
}
