package android.accessibilityservice;

public interface BrailleDisplayController {

    public interface BrailleDisplayCallback {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}
