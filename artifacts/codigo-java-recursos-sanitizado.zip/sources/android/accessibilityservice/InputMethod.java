package android.accessibilityservice;

public class InputMethod {
    static {
        throw new NoClassDefFoundError();
    }
}
