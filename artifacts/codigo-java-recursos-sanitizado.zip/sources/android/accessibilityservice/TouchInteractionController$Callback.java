package android.accessibilityservice;

public interface TouchInteractionController$Callback {
    static {
        throw new NoClassDefFoundError();
    }
}
