package android.accessibilityservice;

public interface AccessibilityService$TakeScreenshotCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
