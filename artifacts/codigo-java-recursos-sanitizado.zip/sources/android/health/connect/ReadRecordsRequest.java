package android.health.connect;

public class ReadRecordsRequest {
    static {
        throw new NoClassDefFoundError();
    }
}
