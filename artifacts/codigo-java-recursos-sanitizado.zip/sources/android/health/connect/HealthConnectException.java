package android.health.connect;

public class HealthConnectException extends RuntimeException {
    static {
        throw new NoClassDefFoundError();
    }
}
