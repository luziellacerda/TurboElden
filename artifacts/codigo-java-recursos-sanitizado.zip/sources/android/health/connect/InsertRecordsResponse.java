package android.health.connect;

public class InsertRecordsResponse {
    static {
        throw new NoClassDefFoundError();
    }
}
