package android.health.connect;

public interface TimeRangeFilter {
    static {
        throw new NoClassDefFoundError();
    }
}
