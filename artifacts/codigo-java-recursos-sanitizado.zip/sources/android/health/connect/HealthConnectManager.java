package android.health.connect;

public class HealthConnectManager {
    static {
        throw new NoClassDefFoundError();
    }
}
