package android.health.connect;

public class ReadRecordsResponse {
    static {
        throw new NoClassDefFoundError();
    }
}
