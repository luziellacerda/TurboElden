package android.health.connect;

public class RecordIdFilter {
    static {
        throw new NoClassDefFoundError();
    }
}
