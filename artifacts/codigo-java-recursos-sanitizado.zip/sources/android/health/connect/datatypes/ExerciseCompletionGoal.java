package android.health.connect.datatypes;

public class ExerciseCompletionGoal {
    static {
        throw new NoClassDefFoundError();
    }
}
