package android.health.connect.datatypes;

public class ExercisePerformanceGoal {
    static {
        throw new NoClassDefFoundError();
    }
}
