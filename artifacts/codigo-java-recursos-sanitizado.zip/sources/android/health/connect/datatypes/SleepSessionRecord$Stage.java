package android.health.connect.datatypes;

public class SleepSessionRecord$Stage {
    static {
        throw new NoClassDefFoundError();
    }
}
