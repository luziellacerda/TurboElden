package android.health.connect.datatypes;

public class InstantRecord extends Record {
    static {
        throw new NoClassDefFoundError();
    }
}
