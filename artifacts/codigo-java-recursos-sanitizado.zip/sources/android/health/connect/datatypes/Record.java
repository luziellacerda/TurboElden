package android.health.connect.datatypes;

public class Record {
    static {
        throw new NoClassDefFoundError();
    }
}
