package android.health.connect.datatypes;

public class IntervalRecord extends Record {
    static {
        throw new NoClassDefFoundError();
    }
}
