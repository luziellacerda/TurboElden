package android.location;

public interface Geocoder$GeocodeListener {
    static {
        throw new NoClassDefFoundError();
    }
}
