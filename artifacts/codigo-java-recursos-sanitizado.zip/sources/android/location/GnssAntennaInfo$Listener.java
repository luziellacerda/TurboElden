package android.location;

public interface GnssAntennaInfo$Listener {
    static {
        throw new NoClassDefFoundError();
    }
}
