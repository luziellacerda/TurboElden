package android.location;

public class GnssAntennaInfo$Builder {
    static {
        throw new NoClassDefFoundError();
    }
}
