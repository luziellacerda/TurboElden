package android.bluetooth;

import java.io.IOException;

public class BluetoothSocketException extends IOException {
    static {
        throw new NoClassDefFoundError();
    }
}
