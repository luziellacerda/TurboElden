package android.bluetooth;

public class BluetoothHidDevice$Callback {
    static {
        throw new NoClassDefFoundError();
    }
}
