const float PI=3.14159265359;
uniform float time;
// A small coordinated turn: yaw changes continuously, bank leads that turn,
// and pitch/height settle on a slower climb cycle. The short engine response lag
// avoids a rigid display-model rock or a sudden reset at the end of a cycle.
float turnPhase(){return time*.42;}
float boost(){
 float load=cos(turnPhase()-.30);
 return clamp(.66+.13*load*load+.065*sin(time*.31-.95)+.015*sin(time*.74-.15),.54,.90);
}
vec3 shipOffset(){return vec3(.075*sin(turnPhase()-.4),.045*sin(time*.31-.7)+.008*sin(time*.93),.07*sin(time*.20));}
mat3 shipRotation(){
 float yaw=.11+.22*sin(turnPhase())+.035*sin(time*.87+.7);
 float roll=-.30*cos(turnPhase())-.055*cos(time*.87+.7)+.012*sin(time*1.7);
 float pitch=.05*sin(time*.31-.7)+.02*sin(time*.74+.2);
 float a=cos(yaw),b=sin(yaw),c=cos(roll),d=sin(roll),e=cos(pitch),f=sin(pitch);
 return mat3(a,0.,-b,0.,1.,0.,b,0.,a)*mat3(c,d,0.,-d,c,0.,0.,0.,1.)*mat3(1.,0.,0.,0.,e,f,0.,-f,e);
}
vec3 camera(){return vec3(1.60,1.80,-3.10);}
// Framing includes the entire exhaust during the largest bank; scale is unchanged.
vec3 target(){return vec3(-.10,.015,-.28);}
mat3 cameraBasis(){vec3 z=normalize(camera()-target());vec3 x=normalize(cross(vec3(0.,1.,0.),z));return mat3(x,cross(z,x),z);}
mat3 transpose3(mat3 m){return mat3(m[0][0],m[1][0],m[2][0],m[0][1],m[1][1],m[2][1],m[0][2],m[1][2],m[2][2]);}
vec3 worldFromLocal(vec3 p){return shipRotation()*p+shipOffset();}
vec3 localFromWorld(vec3 p){return transpose3(shipRotation())*(p-shipOffset());}
vec4 project(vec3 p){vec3 v=transpose3(cameraBasis())*(p-camera());float near=.1,far=20.;return vec4(v.xy*2.9,-(far+near)/(far-near)*v.z-2.*far*near/(far-near),-v.z);}
vec3 tone(vec3 c){c=max(c,vec3(0.));c=(c*(2.51*c+.03))/(c*(2.43*c+.59)+.14);return pow(clamp(c,0.,1.),vec3(1./2.2));}
