#include <cstring>
#include <algorithm>
#include <array>

#if VIDEO_STATS
#include "libretro_log.h"
#endif

#include "inline.h"
#include "libretro_common.h"
#include "neocd_endian.h"
#include "neogeocd.h"
#include "timer.h"
#include "video.h"

static const std::array<uint32_t, 256> SPR_DECODE_TABLE {
    0x00000000, 0x00000001, 0x00000010, 0x00000011,
    0x00000100, 0x00000101, 0x00000110, 0x00000111,
    0x00001000, 0x00001001, 0x00001010, 0x00001011,
    0x00001100, 0x00001101, 0x00001110, 0x00001111,
    0x00010000, 0x00010001, 0x00010010, 0x00010011,
    0x00010100, 0x00010101, 0x00010110, 0x00010111,
    0x00011000, 0x00011001, 0x00011010, 0x00011011,
    0x00011100, 0x00011101, 0x00011110, 0x00011111,
    0x00100000, 0x00100001, 0x00100010, 0x00100011,
    0x00100100, 0x00100101, 0x00100110, 0x00100111,
    0x00101000, 0x00101001, 0x00101010, 0x00101011,
    0x00101100, 0x00101101, 0x00101110, 0x00101111,
    0x00110000, 0x00110001, 0x00110010, 0x00110011,
    0x00110100, 0x00110101, 0x00110110, 0x00110111,
    0x00111000, 0x00111001, 0x00111010, 0x00111011,
    0x00111100, 0x00111101, 0x00111110, 0x00111111,
    0x01000000, 0x01000001, 0x01000010, 0x01000011,
    0x01000100, 0x01000101, 0x01000110, 0x01000111,
    0x01001000, 0x01001001, 0x01001010, 0x01001011,
    0x01001100, 0x01001101, 0x01001110, 0x01001111,
    0x01010000, 0x01010001, 0x01010010, 0x01010011,
    0x01010100, 0x01010101, 0x01010110, 0x01010111,
    0x01011000, 0x01011001, 0x01011010, 0x01011011,
    0x01011100, 0x01011101, 0x01011110, 0x01011111,
    0x01100000, 0x01100001, 0x01100010, 0x01100011,
    0x01100100, 0x01100101, 0x01100110, 0x01100111,
    0x01101000, 0x01101001, 0x01101010, 0x01101011,
    0x01101100, 0x01101101, 0x01101110, 0x01101111,
    0x01110000, 0x01110001, 0x01110010, 0x01110011,
    0x01110100, 0x01110101, 0x01110110, 0x01110111,
    0x01111000, 0x01111001, 0x01111010, 0x01111011,
    0x01111100, 0x01111101, 0x01111110, 0x01111111,
    0x10000000, 0x10000001, 0x10000010, 0x10000011,
    0x10000100, 0x10000101, 0x10000110, 0x10000111,
    0x10001000, 0x10001001, 0x10001010, 0x10001011,
    0x10001100, 0x10001101, 0x10001110, 0x10001111,
    0x10010000, 0x10010001, 0x10010010, 0x10010011,
    0x10010100, 0x10010101, 0x10010110, 0x10010111,
    0x10011000, 0x10011001, 0x10011010, 0x10011011,
    0x10011100, 0x10011101, 0x10011110, 0x10011111,
    0x10100000, 0x10100001, 0x10100010, 0x10100011,
    0x10100100, 0x10100101, 0x10100110, 0x10100111,
    0x10101000, 0x10101001, 0x10101010, 0x10101011,
    0x10101100, 0x10101101, 0x10101110, 0x10101111,
    0x10110000, 0x10110001, 0x10110010, 0x10110011,
    0x10110100, 0x10110101, 0x10110110, 0x10110111,
    0x10111000, 0x10111001, 0x10111010, 0x10111011,
    0x10111100, 0x10111101, 0x10111110, 0x10111111,
    0x11000000, 0x11000001, 0x11000010, 0x11000011,
    0x11000100, 0x11000101, 0x11000110, 0x11000111,
    0x11001000, 0x11001001, 0x11001010, 0x11001011,
    0x11001100, 0x11001101, 0x11001110, 0x11001111,
    0x11010000, 0x11010001, 0x11010010, 0x11010011,
    0x11010100, 0x11010101, 0x11010110, 0x11010111,
    0x11011000, 0x11011001, 0x11011010, 0x11011011,
    0x11011100, 0x11011101, 0x11011110, 0x11011111,
    0x11100000, 0x11100001, 0x11100010, 0x11100011,
    0x11100100, 0x11100101, 0x11100110, 0x11100111,
    0x11101000, 0x11101001, 0x11101010, 0x11101011,
    0x11101100, 0x11101101, 0x11101110, 0x11101111,
    0x11110000, 0x11110001, 0x11110010, 0x11110011,
    0x11110100, 0x11110101, 0x11110110, 0x11110111,
    0x11111000, 0x11111001, 0x11111010, 0x11111011,
    0x11111100, 0x11111101, 0x11111110, 0x11111111
};

static const std::array<uint8_t, 256> X_ZOOM_TABLE{
    0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0,
    0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0,
    0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0,
    1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0,
    1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0,
    1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0,
    1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1,
    1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1,
    1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
};

/* Which of the two pixels a byte of fix graphics leaves opaque, as a
   mask over the pair of RGB565 colours they become. A pair is drawn as
   one blend of the two colours over the two pixels already there, which
   keeps the transparent pixel out of the flow of control: whether a
   given pixel is transparent is a question no two neighbouring pixels
   answer the same way, and a branch on it turns out to cost about four
   times the drawing it guards. The text layer of a screen full of text
   went from 62 microseconds a frame to 15 this way, drawing exactly the
   same pixels.
*/
static const uint32_t FIX_PAIR_MASK[256] = {
#define FIX_MASK_PAIR(n) (((n) & 0x0F) ? 0x0000FFFFu : 0u) | (((n) & 0xF0) ? 0xFFFF0000u : 0u),
#define FIX_MASK_QUAD(a) FIX_MASK_PAIR(a) FIX_MASK_PAIR(a + 1) FIX_MASK_PAIR(a + 2) FIX_MASK_PAIR(a + 3)
#define FIX_MASK_OCTA(a) FIX_MASK_QUAD(a) FIX_MASK_QUAD(a + 4) FIX_MASK_QUAD(a + 8) FIX_MASK_QUAD(a + 12)
#define FIX_MASK_BLOCK(a) FIX_MASK_OCTA(a) FIX_MASK_OCTA(a + 16) FIX_MASK_OCTA(a + 32) FIX_MASK_OCTA(a + 48)
    FIX_MASK_BLOCK(0) FIX_MASK_BLOCK(64) FIX_MASK_BLOCK(128) FIX_MASK_BLOCK(192)
#undef FIX_MASK_BLOCK
#undef FIX_MASK_OCTA
#undef FIX_MASK_QUAD
#undef FIX_MASK_PAIR
};

static_assert(sizeof(FIX_PAIR_MASK) / sizeof(FIX_PAIR_MASK[0]) == 256,
              "The fix pair mask has to cover every byte of pixel data.");

Video::Video() :
    paletteRamPc(nullptr),
    fixUsageMap(nullptr),
    frameBuffer(nullptr),
    activePaletteBank(0),
    autoAnimationCounter(0),
    autoAnimationSpeed(0),
    autoAnimationFrameCounter(0),
    autoAnimationDisabled(false),
    sprDisable(true),
    fixDisable(true),
    videoEnable(false),
    hirqControl(HIRQ_CTRL_DISABLE),
    hirqRegister(0),
    videoramOffset(0),
    videoramModulo(0),
    videoramData(0),
    sprite_x(0),
    sprite_y(0),
    sprite_zoomX(15),
    sprite_zoomY(255),
    sprite_clipping(0x20)
{
    static_assert((FRAMEBUFFER_WIDTH % 16) == 0, "Framebuffer width must be a multiple of 16.");
    static_assert(FRAMEBUFFER_WIDTH <= 320, "Framebuffer width must less or equal to 320.");

    // Palette RAM: 16KiB, converted into RGB565 equivalent
    paletteRamPc = reinterpret_cast<uint16_t*>(std::malloc(Memory::PALETTERAM_SIZE));

    // Fix usage map, if zero tile is fully transparent
    fixUsageMap = reinterpret_cast<uint8_t*>(std::malloc(Memory::FIXRAM_SIZE / 32));

    // 304x224 RGB565 framebuffer
    frameBuffer = reinterpret_cast<uint16_t*>(std::malloc(FRAMEBUFFER_WIDTH * FRAMEBUFFER_HEIGHT * sizeof(uint16_t)));
}

Video::~Video()
{
    if (frameBuffer)
        std::free(frameBuffer);

    if (fixUsageMap)
        std::free(fixUsageMap);

    if (paletteRamPc)
        std::free(paletteRamPc);
}

void Video::reset()
{
    spriteIndexDirty = true;

    std::memset(paletteRamPc, 0, Memory::PALETTERAM_SIZE);
    std::memset(fixUsageMap, 0, Memory::FIXRAM_SIZE / 32);
    activePaletteBank = 0;
    autoAnimationCounter = 0;
    autoAnimationFrameCounter = 0;
    autoAnimationSpeed = 0;
    autoAnimationDisabled = false;
    sprDisable = true;
    fixDisable = true;
    videoEnable = false;
    hirqControl = HIRQ_CTRL_DISABLE;
    hirqRegister = 0;
    videoramOffset = 0;
    videoramModulo = 0;
    videoramData = 0;
    sprite_x = 0;
    sprite_y = 0;
    sprite_zoomX = 15;
    sprite_zoomY = 255;
    sprite_clipping = 0x20;
}

void Video::convertColor(uint32_t index)
{
    uint16_t c = BIG_ENDIAN_WORD(neocd->memory.paletteRam[index]);

#ifdef ABGR1555
    uint16_t out = ((c & 0x000F) << 11) | ((c & 0x1000) >> 2) |
	(((c & 0x00F0) << 2) | ((c & 0x2000) >> 8)) |
	(((c & 0x0F00) >> 7) | ((c & 0x4000) >> 14));

    // Five bit channels have nowhere to put the dark bit's half step.
    if (shadow)
        out = (out >> 1) & 0x3DEF;

    paletteRamPc[index] = out;
#else
    /* Each channel is really six bits on the machine: five from the
       palette word plus the dark bit, inverted, as the low bit shared
       by all three - read out of Geolith's converter. Green is the one
       channel with six bits here, so it carries the dark bit exactly;
       red and blue have nowhere to put a half step and keep their five.
    */
    uint16_t out = ((c & 0x0F00) << 4) | ((c & 0x4000) >> 3) |
        ((c & 0x00F0) << 3) | ((c & 0x2000) >> 7) |
        ((c & 0x000F) << 1) | ((c & 0x1000) >> 12);

    if (!(c & 0x8000))
        out |= 0x0020;

    /* The shadow register hangs a pulldown on every channel and the
       screen comes out at about half brightness; halving each channel
       is the same approximation Geolith's plain converter uses.
    */
    if (shadow)
        out = (out >> 1) & 0x7BEF;

    paletteRamPc[index] = out;
#endif
}

void Video::convertPalette()
{
    for (uint32_t i = 0; i < (Memory::PALETTERAM_SIZE / sizeof(uint16_t)); ++i)
        convertColor(i);
}

void Video::updateFixUsageMap()
{
    uint8_t* fixPtr = neocd->memory.fixRam;
    uint8_t* usagePtrStart = fixUsageMap;
    uint8_t* usagePtrEnd = fixUsageMap + (Memory::FIXRAM_SIZE / 32);

    std::generate(usagePtrStart, usagePtrEnd, [&]() {
        bool result = std::any_of(fixPtr, fixPtr + 32, [](const uint8_t& value) {
            return value ? 1 : 0;
        });

        fixPtr += 32;
        return result;
    });
}

// Note: scanline between 16 and 240!
void Video::drawFix(uint32_t scanline)
{
    uint16_t* videoRamPtr = &neocd->memory.videoRam[(0xE004 / 2) + ((scanline - 16) / 8)] + (Video::LEFT_BORDER * 4);
    uint16_t* videoRamEndPtr = videoRamPtr + (FRAMEBUFFER_WIDTH * 4);
    uint16_t* frameBufferPtr = frameBuffer + ((scanline - 16) * FRAMEBUFFER_WIDTH);

    for (; videoRamPtr < videoRamEndPtr; videoRamPtr += 32)
    {
        int character = (*videoRamPtr) & 0x0FFF;
        int palette = ((*videoRamPtr) & 0xF000) >> 12;

        // Check for total transparency, no need to draw
        if (!fixUsageMap[character])
        {
#if VIDEO_STATS
            ++stats.fixCellsSkipped;
#endif
            frameBufferPtr += 8;
            continue;
        }

#if VIDEO_STATS
        ++stats.fixCells;
#endif

        const uint8_t* fixBase = &neocd->memory.fixRam[(character * 32) + (scanline % 8)];
        const uint16_t* paletteBase = &paletteRamPc[(activePaletteBank * 4096) + (palette * 16)];

        /* Four bytes make the eight pixels of one row of a character, two
           pixels apiece, and both of a pair go down in one blend. The
           framebuffer runs 320 pixels to the line and the pairs are
           always two pixels side by side within one, so a pair is whole
           wherever it lands; memcpy rather than a widened pointer keeps
           that a matter of arithmetic rather than of assumption.
        */
        auto decodeAndDrawFix = [&](int n) ALWAYS_INLINE {
            const uint8_t byte = fixBase[n];

            const uint32_t colors = uint32_t(paletteBase[byte & 0x0F])
                | (uint32_t(paletteBase[byte >> 4]) << 16);
            const uint32_t mask = FIX_PAIR_MASK[byte];

            uint32_t under;
            std::memcpy(&under, frameBufferPtr, sizeof(under));
            under = (colors & mask) | (under & ~mask);
            std::memcpy(frameBufferPtr, &under, sizeof(under));

            frameBufferPtr += 2;
        };

        decodeAndDrawFix(16);
        decodeAndDrawFix(24);
        decodeAndDrawFix(0);
        decodeAndDrawFix(8);
    }
}

static inline bool isSpriteOnScanline(uint32_t scanline, uint32_t y, uint32_t clipping)
{
    return (clipping == 0) || (clipping >= 0x20) || ((scanline - y) & 0x1ff) < (clipping * 0x10);
}

void Video::rebuildSpriteIndex()
{
    /* One walk over the sprite bank in hardware order resolves every
       sprite's place: chain position accumulates for each in turn, a
       chained sprite taking its x from the sum of everything before
       it. None of it depends on the line, so the walk happens once,
       and each visible line collects the sprites whose height covers
       it, in bank order, stopping at the chip's ninety six as the
       chip's own scan stops.
    */
#if VIDEO_STATS
    ++stats.rebuilds;
    ++stats.rebuildsThisFrame;
#endif

    const uint16_t* scb3 = &neocd->memory.videoRam[0x8000];
    const uint16_t* scb2 = &neocd->memory.videoRam[0x8200];
    const uint16_t* scb4 = &neocd->memory.videoRam[0x8400];

    uint32_t x = 0;
    uint32_t y = 0;
    uint32_t zoomX = 0xF;
    uint32_t zoomY = 0xFF;
    uint32_t clipping = 0;

    for (uint16_t spriteNumber = 1; spriteNumber <= MAX_SPRITES_PER_SCREEN; ++spriteNumber)
    {
        uint32_t attributes1 = scb3[spriteNumber];
        uint32_t attributes2 = scb2[spriteNumber];

        if (attributes2 & 0x40)
        {
            x = (x + zoomX + 1) & 0x1FF;
            zoomX = (attributes1 >> 8) & 0xF;
        }
        else
        {
            zoomY = attributes1 & 0xFF;
            zoomX = (attributes1 >> 8) & 0xF;
            clipping = attributes2 & 0x3F;
            y = 0x200 - (attributes2 >> 7);
            x = scb4[spriteNumber] >> 7;
        }

        resolvedX[spriteNumber] = static_cast<uint16_t>(x);
        resolvedY[spriteNumber] = static_cast<uint16_t>(y);
        resolvedZoomX[spriteNumber] = static_cast<uint8_t>(zoomX);
        resolvedZoomY[spriteNumber] = static_cast<uint8_t>(zoomY);
        resolvedClipping[spriteNumber] = static_cast<uint8_t>(clipping);
    }

    std::memset(lineSpriteCount, 0, sizeof(lineSpriteCount));

    for (uint16_t spriteNumber = 1; spriteNumber <= MAX_SPRITES_PER_SCREEN; ++spriteNumber)
    {
        uint32_t c = resolvedClipping[spriteNumber];

        if (!c)
            continue;

        auto take = [&](uint32_t from, uint32_t to) {
            for (uint32_t line = from; line < to; ++line)
            {
                uint8_t& count = lineSpriteCount[line - Timer::ACTIVE_AREA_TOP];
                if (count < MAX_SPRITES_PER_LINE)
                    lineSprites[line - Timer::ACTIVE_AREA_TOP][count++] = spriteNumber;
            }
        };

        if (c >= 0x20)
        {
            take(Timer::ACTIVE_AREA_TOP, Timer::ACTIVE_AREA_BOTTOM);
            continue;
        }

        // The covered lines: y to y + height, wrapped in the chip's
        // nine bit space, clipped to the visible area.
        uint32_t sy = resolvedY[spriteNumber];
        uint32_t height = c * 0x10;
        uint32_t end = (sy + height) & 0x1FF;

        auto clamp = [&](uint32_t from, uint32_t to) {
            from = std::max<uint32_t>(from, Timer::ACTIVE_AREA_TOP);
            to = std::min<uint32_t>(to, Timer::ACTIVE_AREA_BOTTOM);
            if (from < to)
                take(from, to);
        };

        if (sy < end)
            clamp(sy, end);
        else
        {
            clamp(sy, 0x200);
            clamp(0, end);
        }
    }

#if VIDEO_STATS
    for (uint32_t line = 0; line < FRAMEBUFFER_HEIGHT; ++line)
        stats.bucketEntries += lineSpriteCount[line];
#endif

    spriteIndexDirty = false;
}

uint16_t Video::renderScanlineSprites(uint32_t scanline, uint16_t *spriteList)
{
    if (spriteIndexDirty)
        rebuildSpriteIndex();

#if VIDEO_STATS
    ++stats.lines;
#endif

    const uint32_t row = scanline - Timer::ACTIVE_AREA_TOP;
    const uint16_t activeCount = lineSpriteCount[row];

    for (uint16_t at = 0; at < activeCount; ++at)
    {
        uint16_t spriteNumber = lineSprites[row][at];

        *spriteList++ = spriteNumber;

        drawSprite(spriteNumber,
                   resolvedX[spriteNumber],
                   resolvedY[spriteNumber],
                   resolvedZoomX[spriteNumber],
                   resolvedZoomY[spriteNumber],
                   scanline,
                   resolvedClipping[spriteNumber]);
    }

    // Fill the rest of the sprite list with 0, including one extra entry
    std::memset(spriteList, 0, sizeof(uint16_t) * (MAX_SPRITES_PER_LINE - activeCount + 1));

    return activeCount;
}

inline void drawSpriteLine(
    uint32_t zoomX,
    int increment,
    uint32_t pixelData,
    uint32_t pixelDataB,
    const uint16_t* paletteBase,
    uint16_t*& frameBufferPtr)
{
    uint16_t* out = frameBufferPtr;

    // Full width is nearly every sprite on screen; give it a straight
    // sixteen pixel run with no per-pixel table looks.
    if (zoomX == 15)
    {
        for (int i = 0; i < 8; ++i)
        {
            if (pixelData & (0xFu << (i * 4)))
                *out = paletteBase[(pixelData >> (i * 4)) & 0xF];
            out += increment;
        }
        for (int i = 0; i < 8; ++i)
        {
            if (pixelDataB & (0xFu << (i * 4)))
                *out = paletteBase[(pixelDataB >> (i * 4)) & 0xF];
            out += increment;
        }
        frameBufferPtr = out;
        return;
    }

    auto drawSprLine = [&](int N) {
        for(int i = 0; i < 8; ++i)
        {
            if (X_ZOOM_TABLE[N * 16 + i])
            {
                uint32_t mask = 0xF << (i * 4);
                if (pixelData & mask)
                    *out = paletteBase[(pixelData >> (i * 4)) & 0xF];
                out += increment;
            }
        }

        for(int i = 0; i < 8; ++i)
        {
            if (X_ZOOM_TABLE[N * 16 + 8 + i])
            {
                uint32_t mask = 0xF << (i * 4);
                if (pixelDataB & mask)
                    *out = paletteBase[(pixelDataB >> (i * 4)) & 0xF];
                out += increment;
            }
        }
    };

    switch (zoomX)
    {
    case 0:
        drawSprLine(0);
        break;
    case 1:
        drawSprLine(1);
        break;
    case 2:
        drawSprLine(2);
        break;
    case 3:
        drawSprLine(3);
        break;
    case 4:
        drawSprLine(4);
        break;
    case 5:
        drawSprLine(5);
        break;
    case 6:
        drawSprLine(6);
        break;
    case 7:
        drawSprLine(7);
        break;
    case 8:
        drawSprLine(8);
        break;
    case 9:
        drawSprLine(9);
        break;
    case 10:
        drawSprLine(10);
        break;
    case 11:
        drawSprLine(11);
        break;
    case 12:
        drawSprLine(12);
        break;
    case 13:
        drawSprLine(13);
        break;
    case 14:
        drawSprLine(14);
        break;
    case 15:
        drawSprLine(15);
        break;
    }

    frameBufferPtr = out;
}

inline void drawSpriteLineClipped(
    uint32_t zoomX,
    int increment,
    uint32_t pixelData,
    uint32_t pixelDataB,
    const uint16_t* paletteBase,
    uint16_t*& frameBufferPtr,
    const uint16_t* low,
    const uint16_t* high)
{
    uint16_t* out = frameBufferPtr;

    // Full width is nearly every sprite on screen; a straight sixteen
    // pixel run, still held inside the line like the general loop.
    if (zoomX == 15)
    {
        for (int i = 0; i < 8; ++i)
        {
            if ((pixelData & (0xFu << (i * 4))) && (out >= low) && (out < high))
                *out = paletteBase[(pixelData >> (i * 4)) & 0xF];
            out += increment;
        }
        for (int i = 0; i < 8; ++i)
        {
            if ((pixelDataB & (0xFu << (i * 4))) && (out >= low) && (out < high))
                *out = paletteBase[(pixelDataB >> (i * 4)) & 0xF];
            out += increment;
        }
        frameBufferPtr = out;
        return;
    }

    auto drawSprLine = [&](int N) {
        for(int i = 0; i < 8; ++i)
        {
            if (X_ZOOM_TABLE[N * 16 + i])
            {
                uint32_t mask = 0xF << (i * 4);
                if ((pixelData & mask) && (out >= low) && (out < high))
                    *out = paletteBase[(pixelData >> (i * 4)) & 0xF];
                out += increment;
            }
        }

        for(int i = 0; i < 8; ++i)
        {
            if (X_ZOOM_TABLE[N * 16 + 8 + i])
            {
                uint32_t mask = 0xF << (i * 4);
                if ((pixelDataB & mask) && (out >= low) && (out < high))
                    *out = paletteBase[(pixelDataB >> (i * 4)) & 0xF];
                out += increment;
            }
        }
    };

    switch (zoomX)
    {
    case 0:
        drawSprLine(0);
        break;
    case 1:
        drawSprLine(1);
        break;
    case 2:
        drawSprLine(2);
        break;
    case 3:
        drawSprLine(3);
        break;
    case 4:
        drawSprLine(4);
        break;
    case 5:
        drawSprLine(5);
        break;
    case 6:
        drawSprLine(6);
        break;
    case 7:
        drawSprLine(7);
        break;
    case 8:
        drawSprLine(8);
        break;
    case 9:
        drawSprLine(9);
        break;
    case 10:
        drawSprLine(10);
        break;
    case 11:
        drawSprLine(11);
        break;
    case 12:
        drawSprLine(12);
        break;
    case 13:
        drawSprLine(13);
        break;
    case 14:
        drawSprLine(14);
        break;
    case 15:
        drawSprLine(15);
        break;
    }

    frameBufferPtr = out;
}

void Video::drawSprite(uint32_t spriteNumber, uint32_t x, uint32_t y, uint32_t zoomX, uint32_t zoomY, uint32_t scanline, uint32_t clipping)
{
    uint32_t spriteLine = (scanline - y) & 0x1FF;
    uint32_t zoomLine = spriteLine & 0xFF;
    bool invert = (spriteLine & 0x100) != 0;

    enum Status {
        Normal,
        Clipped,
        Invisible
    };

    auto withinLimits = [&](uint32_t value) {
        return (value >= Video::LEFT_BORDER) && (value <= Video::RIGHT_BORDER);
    };

    auto checkVisibility = [&]() -> Status
    {
        uint32_t x2 = (x + zoomX + 1) & 0x1FF;
        uint32_t x1 = (x & 0x1FF);

        if (!withinLimits(x1) && !withinLimits(x2))
            return Invisible;

        if (!withinLimits(x1) || !withinLimits(x2))
            return Clipped;

        return Normal;
    };

    Status spriteStatus = checkVisibility();

    if (spriteStatus == Invisible)
    {
#if VIDEO_STATS
        ++stats.objectLinesOff;
#endif
        return;
    }

    if (invert)
        zoomLine ^= 0xFF;

    if (clipping == 0x21)
    {
        zoomLine = zoomLine % ((zoomY + 1) << 1);

        if (zoomLine > zoomY)
        {
            zoomLine = ((zoomY + 1) << 1) - 1 - zoomLine;
            invert = !invert;
        }
    }

    uint32_t tileNumber = neocd->memory.yZoomRom[zoomY * 256 + zoomLine];
    uint32_t tileLine = tileNumber & 0xF;
    tileNumber >>= 4;

    if (invert)
    {
        tileLine ^= 0x0f;
        tileNumber ^= 0x1f;
    }

    uint32_t tileIndex = neocd->memory.videoRam[spriteNumber * 64 + tileNumber * 2];
    uint32_t tileControl = neocd->memory.videoRam[spriteNumber * 64 + tileNumber * 2 + 1];

    if (tileControl & 2)
        tileLine ^= 0x0F;

    // Auto animation
    if (!autoAnimationDisabled)
    {
        if (tileControl & 0x0008)
            tileIndex = (tileIndex & ~0x07) | (autoAnimationCounter & 0x07);
        else if (tileControl & 0x0004)
            tileIndex = (tileIndex & ~0x03) | (autoAnimationCounter & 0x03);
    }

    const uint16_t* paletteBase = &paletteRamPc[(activePaletteBank * 0x1000) + ((tileControl >> 8) * 16)];
    const uint8_t* spriteBase = &neocd->memory.sprRam[(tileIndex & 0x7FFF) * 128 + (tileLine * 4)];

    uint16_t* frameBufferPtr = frameBuffer;

    frameBufferPtr += x;

    if (x > 0x1F0)
        frameBufferPtr -= 0x200;

    frameBufferPtr -= Video::LEFT_BORDER;

    frameBufferPtr += (scanline - 16) * FRAMEBUFFER_WIDTH;

    int increment;

    if (tileControl & 1)
    {
        frameBufferPtr += zoomX;
        increment = -1;
    }
    else
        increment = 1;

    uint32_t pixelData = SPR_DECODE_TABLE[spriteBase[64 + 1]]
        | (SPR_DECODE_TABLE[spriteBase[64 + 0]] << 1)
        | (SPR_DECODE_TABLE[spriteBase[64 + 3]] << 2)
        | (SPR_DECODE_TABLE[spriteBase[64 + 2]] << 3);

    uint32_t pixelDataB = SPR_DECODE_TABLE[spriteBase[0 + 1]]
        | (SPR_DECODE_TABLE[spriteBase[0 + 0]] << 1)
        | (SPR_DECODE_TABLE[spriteBase[0 + 3]] << 2)
        | (SPR_DECODE_TABLE[spriteBase[0 + 2]] << 3);

    if (spriteStatus == Clipped)
    {
        drawSpriteLineClipped(
            zoomX,
            increment,
            pixelData,
            pixelDataB,
            paletteBase,
            frameBufferPtr,
            frameBuffer + ((scanline - 16) * FRAMEBUFFER_WIDTH),
            frameBuffer + ((scanline - 15) * FRAMEBUFFER_WIDTH));
    }
    else
        drawSpriteLine(zoomX, increment, pixelData, pixelDataB, paletteBase, frameBufferPtr);

#if VIDEO_STATS
    /* Slots put on screen, transparent ones included: the zoom decides how
       many there are, and it is always zoomX + 1.
    */
    ++stats.objectLines;
    stats.objectPixels += zoomX + 1;
#endif
}

#if VIDEO_STATS
// Once every five seconds or thereabouts of a 60Hz picture.
static constexpr uint64_t STATS_FRAMES_PER_REPORT = 300;
#endif

void Video::noteFrame()
{
#if VIDEO_STATS
    /* An ordinary build arrives here with nothing counted and nothing to
       report, and the empty function is all that is left of it.

       The number to look for is the walks per frame. A game that lays its
       objects out during vertical blank costs one walk of the sprite bank
       for the whole picture; one that rewrites the sprite control blocks
       from a raster interrupt costs one per line, which on a screen full
       of objects is two orders of magnitude of work that the first game
       never pays. The worst figure says how bad the worst frame was, and
       the rest of the line is the load each walk and each drawn line
       brings with it.

       Logged at debug level: a line every five seconds is for whoever is
       reading a log file, and should not be across their picture.
    */
    if (stats.rebuildsThisFrame > stats.worstRebuilds)
        stats.worstRebuilds = stats.rebuildsThisFrame;

    stats.rebuildsThisFrame = 0;

    if (++stats.frames < STATS_FRAMES_PER_REPORT)
        return;

    const double frames = static_cast<double>(stats.frames);

    Libretro::Log::message(RETRO_LOG_DEBUG,
        "VIDEO STATS over %llu frames: %.2f sprite bank walks per frame (worst %llu in one frame), "
        "%.1f scanlines and %.1f object lines drawn, %.1f object lines off screen, %.0f object pixels, "
        "%.1f fix cells drawn and %.1f skipped, %.1f entries per walk\n",
        static_cast<unsigned long long>(stats.frames),
        static_cast<double>(stats.rebuilds) / frames,
        static_cast<unsigned long long>(stats.worstRebuilds),
        static_cast<double>(stats.lines) / frames,
        static_cast<double>(stats.objectLines) / frames,
        static_cast<double>(stats.objectLinesOff) / frames,
        static_cast<double>(stats.objectPixels) / frames,
        static_cast<double>(stats.fixCells) / frames,
        static_cast<double>(stats.fixCellsSkipped) / frames,
        stats.rebuilds ? static_cast<double>(stats.bucketEntries) / static_cast<double>(stats.rebuilds) : 0.0);

    stats = {};
#endif // VIDEO_STATS
}

void Video::drawBlackLine(uint32_t scanline)
{
    std::memset(&frameBuffer[(scanline - 16) * Video::FRAMEBUFFER_WIDTH], 0, Video::FRAMEBUFFER_WIDTH * sizeof(uint16_t));
}

void Video::drawEmptyLine(uint32_t scanline)
{
    uint16_t* ptr = &frameBuffer[(scanline - 16) * Video::FRAMEBUFFER_WIDTH];
    uint16_t* ptrEnd = ptr + Video::FRAMEBUFFER_WIDTH;
    uint16_t color = paletteRamPc[(activePaletteBank * 0x1000) + 4095];

    std::fill(ptr, ptrEnd, color);
}

DataPacker& operator<<(DataPacker& out, const Video& video)
{
    out << video.activePaletteBank;
    out << video.autoAnimationCounter;
    out << video.autoAnimationSpeed;
    out << video.autoAnimationFrameCounter;
    out << video.autoAnimationDisabled;
    out << video.sprDisable;
    out << video.fixDisable;
    out << video.videoEnable;
    out << video.hirqControl;
    out << video.hirqRegister;
    out << video.videoramOffset;
    out << video.videoramModulo;
    out << video.videoramData;
    out << video.sprite_x;
    out << video.sprite_y;
    out << video.sprite_zoomX;
    out << video.sprite_zoomY;
    out << video.sprite_clipping;

    return out;
}

DataPacker& operator>>(DataPacker& in, Video& video)
{
    in >> video.activePaletteBank;
    in >> video.autoAnimationCounter;
    in >> video.autoAnimationSpeed;
    in >> video.autoAnimationFrameCounter;
    in >> video.autoAnimationDisabled;
    in >> video.sprDisable;
    in >> video.fixDisable;
    in >> video.videoEnable;
    in >> video.hirqControl;
    in >> video.hirqRegister;
    in >> video.videoramOffset;
    in >> video.videoramModulo;
    in >> video.videoramData;
    in >> video.sprite_x;
    in >> video.sprite_y;
    in >> video.sprite_zoomX;
    in >> video.sprite_zoomY;
    in >> video.sprite_clipping;

    // These come back as raw words from the state and are then used as
    // array indices before the hardware would next constrain them. During
    // normal operation activePaletteBank is only ever 0 or 1, videoramOffset
    // is kept to 16 bits by the auto-increment mask, and sprite_zoomY is a
    // byte from the sprite attributes. A corrupt state could set any of them
    // out of range, which would index paletteRam/paletteRamPc, videoRam and
    // yZoomRom out of bounds (and make (zoomY + 1) << 1 wrap to a zero
    // modulus). Fold them back into their hardware ranges here.
    video.activePaletteBank &= 1;
    video.videoramOffset    &= 0xFFFF;
    video.sprite_zoomY      &= 0xFF;

    video.spriteIndexDirty = true;

    return in;
}
